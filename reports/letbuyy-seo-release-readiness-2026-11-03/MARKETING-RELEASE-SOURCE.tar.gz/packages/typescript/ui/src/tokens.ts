import { letbuyyFontStacks } from './fonts';

export type LetbuyyTheme = 'light' | 'dark';
export type LetbuyyDensity = 'compact' | 'comfortable' | 'spacious';
export type LetbuyySurface = 'admin' | 'marketplace' | 'storefront' | 'identity' | 'operations';

type CssVariableMap = Record<`--${string}`, string>;

const deprecatedTokenAliasVariables = new Set<string>([
    '--lb-color-text-primary',
    '--lb-color-text-secondary',
    '--lb-color-border-default',
    '--lb-color-border-subtle',
    '--lb-color-danger',
    '--lb-semantic-focus-ring',
    '--lb-semantic-accent-brand',
    '--lb-semantic-accent-text',
    '--lb-semantic-text-primary',
    '--lb-semantic-text-secondary',
    '--lb-semantic-text-muted',
]);

export interface LetbuyyBrandOverrides {
    primary: string;
    primaryText?: string;
    primaryHover?: string;
    primaryActive?: string;
    primarySubtle?: string;
    primaryCta?: string;
    primaryCtaHover?: string;
    primaryCtaActive?: string;
    primaryCtaText?: string;
    focusRing?: string;
}

export type LetbuyyBrandInput = string | LetbuyyBrandOverrides;

export interface LetbuyyBrandContrastCheck {
    token: '--lb-color-primary-text' | '--lb-color-primary-cta-text' | '--lb-color-focus-ring';
    foreground: string;
    background: string;
    ratio: number;
    minimum: number;
    passes: boolean;
}

export const letbuyyPrimitiveTokens = {
    color: {
        purple: {
            100: '#EDE9FE',
            200: '#DDD6FE',
            300: '#C4B5FD',
            400: '#A78BFA',
            500: '#8B5CF6',
            600: '#7C3AED',
            700: '#6D28D9',
            800: '#5B21B6',
            900: '#4C1D95',
        },
        gray: {
            50: '#F9FAFB',
            100: '#F5F5F7',
            125: '#F6F7F9',
            150: '#EFEFF1',
            175: '#F1F2F4',
            200: '#E5E7EB',
            300: '#D1D5DB',
            400: '#94A3B8',
            500: '#6B7280',
            600: '#4B5563',
            700: '#374151',
            800: '#1F2937',
            900: '#111827',
        },
        slate: {
            50: '#F8FAFC',
            100: '#F1F5F9',
            200: '#E2E8F0',
            300: '#CBD5E1',
            400: '#94A3B8',
            500: '#64748B',
            600: '#475569',
            700: '#334155',
            800: '#1E293B',
            850: '#1F2937',
            900: '#0F172A',
            950: '#0A0F1A',
        },
        // Deep violet-tinted darks — the platform's canonical dark mode palette
        ink: {
            950: '#0a0912',
            900: '#0d0b15',
            850: '#0d0b16',
            800: '#15131f',
            700: '#1b1827',
        },
        /**
         * Brand ink — the merchant control plane's operator identity.
         *
         * Anchored on the admin navigation rail (`800` = #2C2642 = hsl(253 27% 20%));
         * every other step is that exact hue held constant, so the rail, the primary
         * CTA, the focus ring and the active-nav accent are provably one family
         * rather than two purples that merely look similar.
         *
         * This is deliberately NOT `purple` (hue 258, saturation 91%): the stock
         * ramp is a loud product violet, while an operator console is read for
         * hours and needs a calm, desaturated ink. Both scales coexist — `purple`
         * remains the marketplace/storefront accent, `brandInk` is the admin one.
         */
        brandInk: {
            100: '#E7E3F7',
            200: '#C9BFED',
            300: '#9D8DD8',
            400: '#6C54C4',
            500: '#523F97',
            600: '#443870',
            700: '#362C58',
            800: '#2C2642',
            850: '#1E1A2D',
            900: '#181524',
            950: '#0F0D17',
        },
        white: '#FFFFFF',
        black: '#000000',
        green: {
            100: '#DCFCE7',
            500: '#22C55E',
            700: '#15803D',
            950: '#052E16',
        },
        amber: {
            100: '#FEF3C7',
            500: '#F59E0B',
            800: '#92400E',
            950: '#422006',
        },
        red: {
            100: '#FEE2E2',
            300: '#FCA5A5',
            500: '#EF4444',
            600: '#DC2626',
            700: '#B91C1C',
            950: '#451A1A',
        },
        pink: {
            300: '#F9A8D4',
            400: '#F472B6',
            500: '#EC4899',
            600: '#DB2777',
            700: '#BE185D',
        },
        blue: {
            100: '#E0F2FE',
            300: '#7DD3FC',
            500: '#3B82F6',
            700: '#1D4ED8',
            950: '#082F49',
        },
        cyan: {
            500: '#06B6D4',
        },
        teal: {
            100: '#CCFBF1',
            300: '#5EEAD4',
            500: '#14B8A6',
            600: '#0D9488',
            700: '#0F766E',
            800: '#115E59',
            900: '#134E4A',
        },
        // Neutral graphite for long-session operations workspaces.
        graphite: {
            50: '#FAFBFC',
            100: '#F4F6F8',
            200: '#E1E6EA',
            300: '#C5CDD4',
            400: '#A6B1BB',
            500: '#65717C',
            600: '#505D68',
            700: '#35414B',
            750: '#303A43',
            800: '#242C33',
            850: '#1B2228',
            900: '#151B20',
            950: '#10161B',
        },
        // Owner-approved Console E: burgundy actions, a wine rail and porcelain layers.
        burgundy: {
            100: '#F4DDE4',
            200: '#EAC0CE',
            300: '#DEA3B7',
            400: '#C47A92',
            500: '#BE708B',
            700: '#8D3F56',
            800: '#713146',
            850: '#5B2D3E',
            900: '#44232E',
            950: '#24141C',
        },
        porcelain: {
            50: '#FAF8F9',
            100: '#F6F2F3',
            200: '#E7DEE1',
            400: '#BFB0B6',
            500: '#75666D',
            700: '#594751',
            750: '#483941',
            800: '#30262C',
            850: '#231D21',
            900: '#1D171B',
            950: '#171317',
            text: '#30232B',
        },
        emerald: {
            500: '#10B981',
        },
    },
    opacity: {
        purpleSubtle: 'rgba(139, 92, 246, 0.12)',
        overlayLight: 'rgb(15 23 42 / 56%)',
        overlayDark: 'rgb(0 0 0 / 64%)',
    },
} as const;

const primitive = letbuyyPrimitiveTokens;

export const letbuyyBreakpointTokens = {
    xs: '360px',
    mobile: '480px',
    sm: '640px',
    md: '768px',
    lg: '1024px',
    xl: '1280px',
} as const;

export const letbuyyTailwindScreens = {
    xs: letbuyyBreakpointTokens.xs,
    mobile: letbuyyBreakpointTokens.mobile,
    sm: letbuyyBreakpointTokens.sm,
    md: letbuyyBreakpointTokens.md,
    lg: letbuyyBreakpointTokens.lg,
    xl: letbuyyBreakpointTokens.xl,
} as const;

export const letbuyyTailwindPreset = {
    theme: {
        screens: letbuyyTailwindScreens,
    },
} as const;

export const letbuyyShadowTokens = {
    sm: '0 1px 2px rgb(0 0 0 / 4%)',
    md: '0 4px 12px rgb(15 23 42 / 6%)',
    lg: '0 12px 32px rgb(15 23 42 / 8%)',
    cardLight: '0 1px 2px rgb(15 23 42 / 5%), 0 8px 24px rgb(15 23 42 / 4%)',
    cardDark: '0 1px 2px rgb(0 0 0 / 18%), 0 10px 26px rgb(0 0 0 / 16%)',
} as const;

export const letbuyyColorTokens = {
    brandPurple: primitive.color.purple[500],
    primary: primitive.color.purple[500],
    primaryTextLight: primitive.color.purple[700],
    primaryTextDark: primitive.color.purple[300],
    primaryHover: primitive.color.purple[600],
    primaryActive: primitive.color.purple[700],
    primarySubtle: primitive.opacity.purpleSubtle,
    backgroundLight: primitive.color.gray[125],
    backgroundDark: primitive.color.ink[950],
    surfaceLight: primitive.color.white,
    surfaceDark: primitive.color.ink[850],
    cardLight: primitive.color.white,
    cardDark: primitive.color.ink[800],
    sidebarLight: primitive.color.gray[175],
    sidebarDark: primitive.color.ink[900],
    textPrimaryLight: primitive.color.gray[900],
    textPrimaryDark: primitive.color.white,
    textSecondaryLight: primitive.color.gray[500],
    textSecondaryDark: primitive.color.slate[300],
    textMuted: primitive.color.gray[500],
    borderLight: primitive.color.gray[200],
    borderDark: 'rgba(139, 92, 246, 0.18)',
    success: primitive.color.green[500],
    warning: primitive.color.amber[500],
    danger: primitive.color.red[500],
    info: primitive.color.blue[500],
} as const;

export const letbuyySemanticTokens = {
    light: {
        background: {
            page: letbuyyColorTokens.backgroundLight,
            surface: letbuyyColorTokens.surfaceLight,
            card: letbuyyColorTokens.cardLight,
            subdued: primitive.color.gray[50],
            raised: letbuyyColorTokens.cardLight,
            sidebar: letbuyyColorTokens.sidebarLight,
            header: letbuyyColorTokens.surfaceLight,
        },
        button: {
            primary: {
                bg: primitive.color.purple[700],
                hover: primitive.color.purple[800],
                active: primitive.color.purple[900],
                text: primitive.color.white,
                border: primitive.color.purple[700],
            },
            secondary: {
                bg: 'transparent',
                hover: primitive.color.gray[50],
                text: primitive.color.gray[900],
                border: primitive.color.gray[200],
            },
        },
        text: {
            primary: letbuyyColorTokens.textPrimaryLight,
            secondary: letbuyyColorTokens.textSecondaryLight,
            muted: letbuyyColorTokens.textMuted,
            inverse: primitive.color.white,
        },
        border: {
            subtle: primitive.color.gray[200],
            default: primitive.color.gray[200],
            strong: primitive.color.slate[700],
        },
        accent: {
            brand: letbuyyColorTokens.primary,
            text: letbuyyColorTokens.primaryTextLight,
            hover: letbuyyColorTokens.primaryHover,
            active: letbuyyColorTokens.primaryActive,
            subtle: letbuyyColorTokens.primarySubtle,
        },
        status: {
            success: letbuyyColorTokens.success,
            warning: letbuyyColorTokens.warning,
            danger: letbuyyColorTokens.danger,
            info: letbuyyColorTokens.info,
        },
        statusText: {
            success: primitive.color.green[700],
            warning: primitive.color.amber[800],
            danger: primitive.color.red[700],
            info: primitive.color.blue[700],
        },
        statusSoft: {
            success: primitive.color.green[100],
            warning: primitive.color.amber[100],
            danger: primitive.color.red[100],
            info: primitive.color.blue[100],
        },
        focusRing: primitive.color.purple[800],
        overlay: primitive.opacity.overlayLight,
    },
    dark: {
        background: {
            page: letbuyyColorTokens.backgroundDark,
            surface: letbuyyColorTokens.surfaceDark,
            card: letbuyyColorTokens.cardDark,
            subdued: primitive.color.ink[950],
            raised: primitive.color.ink[700],
            sidebar: letbuyyColorTokens.sidebarDark,
            header: letbuyyColorTokens.surfaceDark,
        },
        button: {
            primary: {
                bg: primitive.color.purple[700],
                hover: primitive.color.purple[800],
                active: primitive.color.purple[900],
                text: primitive.color.white,
                border: primitive.color.purple[700],
            },
            secondary: {
                bg: letbuyyColorTokens.surfaceDark,
                hover: letbuyyColorTokens.cardDark,
                text: primitive.color.white,
                border: letbuyyColorTokens.borderDark,
            },
        },
        text: {
            primary: letbuyyColorTokens.textPrimaryDark,
            secondary: letbuyyColorTokens.textSecondaryDark,
            muted: letbuyyColorTokens.textMuted,
            inverse: letbuyyColorTokens.textPrimaryLight,
        },
        border: {
            subtle: letbuyyColorTokens.borderDark,
            default: letbuyyColorTokens.borderDark,
            strong: letbuyyColorTokens.borderLight,
        },
        accent: {
            brand: letbuyyColorTokens.primary,
            text: letbuyyColorTokens.primaryTextDark,
            hover: letbuyyColorTokens.primaryHover,
            active: letbuyyColorTokens.primaryActive,
            subtle: letbuyyColorTokens.primarySubtle,
        },
        status: {
            success: letbuyyColorTokens.success,
            warning: letbuyyColorTokens.warning,
            danger: letbuyyColorTokens.danger,
            info: letbuyyColorTokens.info,
        },
        statusText: {
            success: letbuyyColorTokens.success,
            warning: letbuyyColorTokens.warning,
            danger: primitive.color.red[300],
            info: primitive.color.blue[300],
        },
        statusSoft: {
            success: primitive.color.green[950],
            warning: primitive.color.amber[950],
            danger: primitive.color.red[950],
            info: primitive.color.blue[950],
        },
        focusRing: letbuyyColorTokens.primary,
        overlay: primitive.opacity.overlayDark,
    },
} as const;

export const letbuyyComponentTokens = {
    light: {
        button: {
            primary: letbuyySemanticTokens.light.button.primary,
            secondary: letbuyySemanticTokens.light.button.secondary,
        },
        card: {
            bg: letbuyySemanticTokens.light.background.card,
            text: letbuyySemanticTokens.light.text.primary,
            border: letbuyySemanticTokens.light.border.default,
            radius: '16px',
            shadow: letbuyyShadowTokens.cardLight,
        },
        sidebar: {
            bg: letbuyySemanticTokens.light.background.sidebar,
            border: primitive.color.gray[200],
            hoverBg: 'rgb(15 23 42 / 4%)',
            activeBg: 'rgb(15 23 42 / 6%)',
            activeText: primitive.color.gray[900],
            sectionText: primitive.color.gray[500],
            itemRadius: '12px',
            rowHeight: 'var(--lb-density-sidebar-row-height)',
            iconSize: 'var(--lb-density-sidebar-icon-size)',
            nestedItemSize: '14px',
            nestedSpacing: 'var(--lb-density-sidebar-nested-spacing, 8px)',
            sectionSpacing: 'var(--lb-density-sidebar-section-spacing, 16px)',
            // Active affordance: a rail plus a hairline inset ring reads as
            // deliberate at a glance, where a flat fill alone reads as a hover.
            railColor: 'color-mix(in srgb, var(--lb-color-primary) 92%, transparent)',
            activeRing: 'inset 0 0 0 1px color-mix(in srgb, var(--lb-color-primary) 12%, transparent)',
            childRail: 'color-mix(in srgb, var(--lb-color-border) 70%, transparent)',
        },
        emptyState: {
            bg: letbuyySemanticTokens.light.background.card,
            border: letbuyySemanticTokens.light.border.default,
            illustrationBg: letbuyySemanticTokens.light.accent.subtle,
            illustrationInk: letbuyySemanticTokens.light.accent.brand,
            title: letbuyySemanticTokens.light.text.primary,
            body: letbuyySemanticTokens.light.text.secondary,
        },
        input: {
            bg: letbuyySemanticTokens.light.background.surface,
            text: letbuyySemanticTokens.light.text.primary,
            placeholder: letbuyySemanticTokens.light.text.secondary,
            border: letbuyySemanticTokens.light.border.default,
            focusBorder: letbuyySemanticTokens.light.accent.brand,
            focusRing: letbuyySemanticTokens.light.accent.subtle,
            height: 'var(--lb-density-input-height)',
        },
        table: {
            bg: letbuyySemanticTokens.light.background.card,
            headerBg: letbuyySemanticTokens.light.background.subdued,
            rowHoverBg: letbuyySemanticTokens.light.background.subdued,
            border: letbuyySemanticTokens.light.border.default,
            text: letbuyySemanticTokens.light.text.primary,
            textSecondary: letbuyySemanticTokens.light.text.secondary,
            rowHeight: 'var(--lb-density-table-row-height)',
            headerHeight: 'var(--lb-density-table-header-height)',
            toolbarHeight: 'var(--lb-density-action-bar-height)',
        },
        pageHeader: {
            height: 'var(--lb-density-header-height)',
            titleSize: '24px',
            titleLineHeight: '32px',
            iconSize: 'var(--lb-component-page-header-title-size)',
            iconBg: 'transparent',
            iconText: primitive.color.gray[900],
            iconFill: 'color-mix(in srgb, currentColor 18%, transparent)',
            iconStrokeWidth: '2.45',
            iconBorder: 'transparent',
        },
        badge: {
            accentBg: letbuyySemanticTokens.light.accent.subtle,
            accentText: letbuyySemanticTokens.light.accent.text,
            accentBorder: letbuyySemanticTokens.light.accent.brand,
        },
        banner: {
            infoBg: letbuyySemanticTokens.light.statusSoft.info,
            infoText: letbuyySemanticTokens.light.statusText.info,
            infoBorder: letbuyySemanticTokens.light.status.info,
            successBg: letbuyySemanticTokens.light.statusSoft.success,
            successText: letbuyySemanticTokens.light.statusText.success,
            successBorder: letbuyySemanticTokens.light.status.success,
            warningBg: letbuyySemanticTokens.light.statusSoft.warning,
            warningText: letbuyySemanticTokens.light.statusText.warning,
            warningBorder: letbuyySemanticTokens.light.status.warning,
            dangerBg: letbuyySemanticTokens.light.statusSoft.danger,
            dangerText: letbuyySemanticTokens.light.statusText.danger,
            dangerBorder: letbuyySemanticTokens.light.status.danger,
        },
        /* Deliberately NOT statusSoft (the pale tints banner/badge use) — a
           toast is a transient, high-attention surface (Sonner "rich colors"),
           so it takes a full, saturated fill with white text/icon on top. One
           step darker than the mid-tone `status.*` accent (500-weight, too
           light for AA-contrast white text) — the 700-weight primitive, or
           amber's 800 where the scale has no 700. */
        toast: {
            // 700/800 (and red's own 700) read as muddy/near-black at toast
            // size — dropped one step to the classic "600" tier (the usual
            // sweet spot for a solid fill with white text: vivid, still
            // AA-contrast). green/amber/blue have no 600 in the primitive
            // scale, so these are literal — still centralised here, just not
            // reused from an existing step.
            infoBg: '#2563EB',
            successBg: '#16A34A',
            warningBg: '#D97706',
            dangerBg: primitive.color.red[600],
            text: primitive.color.white,
            iconBg: 'rgb(255 255 255 / 20%)',
            closeHover: 'rgb(255 255 255 / 16%)',
        },
        /* Banner's own solid fill — same "600" tier decision as toast, kept
           as a separate named token (not a cross-component reference to
           --lb-component-toast-*) so the two surfaces can be retuned
           independently later. `action*` is the "on solid colour" button
           treatment: an inline action (e.g. Retry) inside a full-bleed
           banner can't use the page's normal secondary-button tokens — those
           assume a neutral/white background — so Banner overrides them
           locally to a translucent-white ghost button that reads on any of
           the four solid fills below. */
        bannerSolid: {
            infoBg: '#2563EB',
            successBg: '#16A34A',
            warningBg: '#D97706',
            dangerBg: primitive.color.red[600],
            text: primitive.color.white,
            actionBg: 'rgb(255 255 255 / 14%)',
            actionBorder: 'rgb(255 255 255 / 40%)',
            actionText: primitive.color.white,
            actionHover: 'rgb(255 255 255 / 24%)',
        },
        /* Same "600"-tier solid fills as toast/bannerSolid — one visual
           language across every status surface. `defaultBg` is the one
           variant that's NOT a fixed semantic colour: it's a neutral/brand
           chip (role labels, counts), so it takes the LIVE --lb-color-primary
           reference rather than a literal — on the admin surface that
           resolves to the merchant ink brand automatically, on any other
           surface to that surface's own primary. Never a hardcoded hex here. */
        badgeSolid: {
            defaultBg: 'var(--lb-color-primary)',
            infoBg: '#2563EB',
            successBg: '#16A34A',
            warningBg: '#D97706',
            dangerBg: primitive.color.red[600],
            text: primitive.color.white,
        },
    },
    dark: {
        button: {
            primary: letbuyySemanticTokens.dark.button.primary,
            secondary: letbuyySemanticTokens.dark.button.secondary,
        },
        card: {
            bg: letbuyySemanticTokens.dark.background.card,
            text: letbuyySemanticTokens.dark.text.primary,
            border: letbuyySemanticTokens.dark.border.default,
            radius: '16px',
            shadow: letbuyyShadowTokens.cardDark,
        },
        sidebar: {
            bg: letbuyySemanticTokens.dark.background.sidebar,
            border: letbuyySemanticTokens.dark.border.default,
            hoverBg: 'rgb(255 255 255 / 5%)',
            activeBg: 'rgb(139 92 246 / 16%)',
            activeText: primitive.color.white,
            sectionText: letbuyySemanticTokens.dark.text.secondary,
            itemRadius: '12px',
            rowHeight: 'var(--lb-density-sidebar-row-height)',
            iconSize: 'var(--lb-density-sidebar-icon-size)',
            nestedItemSize: '14px',
            nestedSpacing: 'var(--lb-density-sidebar-nested-spacing, 8px)',
            sectionSpacing: 'var(--lb-density-sidebar-section-spacing, 16px)',
            // Carried heavier on dark, where low-alpha edges disappear.
            railColor: 'color-mix(in srgb, var(--lb-color-primary) 96%, transparent)',
            activeRing: 'inset 0 0 0 1px color-mix(in srgb, var(--lb-color-primary) 28%, transparent)',
            childRail: 'color-mix(in srgb, var(--lb-color-border) 88%, transparent)',
        },
        emptyState: {
            bg: letbuyySemanticTokens.dark.background.card,
            border: letbuyySemanticTokens.dark.border.default,
            illustrationBg: letbuyySemanticTokens.dark.accent.subtle,
            illustrationInk: letbuyySemanticTokens.dark.accent.brand,
            title: letbuyySemanticTokens.dark.text.primary,
            body: letbuyySemanticTokens.dark.text.secondary,
        },
        input: {
            bg: letbuyySemanticTokens.dark.background.surface,
            text: letbuyySemanticTokens.dark.text.primary,
            placeholder: letbuyySemanticTokens.dark.text.secondary,
            border: letbuyySemanticTokens.dark.border.default,
            focusBorder: letbuyySemanticTokens.dark.accent.brand,
            focusRing: letbuyySemanticTokens.dark.accent.subtle,
            height: 'var(--lb-density-input-height)',
        },
        table: {
            bg: letbuyySemanticTokens.dark.background.card,
            headerBg: letbuyySemanticTokens.dark.background.surface,
            rowHoverBg: letbuyySemanticTokens.dark.background.surface,
            border: letbuyySemanticTokens.dark.border.default,
            text: letbuyySemanticTokens.dark.text.primary,
            textSecondary: letbuyySemanticTokens.dark.text.secondary,
            rowHeight: 'var(--lb-density-table-row-height)',
            headerHeight: 'var(--lb-density-table-header-height)',
            toolbarHeight: 'var(--lb-density-action-bar-height)',
        },
        pageHeader: {
            height: 'var(--lb-density-header-height)',
            titleSize: '24px',
            titleLineHeight: '32px',
            iconSize: 'var(--lb-component-page-header-title-size)',
            iconBg: 'transparent',
            iconText: primitive.color.white,
            iconFill: 'color-mix(in srgb, currentColor 18%, transparent)',
            iconStrokeWidth: '2.45',
            iconBorder: 'transparent',
        },
        badge: {
            accentBg: letbuyySemanticTokens.dark.accent.subtle,
            accentText: letbuyySemanticTokens.dark.accent.text,
            accentBorder: letbuyySemanticTokens.dark.accent.brand,
        },
        banner: {
            infoBg: letbuyySemanticTokens.dark.statusSoft.info,
            infoText: letbuyySemanticTokens.dark.statusText.info,
            infoBorder: letbuyySemanticTokens.dark.status.info,
            successBg: letbuyySemanticTokens.dark.statusSoft.success,
            successText: letbuyySemanticTokens.dark.statusText.success,
            successBorder: letbuyySemanticTokens.dark.status.success,
            warningBg: letbuyySemanticTokens.dark.statusSoft.warning,
            warningText: letbuyySemanticTokens.dark.statusText.warning,
            warningBorder: letbuyySemanticTokens.dark.status.warning,
            dangerBg: letbuyySemanticTokens.dark.statusSoft.danger,
            dangerText: letbuyySemanticTokens.dark.statusText.danger,
            dangerBorder: letbuyySemanticTokens.dark.status.danger,
        },
        /* Same solid fills as light — a rich-colours toast doesn't need to
           invert per theme the way a subtle tint/border pairing does; white
           text stays legible against these regardless of page theme. */
        toast: {
            // 700/800 (and red's own 700) read as muddy/near-black at toast
            // size — dropped one step to the classic "600" tier (the usual
            // sweet spot for a solid fill with white text: vivid, still
            // AA-contrast). green/amber/blue have no 600 in the primitive
            // scale, so these are literal — still centralised here, just not
            // reused from an existing step.
            infoBg: '#2563EB',
            successBg: '#16A34A',
            warningBg: '#D97706',
            dangerBg: primitive.color.red[600],
            text: primitive.color.white,
            iconBg: 'rgb(255 255 255 / 20%)',
            closeHover: 'rgb(255 255 255 / 16%)',
        },
        bannerSolid: {
            infoBg: '#2563EB',
            successBg: '#16A34A',
            warningBg: '#D97706',
            dangerBg: primitive.color.red[600],
            text: primitive.color.white,
            actionBg: 'rgb(255 255 255 / 14%)',
            actionBorder: 'rgb(255 255 255 / 40%)',
            actionText: primitive.color.white,
            actionHover: 'rgb(255 255 255 / 24%)',
        },
        badgeSolid: {
            defaultBg: 'var(--lb-color-primary)',
            infoBg: '#2563EB',
            successBg: '#16A34A',
            warningBg: '#D97706',
            dangerBg: primitive.color.red[600],
            text: primitive.color.white,
        },
    },
} as const;

export const letbuyyZIndexTokens = {
    base: '0',
    dropdown: '30',
    sticky: '40',
    overlay: '50',
    modal: '60',
    toast: '70',
    tooltip: '80',
} as const;

export const letbuyyDensityTokens = {
    compact: {
        sidebarRowHeight: '40px',
        inputHeight: '36px',
        buttonHeight: '36px',
        buttonHeightLarge: '40px',
        iconButtonHeight: '32px',
        pillHeight: '28px',
        tableRowHeight: '44px',
        tableHeaderHeight: '44px',
        pageGap: '12px',
        sectionGap: '12px',
        cardGap: '16px',
        cardPadding: '16px',
        headerHeight: '64px',
        actionBarHeight: '36px',
        modalPadding: '16px',
        nestedSpacing: '8px',
        sectionSpacing: '16px',
        emptyStateScale: '0.72',
        emptyStateIllustrationWidth: '160px',
        emptyStateIllustrationHeight: '108px',
        emptyStateMinHeight: '180px',
        iconPage: '18px',
        iconSidebar: '18px',
        iconButton: '16px',
        iconTable: '14px',
        iconAction: '16px',
    },
    comfortable: {
        sidebarRowHeight: '44px',
        inputHeight: '40px',
        buttonHeight: '40px',
        buttonHeightLarge: '44px',
        iconButtonHeight: '36px',
        pillHeight: '32px',
        tableRowHeight: '48px',
        tableHeaderHeight: '48px',
        pageGap: '16px',
        sectionGap: '16px',
        cardGap: '20px',
        cardPadding: '20px',
        headerHeight: '72px',
        actionBarHeight: '40px',
        modalPadding: '20px',
        nestedSpacing: '8px',
        sectionSpacing: '16px',
        emptyStateScale: '0.88',
        emptyStateIllustrationWidth: '184px',
        emptyStateIllustrationHeight: '122px',
        emptyStateMinHeight: '220px',
        iconPage: '20px',
        iconSidebar: '18px',
        iconButton: '16px',
        iconTable: '14px',
        iconAction: '16px',
    },
    spacious: {
        sidebarRowHeight: '48px',
        inputHeight: '44px',
        buttonHeight: '44px',
        buttonHeightLarge: '48px',
        iconButtonHeight: '40px',
        pillHeight: '36px',
        tableRowHeight: '52px',
        tableHeaderHeight: '52px',
        pageGap: '20px',
        sectionGap: '20px',
        cardGap: '24px',
        cardPadding: '24px',
        headerHeight: '88px',
        actionBarHeight: '44px',
        modalPadding: '24px',
        nestedSpacing: '12px',
        sectionSpacing: '20px',
        emptyStateScale: '1',
        emptyStateIllustrationWidth: '208px',
        emptyStateIllustrationHeight: '138px',
        emptyStateMinHeight: '260px',
        iconPage: '22px',
        iconSidebar: '20px',
        iconButton: '18px',
        iconTable: '16px',
        iconAction: '18px',
    },
} as const;

export const letbuyyTokens = {
    primitive: letbuyyPrimitiveTokens,
    semantic: letbuyySemanticTokens,
    component: letbuyyComponentTokens,
    density: letbuyyDensityTokens,
    zIndex: letbuyyZIndexTokens,
    breakpoint: letbuyyBreakpointTokens,
    color: {
        light: {
            ...letbuyyColorTokens,
            bg: letbuyySemanticTokens.light.background.page,
            background: letbuyySemanticTokens.light.background.page,
            surface: letbuyySemanticTokens.light.background.surface,
            surfaceRaised: letbuyySemanticTokens.light.background.raised,
            surfaceSubdued: letbuyySemanticTokens.light.background.subdued,
            card: letbuyySemanticTokens.light.background.card,
            sidebar: letbuyySemanticTokens.light.background.sidebar,
            header: letbuyySemanticTokens.light.background.header,
            border: letbuyySemanticTokens.light.border.default,
            borderSubtle: letbuyySemanticTokens.light.border.subtle,
            borderDefault: letbuyySemanticTokens.light.border.default,
            borderStrong: letbuyySemanticTokens.light.border.strong,
            text: letbuyySemanticTokens.light.text.primary,
            textPrimary: letbuyySemanticTokens.light.text.primary,
            textSubdued: letbuyySemanticTokens.light.text.secondary,
            textSecondary: letbuyySemanticTokens.light.text.secondary,
            textMuted: letbuyySemanticTokens.light.text.muted,
            textInverse: letbuyySemanticTokens.light.text.inverse,
            primaryText: letbuyySemanticTokens.light.accent.text,
            primarySoft: letbuyySemanticTokens.light.accent.subtle,
            primaryCta: letbuyyComponentTokens.light.button.primary.bg,
            primaryCtaHover: letbuyyComponentTokens.light.button.primary.hover,
            primaryCtaActive: letbuyyComponentTokens.light.button.primary.active,
            primaryCtaText: letbuyyComponentTokens.light.button.primary.text,
            secondaryAction: letbuyySemanticTokens.light.accent.brand,
            secondaryActionHover: letbuyySemanticTokens.light.accent.hover,
            secondaryActionSubtle: letbuyySemanticTokens.light.accent.subtle,
            critical: letbuyySemanticTokens.light.status.danger,
            criticalHover: primitive.color.red[600],
            criticalSoft: letbuyySemanticTokens.light.statusSoft.danger,
            warningSoft: letbuyySemanticTokens.light.statusSoft.warning,
            successSoft: letbuyySemanticTokens.light.statusSoft.success,
            infoSoft: letbuyySemanticTokens.light.statusSoft.info,
            focusRing: letbuyySemanticTokens.light.focusRing,
            overlay: letbuyySemanticTokens.light.overlay,
        },
        dark: {
            ...letbuyyColorTokens,
            bg: letbuyySemanticTokens.dark.background.page,
            background: letbuyySemanticTokens.dark.background.page,
            surface: letbuyySemanticTokens.dark.background.surface,
            surfaceRaised: letbuyySemanticTokens.dark.background.raised,
            surfaceSubdued: letbuyySemanticTokens.dark.background.subdued,
            card: letbuyySemanticTokens.dark.background.card,
            sidebar: letbuyySemanticTokens.dark.background.sidebar,
            header: letbuyySemanticTokens.dark.background.header,
            border: letbuyySemanticTokens.dark.border.default,
            borderSubtle: letbuyySemanticTokens.dark.border.subtle,
            borderDefault: letbuyySemanticTokens.dark.border.default,
            borderStrong: letbuyySemanticTokens.dark.border.strong,
            text: letbuyySemanticTokens.dark.text.primary,
            textPrimary: letbuyySemanticTokens.dark.text.primary,
            textSubdued: letbuyySemanticTokens.dark.text.secondary,
            textSecondary: letbuyySemanticTokens.dark.text.secondary,
            textMuted: letbuyySemanticTokens.dark.text.muted,
            textInverse: letbuyySemanticTokens.dark.text.inverse,
            primaryText: letbuyySemanticTokens.dark.accent.text,
            primarySoft: letbuyySemanticTokens.dark.accent.subtle,
            primaryCta: letbuyyComponentTokens.dark.button.primary.bg,
            primaryCtaHover: letbuyyComponentTokens.dark.button.primary.hover,
            primaryCtaActive: letbuyyComponentTokens.dark.button.primary.active,
            primaryCtaText: letbuyyComponentTokens.dark.button.primary.text,
            secondaryAction: letbuyySemanticTokens.dark.accent.brand,
            secondaryActionHover: letbuyySemanticTokens.dark.accent.hover,
            secondaryActionSubtle: letbuyySemanticTokens.dark.accent.subtle,
            critical: letbuyySemanticTokens.dark.status.danger,
            criticalHover: primitive.color.red[600],
            criticalSoft: letbuyySemanticTokens.dark.statusSoft.danger,
            warningSoft: letbuyySemanticTokens.dark.statusSoft.warning,
            successSoft: letbuyySemanticTokens.dark.statusSoft.success,
            infoSoft: letbuyySemanticTokens.dark.statusSoft.info,
            focusRing: letbuyySemanticTokens.dark.focusRing,
            overlay: letbuyySemanticTokens.dark.overlay,
        },
    },
    typography: {
        fontFamily: {
            body: letbuyyFontStacks.sans,
            display: letbuyyFontStacks.display,
            mono: letbuyyFontStacks.mono,
        },
        fontSize: {
            displayFluid: 'clamp(2.75rem, 2.1rem + 2vw, 3.5rem)',
            h1Fluid: 'clamp(1.75rem, 1.45rem + 0.9vw, 2rem)',
            h2Fluid: 'clamp(1.375rem, 1.18rem + 0.5vw, 1.5rem)',
            display: '32px',
            h1: '28px',
            h2: '24px',
            h3: '20px',
            h4: '18px',
            pageTitle: '24px',
            sectionTitle: '18px',
            cardTitle: '16px',
            bodyLarge: '16px',
            body: '14px',
            secondary: '13px',
            table: '13px',
            sidebar: '14px',
            emptyState: '14px',
            small: '13px',
            caption: '12px',
            badge: '12px',
            heading: '18px',
        },
        lineHeight: {
            displayFluid: '1.1',
            h1Fluid: '1.2',
            h2Fluid: '1.25',
            display: '40px',
            h1: '36px',
            h2: '32px',
            h3: '28px',
            h4: '24px',
            pageTitle: '32px',
            sectionTitle: '24px',
            cardTitle: '20px',
            bodyLarge: '24px',
            body: '20px',
            secondary: '18px',
            table: '18px',
            sidebar: '20px',
            emptyState: '20px',
            small: '18px',
            caption: '16px',
            badge: '16px',
            heading: '24px',
        },
        fontWeight: {
            regular: '400',
            medium: '500',
            semibold: '600',
            bold: '700',
        },
    },
    space: {
        none: '0',
        '2xs': '2px',
        xs: '4px',
        'xs-plus': '6px',
        sm: '8px',
        md: '12px',
        lg: '16px',
        xl: '20px',
        '2xl': '24px',
        '3xl': '32px',
        '4xl': '40px',
        '5xl': '48px',
        '6xl': '64px',
        '7xl': '96px',
    },
    radius: {
        sm: '4px',
        md: '8px',
        lg: '12px',
        xl: '16px',
        full: '999px',
    },
    shadow: letbuyyShadowTokens,
    motion: {
        duration: {
            hover: '150ms',
            menu: '150ms',
            carousel: '300ms',
            fast: '150ms',
            normal: '180ms',
            slow: '200ms',
        },
        easing: {
            standard: 'ease-out',
            out: 'ease-out',
            emphasized: 'cubic-bezier(0.16, 1, 0.3, 1)',
        },
        transform: {
            hoverLift: '2px',
            hoverScale: '1.01',
        },
    },
    size: {
        controlSm: 'var(--lb-density-icon-button-height)',
        controlMd: 'var(--lb-density-button-height)',
        controlLg: 'var(--lb-density-button-height-large)',
        icon: 'var(--lb-density-icon-button-height)',
        iconInline: 'var(--lb-density-action-icon-size)',
        pageHeaderHeight: 'var(--lb-density-header-height)',
        pageMax: '1440px',
        marketplaceContainer: '1200px',
        contentMeasure: '720px',
        emptyStateMeasure: '440px',
        saveBarWidth: '920px',
        skeletonCardHeight: '120px',
        emptyStateMinHeight: 'var(--lb-density-empty-state-min-height)',
        comboboxMenuMaxHeight: '280px',
        tooltipMaxWidth: '240px',
        metricSparklineWidth: '96px',
        metricSparklineHeight: '40px',
        chartHeightSm: '160px',
        chartHeightMd: '220px',
        chartHeightLg: '280px',
        tableRowHeight: 'var(--lb-density-table-row-height)',
        tableHeaderHeight: 'var(--lb-density-table-header-height)',
        tableToolbarHeight: 'var(--lb-density-action-bar-height)',
        commandPaletteWidth: '720px',
        commandPaletteListMaxHeight: '360px',
        commandPaletteOffset: '12vh',
    },
} as const;

function densityVariables(density: LetbuyyDensity): CssVariableMap {
    const values = letbuyyTokens.density[density];

    return {
        '--lb-density-sidebar-row-height': values.sidebarRowHeight,
        '--lb-density-input-height': values.inputHeight,
        '--lb-density-button-height': values.buttonHeight,
        '--lb-density-button-height-large': values.buttonHeightLarge,
        '--lb-density-icon-button-height': values.iconButtonHeight,
        '--lb-density-pill-height': values.pillHeight,
        '--lb-density-table-row-height': values.tableRowHeight,
        '--lb-density-table-header-height': values.tableHeaderHeight,
        '--lb-density-page-gap': values.pageGap,
        '--lb-density-section-gap': values.sectionGap,
        '--lb-density-card-gap': values.cardGap,
        '--lb-density-card-padding': values.cardPadding,
        '--lb-density-header-height': values.headerHeight,
        '--lb-density-action-bar-height': values.actionBarHeight,
        '--lb-density-modal-padding': values.modalPadding,
        '--lb-density-empty-state-scale': values.emptyStateScale,
        '--lb-density-empty-state-illustration-width': values.emptyStateIllustrationWidth,
        '--lb-density-empty-state-illustration-height': values.emptyStateIllustrationHeight,
        '--lb-density-empty-state-min-height': values.emptyStateMinHeight,
        '--lb-density-page-icon-size': values.iconPage,
        '--lb-density-sidebar-icon-size': values.iconSidebar,
        '--lb-density-sidebar-nested-spacing': values.nestedSpacing,
        '--lb-density-sidebar-section-spacing': values.sectionSpacing,
        '--lb-density-button-icon-size': values.iconButton,
        '--lb-density-table-icon-size': values.iconTable,
        '--lb-density-action-icon-size': values.iconAction,
    };
}

export const letbuyyDensityCssVariables = {
    compact: densityVariables('compact'),
    comfortable: densityVariables('comfortable'),
    spacious: densityVariables('spacious'),
} as const satisfies Record<LetbuyyDensity, CssVariableMap>;

const sharedCssVariables: CssVariableMap = {
    ...letbuyyDensityCssVariables.compact,
    '--lb-font-family-body': letbuyyTokens.typography.fontFamily.body,
    '--lb-font-family-display': letbuyyTokens.typography.fontFamily.display,
    '--lb-font-family-mono': letbuyyTokens.typography.fontFamily.mono,
    // Canonical type variables are role-based (`page-title`, `section-title`, `body`, etc.). Heading aliases (`h1`-`h4`) stay public for existing consumers.
    '--lb-font-size-display': letbuyyTokens.typography.fontSize.display,
    '--lb-font-size-display-fluid': letbuyyTokens.typography.fontSize.displayFluid,
    '--lb-font-size-h1-fluid': letbuyyTokens.typography.fontSize.h1Fluid,
    '--lb-font-size-h2-fluid': letbuyyTokens.typography.fontSize.h2Fluid,
    '--lb-font-size-h1': letbuyyTokens.typography.fontSize.h1,
    '--lb-font-size-h2': letbuyyTokens.typography.fontSize.h2,
    '--lb-font-size-h3': letbuyyTokens.typography.fontSize.h3,
    '--lb-font-size-h4': letbuyyTokens.typography.fontSize.h4,
    '--lb-font-size-page-title': letbuyyTokens.typography.fontSize.pageTitle,
    '--lb-font-size-section-title': letbuyyTokens.typography.fontSize.sectionTitle,
    '--lb-font-size-card-title': letbuyyTokens.typography.fontSize.cardTitle,
    '--lb-font-size-body-large': letbuyyTokens.typography.fontSize.bodyLarge,
    '--lb-font-size-heading': letbuyyTokens.typography.fontSize.heading,
    '--lb-font-size-body': letbuyyTokens.typography.fontSize.body,
    '--lb-font-size-secondary': letbuyyTokens.typography.fontSize.secondary,
    '--lb-font-size-table': letbuyyTokens.typography.fontSize.table,
    '--lb-font-size-sidebar': letbuyyTokens.typography.fontSize.sidebar,
    '--lb-font-size-empty-state': letbuyyTokens.typography.fontSize.emptyState,
    '--lb-font-size-small': letbuyyTokens.typography.fontSize.small,
    '--lb-font-size-caption': letbuyyTokens.typography.fontSize.caption,
    '--lb-font-size-badge': letbuyyTokens.typography.fontSize.badge,
    '--lb-line-height-display': letbuyyTokens.typography.lineHeight.display,
    '--lb-line-height-display-fluid': letbuyyTokens.typography.lineHeight.displayFluid,
    '--lb-line-height-h1-fluid': letbuyyTokens.typography.lineHeight.h1Fluid,
    '--lb-line-height-h2-fluid': letbuyyTokens.typography.lineHeight.h2Fluid,
    '--lb-line-height-h1': letbuyyTokens.typography.lineHeight.h1,
    '--lb-line-height-h2': letbuyyTokens.typography.lineHeight.h2,
    '--lb-line-height-h3': letbuyyTokens.typography.lineHeight.h3,
    '--lb-line-height-h4': letbuyyTokens.typography.lineHeight.h4,
    '--lb-line-height-page-title': letbuyyTokens.typography.lineHeight.pageTitle,
    '--lb-line-height-section-title': letbuyyTokens.typography.lineHeight.sectionTitle,
    '--lb-line-height-card-title': letbuyyTokens.typography.lineHeight.cardTitle,
    '--lb-line-height-body-large': letbuyyTokens.typography.lineHeight.bodyLarge,
    '--lb-line-height-heading': letbuyyTokens.typography.lineHeight.heading,
    '--lb-line-height-body': letbuyyTokens.typography.lineHeight.body,
    '--lb-line-height-secondary': letbuyyTokens.typography.lineHeight.secondary,
    '--lb-line-height-table': letbuyyTokens.typography.lineHeight.table,
    '--lb-line-height-sidebar': letbuyyTokens.typography.lineHeight.sidebar,
    '--lb-line-height-empty-state': letbuyyTokens.typography.lineHeight.emptyState,
    '--lb-line-height-small': letbuyyTokens.typography.lineHeight.small,
    '--lb-line-height-caption': letbuyyTokens.typography.lineHeight.caption,
    '--lb-line-height-badge': letbuyyTokens.typography.lineHeight.badge,
    '--lb-font-weight-regular': letbuyyTokens.typography.fontWeight.regular,
    '--lb-font-weight-medium': letbuyyTokens.typography.fontWeight.medium,
    '--lb-font-weight-semibold': letbuyyTokens.typography.fontWeight.semibold,
    '--lb-font-weight-bold': letbuyyTokens.typography.fontWeight.bold,
    // Canonical spacing variables are the numeric `--lb-space-*` scale. The named `xs`/`sm`/`md`/`lg`/`xl` variables remain public aliases for compatibility.
    '--lb-space-0': letbuyyTokens.space.none,
    '--lb-space-1': letbuyyTokens.space.xs,
    '--lb-space-2': letbuyyTokens.space.sm,
    '--lb-space-3': letbuyyTokens.space.md,
    '--lb-space-4': letbuyyTokens.space.lg,
    '--lb-space-5': letbuyyTokens.space.xl,
    '--lb-space-6': letbuyyTokens.space['2xl'],
    '--lb-space-7': letbuyyTokens.space['3xl'],
    '--lb-space-8': letbuyyTokens.space['4xl'],
    '--lb-space-9': letbuyyTokens.space['5xl'],
    '--lb-space-10': letbuyyTokens.space['6xl'],
    '--lb-space-11': letbuyyTokens.space['7xl'],
    '--lb-space-xs': letbuyyTokens.space.xs,
    '--lb-space-sm': letbuyyTokens.space.sm,
    '--lb-space-md': letbuyyTokens.space.md,
    '--lb-space-lg': letbuyyTokens.space.lg,
    '--lb-space-xl': letbuyyTokens.space.xl,
    '--lb-bp-sm': letbuyyTokens.breakpoint.sm,
    '--lb-bp-xs': letbuyyTokens.breakpoint.xs,
    '--lb-bp-mobile': letbuyyTokens.breakpoint.mobile,
    '--lb-bp-md': letbuyyTokens.breakpoint.md,
    '--lb-bp-lg': letbuyyTokens.breakpoint.lg,
    '--lb-bp-xl': letbuyyTokens.breakpoint.xl,
    '--lb-bp-tablet': letbuyyTokens.breakpoint.md,
    '--lb-bp-desktop': letbuyyTokens.breakpoint.lg,
    '--lb-bp-wide': letbuyyTokens.breakpoint.xl,
    '--lb-radius-sm': letbuyyTokens.radius.sm,
    '--lb-radius-md': letbuyyTokens.radius.md,
    '--lb-radius-lg': letbuyyTokens.radius.lg,
    '--lb-radius-xl': letbuyyTokens.radius.xl,
    '--lb-radius-full': letbuyyTokens.radius.full,
    '--lb-shadow-sm': letbuyyTokens.shadow.sm,
    '--lb-shadow-md': letbuyyTokens.shadow.md,
    '--lb-shadow-lg': letbuyyTokens.shadow.lg,
    '--lb-shadow-card-light': letbuyyTokens.shadow.cardLight,
    '--lb-shadow-card-dark': letbuyyTokens.shadow.cardDark,
    '--lb-z-base': letbuyyZIndexTokens.base,
    '--lb-z-dropdown': letbuyyZIndexTokens.dropdown,
    '--lb-z-sticky': letbuyyZIndexTokens.sticky,
    '--lb-z-overlay': letbuyyZIndexTokens.overlay,
    '--lb-z-modal': letbuyyZIndexTokens.modal,
    '--lb-z-toast': letbuyyZIndexTokens.toast,
    '--lb-z-tooltip': letbuyyZIndexTokens.tooltip,
    '--lb-motion-fast': letbuyyTokens.motion.duration.fast,
    '--lb-motion-hover': letbuyyTokens.motion.duration.hover,
    '--lb-motion-menu': letbuyyTokens.motion.duration.menu,
    '--lb-motion-carousel': letbuyyTokens.motion.duration.carousel,
    '--lb-motion-normal': letbuyyTokens.motion.duration.normal,
    '--lb-motion-slow': letbuyyTokens.motion.duration.slow,
    '--lb-ease-standard': letbuyyTokens.motion.easing.standard,
    '--lb-ease-out': letbuyyTokens.motion.easing.out,
    '--lb-ease-emphasized': letbuyyTokens.motion.easing.emphasized,
    '--lb-motion-hover-lift': letbuyyTokens.motion.transform.hoverLift,
    '--lb-motion-hover-scale': letbuyyTokens.motion.transform.hoverScale,
    '--lb-size-control-sm': letbuyyTokens.size.controlSm,
    '--lb-size-control-md': letbuyyTokens.size.controlMd,
    '--lb-size-control-lg': letbuyyTokens.size.controlLg,
    '--lb-size-icon': letbuyyTokens.size.icon,
    '--lb-size-icon-inline': letbuyyTokens.size.iconInline,
    '--lb-size-page-header-height': letbuyyTokens.size.pageHeaderHeight,
    '--lb-size-page-max': letbuyyTokens.size.pageMax,
    '--lb-size-marketplace-container': letbuyyTokens.size.marketplaceContainer,
    '--lb-size-content-measure': letbuyyTokens.size.contentMeasure,
    '--lb-size-empty-state-measure': letbuyyTokens.size.emptyStateMeasure,
    '--lb-size-save-bar-width': letbuyyTokens.size.saveBarWidth,
    '--lb-size-skeleton-card-height': letbuyyTokens.size.skeletonCardHeight,
    '--lb-size-empty-state-min-height': letbuyyTokens.size.emptyStateMinHeight,
    '--lb-size-combobox-menu-max-height': letbuyyTokens.size.comboboxMenuMaxHeight,
    '--lb-size-tooltip-max-width': letbuyyTokens.size.tooltipMaxWidth,
    '--lb-size-metric-sparkline-width': letbuyyTokens.size.metricSparklineWidth,
    '--lb-size-metric-sparkline-height': letbuyyTokens.size.metricSparklineHeight,
    '--lb-size-chart-height-sm': letbuyyTokens.size.chartHeightSm,
    '--lb-size-chart-height-md': letbuyyTokens.size.chartHeightMd,
    '--lb-size-chart-height-lg': letbuyyTokens.size.chartHeightLg,
    '--lb-size-table-row-height': letbuyyTokens.size.tableRowHeight,
    '--lb-size-table-header-height': letbuyyTokens.size.tableHeaderHeight,
    '--lb-size-table-toolbar-height': letbuyyTokens.size.tableToolbarHeight,
    '--lb-size-command-palette-width': letbuyyTokens.size.commandPaletteWidth,
    '--lb-size-command-palette-list-max-height': letbuyyTokens.size.commandPaletteListMaxHeight,
    '--lb-size-command-palette-offset': letbuyyTokens.size.commandPaletteOffset,
};

function kebabCase(value: string) {
    return value.replace(/[A-Z]/g, (match) => `-${match.toLowerCase()}`).toLowerCase();
}

function appendTokenVariables(target: CssVariableMap, prefix: string[], tokens: unknown) {
    if (typeof tokens === 'string') {
        target[`--${prefix.join('-')}` as `--${string}`] = tokens;
        return;
    }

    if (typeof tokens !== 'object' || tokens === null) return;

    for (const [key, value] of Object.entries(tokens as Record<string, unknown>)) {
        appendTokenVariables(target, [...prefix, kebabCase(key)], value);
    }
}

function colorVariables(theme: LetbuyyTheme): CssVariableMap {
    const colors = letbuyyTokens.color[theme];
    const semantic = letbuyyTokens.semantic[theme];
    const component = letbuyyTokens.component[theme];

    const variables: CssVariableMap = {
        '--lb-color-brand-purple': colors.brandPurple,
        '--lb-color-background-light': colors.backgroundLight,
        '--lb-color-background-dark': colors.backgroundDark,
        '--lb-color-surface-light': colors.surfaceLight,
        '--lb-color-surface-dark': colors.surfaceDark,
        '--lb-color-text-primary-light': colors.textPrimaryLight,
        '--lb-color-text-primary-dark': colors.textPrimaryDark,
        '--lb-color-text-secondary-light': colors.textSecondaryLight,
        '--lb-color-text-secondary-dark': colors.textSecondaryDark,
        '--lb-color-border-light': colors.borderLight,
        '--lb-color-border-dark': colors.borderDark,
        '--lb-color-bg': colors.bg,
        '--lb-color-background': colors.bg,
        '--lb-color-surface': colors.surface,
        '--lb-color-surface-raised': colors.surfaceRaised,
        '--lb-color-surface-subdued': colors.surfaceSubdued,
        '--lb-color-card': colors.card,
        '--lb-color-sidebar': colors.sidebar,
        '--lb-sidebar-bg': colors.sidebar,
        '--lb-content-bg': colors.bg,
        '--lb-card-bg': colors.card,
        '--lb-color-header': colors.header,
        '--lb-color-border': colors.border,
        '--lb-color-border-strong': colors.borderStrong,
        '--lb-color-text': colors.text,
        '--lb-color-text-subdued': colors.textSubdued,
        '--lb-color-text-muted': colors.textMuted,
        '--lb-color-text-inverse': colors.textInverse,
        '--lb-color-primary': colors.primary,
        '--lb-color-primary-text': colors.primaryText,
        '--lb-color-primary-hover': colors.primaryHover,
        '--lb-color-primary-active': colors.primaryActive,
        '--lb-color-primary-subtle': colors.primarySubtle,
        '--lb-color-primary-soft': colors.primarySoft,
        '--lb-color-primary-cta': colors.primaryCta,
        '--lb-color-primary-cta-hover': colors.primaryCtaHover,
        '--lb-color-primary-cta-active': colors.primaryCtaActive,
        '--lb-color-primary-cta-text': colors.primaryCtaText,
        '--lb-color-secondary-action': colors.secondaryAction,
        '--lb-color-secondary-action-hover': colors.secondaryActionHover,
        '--lb-color-secondary-action-subtle': colors.secondaryActionSubtle,
        '--lb-color-critical': colors.critical,
        '--lb-color-critical-hover': colors.criticalHover,
        '--lb-color-critical-soft': colors.criticalSoft,
        '--lb-color-warning': colors.warning,
        '--lb-color-warning-soft': colors.warningSoft,
        '--lb-color-success': colors.success,
        '--lb-color-success-soft': colors.successSoft,
        '--lb-color-info': colors.info,
        '--lb-color-info-soft': colors.infoSoft,
        '--lb-color-focus-ring': colors.focusRing,
        '--lb-color-overlay': colors.overlay,
        '--lb-shadow-card': theme === 'light' ? letbuyyShadowTokens.cardLight : letbuyyShadowTokens.cardDark,
    };

    appendTokenVariables(variables, ['lb', 'primitive'], letbuyyTokens.primitive);
    appendTokenVariables(variables, ['lb', 'semantic'], semantic);
    appendTokenVariables(variables, ['lb', 'component'], component);
    deprecatedTokenAliasVariables.forEach((alias) => {
        delete variables[alias as `--${string}`];
    });

    return variables;
}

/**
 * Per-surface colour identity.
 *
 * `letbuyySurfaceTokens` is emitted under `[data-letbuyy-surface="…"][data-letbuyy-theme="…"]`
 * (specificity 0,2,0), i.e. one selector step above the `:root` block (0,1,0) inside the
 * SAME generated stylesheet. That is the sanctioned place for a surface to differ — an app
 * must never re-declare `--lb-color-primary` from its own stylesheet to win a cascade race
 * against the injected tokens (DOC 03 §35: one token source).
 *
 * Admin and operations own their colour identities here. Other surfaces retain
 * the shared defaults.
 */
const adminSurfaceIdentity: Record<LetbuyyTheme, CssVariableMap> = {
    light: {
        // The rail IS the brand. Primary, CTA and navigation all resolve to brandInk[800].
        '--lb-color-primary': primitive.color.brandInk[800],
        '--lb-color-primary-hover': primitive.color.brandInk[700],
        '--lb-color-primary-active': primitive.color.brandInk[850],
        // Primary used AS TEXT on a light surface (links, badge labels) — not text ON primary.
        '--lb-color-primary-text': primitive.color.brandInk[700],
        '--lb-color-primary-subtle': `color-mix(in srgb, ${primitive.color.brandInk[800]} 10%, transparent)`,
        '--lb-color-primary-soft': `color-mix(in srgb, ${primitive.color.brandInk[800]} 6%, transparent)`,
        '--lb-color-secondary-action': primitive.color.brandInk[700],
        '--lb-color-secondary-action-hover': primitive.color.brandInk[800],
        '--lb-color-secondary-action-subtle': `color-mix(in srgb, ${primitive.color.brandInk[800]} 10%, transparent)`,
        // Distinct from primary so the ring stays legible where primary is the background.
        '--lb-color-focus-ring': primitive.color.brandInk[600],

        '--lb-color-primary-cta': primitive.color.brandInk[800],
        '--lb-color-primary-cta-hover': primitive.color.brandInk[700],
        '--lb-color-primary-cta-active': primitive.color.brandInk[850],
        '--lb-color-primary-cta-text': primitive.color.white,

        '--lb-component-button-primary-bg': primitive.color.brandInk[800],
        '--lb-component-button-primary-hover': primitive.color.brandInk[700],
        '--lb-component-button-primary-active': primitive.color.brandInk[850],
        '--lb-component-button-primary-text': primitive.color.white,
        '--lb-component-button-primary-border': primitive.color.brandInk[800],
        // Quiet member of the same family: a 5% ink wash, never a second filled button.
        '--lb-component-button-secondary-bg': `color-mix(in srgb, ${primitive.color.brandInk[800]} 5%, ${primitive.color.white})`,
        '--lb-component-button-secondary-hover': `color-mix(in srgb, ${primitive.color.brandInk[800]} 10%, ${primitive.color.white})`,
        '--lb-component-button-secondary-text': primitive.color.gray[900],
        '--lb-component-button-secondary-border': `color-mix(in srgb, ${primitive.color.brandInk[800]} 22%, ${primitive.color.white})`,

        '--lb-component-input-focus-border': primitive.color.brandInk[600],
        '--lb-component-input-focus-ring': `color-mix(in srgb, ${primitive.color.brandInk[600]} 18%, transparent)`,

        // Accent-tinted chrome must follow the accent. Left on the shared ramp these
        // render stock violet directly beside an ink CTA — the exact "two primaries"
        // clash this identity exists to remove.
        '--lb-component-badge-accent-bg': `color-mix(in srgb, ${primitive.color.brandInk[800]} 10%, transparent)`,
        '--lb-component-badge-accent-text': primitive.color.brandInk[700],
        '--lb-component-badge-accent-border': `color-mix(in srgb, ${primitive.color.brandInk[800]} 30%, transparent)`,
        '--lb-component-empty-state-illustration-bg': `color-mix(in srgb, ${primitive.color.brandInk[800]} 10%, transparent)`,
        '--lb-component-empty-state-illustration-ink': primitive.color.brandInk[700],

        // A dark rail beneath a light page: text tokens come from the sidebar contract,
        // so no subtree needs to re-point --lb-color-text.
        '--lb-component-sidebar-bg': primitive.color.brandInk[800],
        '--lb-component-sidebar-border': primitive.color.brandInk[850],
        '--lb-component-sidebar-text': primitive.color.white,
        '--lb-component-sidebar-text-subdued': primitive.color.brandInk[200],
        '--lb-component-sidebar-section-text': primitive.color.brandInk[300],
        '--lb-component-sidebar-active-text': primitive.color.white,
        '--lb-component-sidebar-active-bg': 'rgb(255 255 255 / 12%)',
        '--lb-component-sidebar-hover-bg': 'rgb(255 255 255 / 6%)',
        '--lb-component-sidebar-active-ring': 'inset 0 0 0 1px rgb(255 255 255 / 14%)',
        '--lb-component-sidebar-rail-color': primitive.color.brandInk[300],
        '--lb-component-sidebar-child-rail': 'rgb(255 255 255 / 16%)',
    },
    dark: {
        // On a near-black canvas the anchor itself would read as an unlit slab, so dark
        // steps UP the same hue instead of across to a different one.
        '--lb-color-primary': primitive.color.brandInk[400],
        '--lb-color-primary-hover': `color-mix(in srgb, ${primitive.color.white} 10%, ${primitive.color.brandInk[400]})`,
        '--lb-color-primary-active': primitive.color.brandInk[500],
        '--lb-color-primary-text': primitive.color.brandInk[200],
        '--lb-color-primary-subtle': `color-mix(in srgb, ${primitive.color.brandInk[400]} 20%, transparent)`,
        '--lb-color-primary-soft': `color-mix(in srgb, ${primitive.color.brandInk[400]} 12%, transparent)`,
        '--lb-color-secondary-action': primitive.color.brandInk[300],
        '--lb-color-secondary-action-hover': primitive.color.brandInk[200],
        '--lb-color-secondary-action-subtle': `color-mix(in srgb, ${primitive.color.brandInk[400]} 20%, transparent)`,
        '--lb-color-focus-ring': primitive.color.brandInk[300],

        '--lb-color-primary-cta': primitive.color.brandInk[400],
        '--lb-color-primary-cta-hover': `color-mix(in srgb, ${primitive.color.white} 10%, ${primitive.color.brandInk[400]})`,
        '--lb-color-primary-cta-active': primitive.color.brandInk[500],
        '--lb-color-primary-cta-text': primitive.color.white,

        '--lb-component-button-primary-bg': primitive.color.brandInk[400],
        '--lb-component-button-primary-hover': `color-mix(in srgb, ${primitive.color.white} 10%, ${primitive.color.brandInk[400]})`,
        '--lb-component-button-primary-active': primitive.color.brandInk[500],
        '--lb-component-button-primary-text': primitive.color.white,
        '--lb-component-button-primary-border': primitive.color.brandInk[400],
        '--lb-component-button-secondary-bg': `color-mix(in srgb, ${primitive.color.brandInk[400]} 14%, ${primitive.color.ink[800]})`,
        '--lb-component-button-secondary-hover': `color-mix(in srgb, ${primitive.color.brandInk[400]} 22%, ${primitive.color.ink[800]})`,
        '--lb-component-button-secondary-text': primitive.color.white,
        '--lb-component-button-secondary-border': `color-mix(in srgb, ${primitive.color.brandInk[400]} 34%, ${primitive.color.ink[800]})`,

        '--lb-component-input-focus-border': primitive.color.brandInk[300],
        '--lb-component-input-focus-ring': `color-mix(in srgb, ${primitive.color.brandInk[300]} 22%, transparent)`,

        '--lb-component-badge-accent-bg': `color-mix(in srgb, ${primitive.color.brandInk[400]} 20%, transparent)`,
        '--lb-component-badge-accent-text': primitive.color.brandInk[200],
        '--lb-component-badge-accent-border': `color-mix(in srgb, ${primitive.color.brandInk[400]} 40%, transparent)`,
        '--lb-component-empty-state-illustration-bg': `color-mix(in srgb, ${primitive.color.brandInk[400]} 20%, transparent)`,
        '--lb-component-empty-state-illustration-ink': primitive.color.brandInk[300],

        '--lb-component-sidebar-bg': primitive.color.brandInk[900],
        '--lb-component-sidebar-border': primitive.color.brandInk[850],
        '--lb-component-sidebar-text': primitive.color.white,
        '--lb-component-sidebar-text-subdued': primitive.color.brandInk[200],
        '--lb-component-sidebar-section-text': primitive.color.brandInk[300],
        '--lb-component-sidebar-active-text': primitive.color.white,
        '--lb-component-sidebar-active-bg': `color-mix(in srgb, ${primitive.color.brandInk[400]} 22%, transparent)`,
        '--lb-component-sidebar-hover-bg': 'rgb(255 255 255 / 5%)',
        '--lb-component-sidebar-active-ring': `inset 0 0 0 1px color-mix(in srgb, ${primitive.color.brandInk[300]} 28%, transparent)`,
        '--lb-component-sidebar-rail-color': primitive.color.brandInk[300],
        '--lb-component-sidebar-child-rail': 'rgb(255 255 255 / 14%)',
    },
};

function operationsIdentity(theme: LetbuyyTheme): CssVariableMap {
    const dark = theme === 'dark';
    const neutral = primitive.color.porcelain;
    const wine = primitive.color.burgundy;
    const bg = dark ? neutral[950] : neutral[100];
    const surface = dark ? neutral[850] : primitive.color.white;
    const raised = dark ? neutral[800] : primitive.color.white;
    const subdued = dark ? neutral[900] : neutral[50];
    const border = dark ? neutral[750] : neutral[200];
    const text = dark ? neutral[100] : neutral.text;
    const muted = dark ? neutral[400] : neutral[500];
    const accent = dark ? wine[300] : wine[700];
    const sidebar = dark ? wine[950] : wine[900];
    const sidebarActive = dark ? wine[900] : wine[850];
    const accentText = dark ? wine[300] : wine[800];
    const accentWash = `color-mix(in srgb, ${accent} ${dark ? 12 : 8}%, ${surface})`;
    const cta = wine[700];

    return {
        '--lb-color-bg': bg, '--lb-color-background': bg, '--lb-content-bg': bg,
        '--lb-color-surface': surface, '--lb-color-surface-raised': raised,
        '--lb-color-surface-subdued': subdued, '--lb-color-card': surface, '--lb-card-bg': surface,
        '--lb-color-header': dark ? neutral[900] : primitive.color.white,
        '--lb-color-sidebar': sidebar,
        '--lb-sidebar-bg': sidebar,
        '--lb-color-border': border, '--lb-color-text': text, '--lb-color-text-subdued': muted,
        '--lb-color-text-muted': muted,
        '--lb-color-primary': accent, '--lb-color-primary-text': accentText,
        '--lb-color-primary-hover': dark ? wine[200] : wine[800],
        '--lb-color-primary-active': dark ? wine[400] : wine[900],
        '--lb-color-primary-subtle': accentWash, '--lb-color-primary-soft': accentWash,
        '--lb-color-primary-cta': cta, '--lb-color-primary-cta-hover': wine[800],
        '--lb-color-primary-cta-active': wine[900], '--lb-color-primary-cta-text': primitive.color.white,
        '--lb-color-secondary-action': accentText, '--lb-color-secondary-action-hover': accent,
        '--lb-color-secondary-action-subtle': accentWash,
        '--lb-color-focus-ring': dark ? wine[300] : wine[500],
        '--lb-component-card-bg': surface, '--lb-component-card-text': text, '--lb-component-card-border': border,
        '--lb-component-table-bg': surface, '--lb-component-table-header-bg': subdued,
        '--lb-component-table-row-hover-bg': subdued, '--lb-component-table-border': border,
        '--lb-component-table-text': text, '--lb-component-table-text-secondary': muted,
        '--lb-component-button-primary-bg': cta, '--lb-component-button-primary-hover': wine[800],
        '--lb-component-button-primary-active': wine[900], '--lb-component-button-primary-text': primitive.color.white,
        '--lb-component-button-primary-border': cta,
        '--lb-component-button-secondary-bg': surface, '--lb-component-button-secondary-hover': subdued,
        '--lb-component-button-secondary-text': text, '--lb-component-button-secondary-border': border,
        // White status copy needs a darker solid fill than the shared 600-tier ramp.
        '--lb-component-badge-solid-default-bg': cta,
        '--lb-component-badge-solid-success-bg': primitive.color.green[700],
        '--lb-component-badge-solid-warning-bg': primitive.color.amber[800],
        '--lb-component-banner-solid-success-bg': primitive.color.green[700],
        '--lb-component-banner-solid-warning-bg': primitive.color.amber[800],
        '--lb-component-toast-success-bg': primitive.color.green[700],
        '--lb-component-toast-warning-bg': primitive.color.amber[800],
        '--lb-component-input-bg': surface, '--lb-component-input-text': text, '--lb-component-input-border': border,
        '--lb-component-input-focus-border': accent,
        '--lb-component-input-focus-ring': `color-mix(in srgb, ${accent} 20%, transparent)`,
        '--lb-component-empty-state-bg': subdued, '--lb-component-empty-state-border': border,
        '--lb-component-empty-state-illustration-bg': accentWash, '--lb-component-empty-state-illustration-ink': accentText,
        '--lb-component-empty-state-title': text, '--lb-component-empty-state-body': muted,
        '--lb-component-badge-accent-bg': accentWash, '--lb-component-badge-accent-text': accentText,
        '--lb-component-badge-accent-border': `color-mix(in srgb, ${accent} 22%, ${surface})`,
        '--lb-component-sidebar-bg': sidebar,
        '--lb-component-sidebar-border': dark ? wine[900] : wine[850],
        '--lb-component-sidebar-text': neutral[100],
        '--lb-component-sidebar-text-subdued': wine[200], '--lb-component-sidebar-section-text': wine[200],
        '--lb-component-sidebar-active-text': primitive.color.white, '--lb-component-sidebar-active-bg': sidebarActive,
        '--lb-component-sidebar-hover-bg': sidebarActive,
        '--lb-component-sidebar-active-ring': 'none', '--lb-component-sidebar-rail-color': wine[300],
        '--lb-component-sidebar-child-rail': wine[850],
        '--lb-component-page-header-icon-bg': accentWash, '--lb-component-page-header-icon-text': accentText,
        '--lb-component-page-header-icon-border': border,
    };
}

const letbuyySurfaceIdentities: Partial<Record<LetbuyySurface, Record<LetbuyyTheme, CssVariableMap>>> = {
    admin: adminSurfaceIdentity,
    operations: { light: operationsIdentity('light'), dark: operationsIdentity('dark') },
};

function surfaceVariables(surface: LetbuyySurface, theme: LetbuyyTheme): CssVariableMap {
    const colors = letbuyyTokens.color[theme];
    const component = letbuyyTokens.component[theme];

    return {
        '--lb-color-bg': colors.bg,
        '--lb-color-background': colors.bg,
        '--lb-color-surface': colors.surface,
        '--lb-color-surface-raised': colors.surfaceRaised,
        '--lb-color-surface-subdued': colors.surfaceSubdued,
        '--lb-color-card': colors.card,
        '--lb-card-bg': colors.card,
        '--lb-content-bg': colors.bg,
        '--lb-color-sidebar': colors.sidebar,
        '--lb-sidebar-bg': colors.sidebar,
        '--lb-color-header': colors.header,
        '--lb-color-border': colors.border,
        '--lb-color-text': colors.text,
        '--lb-color-text-subdued': colors.textSubdued,
        '--lb-color-primary': colors.primary,
        '--lb-color-primary-text': colors.primaryText,
        '--lb-color-primary-hover': colors.primaryHover,
        '--lb-color-primary-active': colors.primaryActive,
        '--lb-color-primary-subtle': colors.primarySubtle,
        '--lb-color-primary-soft': colors.primarySoft,
        '--lb-color-primary-cta': colors.primaryCta,
        '--lb-color-primary-cta-hover': colors.primaryCtaHover,
        '--lb-color-primary-cta-active': colors.primaryCtaActive,
        '--lb-color-primary-cta-text': colors.primaryCtaText,
        '--lb-color-secondary-action': colors.secondaryAction,
        '--lb-color-secondary-action-hover': colors.secondaryActionHover,
        '--lb-color-secondary-action-subtle': colors.secondaryActionSubtle,
        '--lb-color-focus-ring': colors.focusRing,
        '--lb-component-card-bg': component.card.bg,
        '--lb-component-card-text': component.card.text,
        '--lb-component-card-border': component.card.border,
        '--lb-component-card-radius': component.card.radius,
        '--lb-component-card-shadow': component.card.shadow,
        '--lb-component-button-primary-bg': component.button.primary.bg,
        '--lb-component-button-primary-hover': component.button.primary.hover,
        '--lb-component-button-primary-active': component.button.primary.active,
        '--lb-component-button-primary-text': component.button.primary.text,
        '--lb-component-button-primary-border': component.button.primary.border,
        '--lb-component-button-secondary-bg': component.button.secondary.bg,
        '--lb-component-button-secondary-hover': component.button.secondary.hover,
        '--lb-component-button-secondary-text': component.button.secondary.text,
        '--lb-component-button-secondary-border': component.button.secondary.border,
        '--lb-component-empty-state-bg': component.emptyState.bg,
        '--lb-component-empty-state-border': component.emptyState.border,
        '--lb-component-empty-state-title': component.emptyState.title,
        '--lb-component-empty-state-body': component.emptyState.body,
        '--lb-component-badge-accent-bg': component.badge.accentBg,
        '--lb-component-badge-accent-text': component.badge.accentText,
        '--lb-component-badge-accent-border': component.badge.accentBorder,
        '--lb-component-banner-info-bg': component.banner.infoBg,
        '--lb-component-banner-info-text': component.banner.infoText,
        '--lb-component-banner-info-border': component.banner.infoBorder,
        '--lb-component-banner-success-bg': component.banner.successBg,
        '--lb-component-banner-success-text': component.banner.successText,
        '--lb-component-banner-success-border': component.banner.successBorder,
        '--lb-component-banner-warning-bg': component.banner.warningBg,
        '--lb-component-banner-warning-text': component.banner.warningText,
        '--lb-component-banner-warning-border': component.banner.warningBorder,
        '--lb-component-banner-danger-bg': component.banner.dangerBg,
        '--lb-component-banner-danger-text': component.banner.dangerText,
        '--lb-component-banner-danger-border': component.banner.dangerBorder,
        '--lb-component-toast-info-bg': component.toast.infoBg,
        '--lb-component-toast-success-bg': component.toast.successBg,
        '--lb-component-toast-warning-bg': component.toast.warningBg,
        '--lb-component-toast-danger-bg': component.toast.dangerBg,
        '--lb-component-toast-text': component.toast.text,
        '--lb-component-toast-icon-bg': component.toast.iconBg,
        '--lb-component-toast-close-hover': component.toast.closeHover,
        '--lb-component-banner-solid-info-bg': component.bannerSolid.infoBg,
        '--lb-component-banner-solid-success-bg': component.bannerSolid.successBg,
        '--lb-component-banner-solid-warning-bg': component.bannerSolid.warningBg,
        '--lb-component-banner-solid-danger-bg': component.bannerSolid.dangerBg,
        '--lb-component-banner-solid-text': component.bannerSolid.text,
        '--lb-component-banner-solid-action-bg': component.bannerSolid.actionBg,
        '--lb-component-banner-solid-action-border': component.bannerSolid.actionBorder,
        '--lb-component-banner-solid-action-text': component.bannerSolid.actionText,
        '--lb-component-banner-solid-action-hover': component.bannerSolid.actionHover,
        '--lb-component-badge-solid-default-bg': component.badgeSolid.defaultBg,
        '--lb-component-badge-solid-info-bg': component.badgeSolid.infoBg,
        '--lb-component-badge-solid-success-bg': component.badgeSolid.successBg,
        '--lb-component-badge-solid-warning-bg': component.badgeSolid.warningBg,
        '--lb-component-badge-solid-danger-bg': component.badgeSolid.dangerBg,
        '--lb-component-badge-solid-text': component.badgeSolid.text,
        '--lb-component-input-bg': component.input.bg,
        '--lb-component-input-text': component.input.text,
        '--lb-component-input-border': component.input.border,
        '--lb-component-input-focus-border': component.input.focusBorder,
        '--lb-component-input-focus-ring': component.input.focusRing,
        // Emitted per surface so a surface identity can run its own navigation rail.
        // `--lb-component-sidebar-text{,-subdued}` are deliberately NOT emitted here:
        // they exist only where a surface actually needs them (a dark rail under a
        // light page). Consumers read them with a `var(…, var(--lb-color-text))`
        // fallback, so surfaces without them are byte-identical to before — and the
        // shared token contract gains no new duplicate-value aliases.
        '--lb-component-sidebar-bg': component.sidebar.bg,
        '--lb-component-sidebar-border': component.sidebar.border,
        '--lb-component-sidebar-section-text': component.sidebar.sectionText,
        '--lb-component-sidebar-active-text': component.sidebar.activeText,
        '--lb-component-sidebar-active-bg': component.sidebar.activeBg,
        '--lb-component-sidebar-hover-bg': component.sidebar.hoverBg,
        '--lb-component-sidebar-active-ring': component.sidebar.activeRing,
        '--lb-component-sidebar-rail-color': component.sidebar.railColor,
        '--lb-component-sidebar-child-rail': component.sidebar.childRail,
        // NOTE: --lb-component-sidebar-item-radius is deliberately NOT emitted here.
        // It is layout, not colour, and apps legitimately tune it from their own
        // stylesheet; emitting it at surface specificity (0,2,0) would silently
        // outrank those app-level values.
        '--lb-component-page-header-height': component.pageHeader.height,
        '--lb-component-page-header-title-size': component.pageHeader.titleSize,
        '--lb-component-page-header-title-line-height': component.pageHeader.titleLineHeight,
        '--lb-component-page-header-icon-size': component.pageHeader.iconSize,
        '--lb-component-page-header-icon-bg': component.pageHeader.iconBg,
        '--lb-component-page-header-icon-text': component.pageHeader.iconText,
        '--lb-component-page-header-icon-fill': component.pageHeader.iconFill,
        '--lb-component-page-header-icon-stroke-width': component.pageHeader.iconStrokeWidth,
        '--lb-component-page-header-icon-border': component.pageHeader.iconBorder,
        // A surface identity wins over the shared defaults it overlays, and only over
        // the keys it names.
        ...(letbuyySurfaceIdentities[surface]?.[theme] ?? {}),
    };
}

const letbuyySurfaceNames = ['admin', 'marketplace', 'storefront', 'identity', 'operations'] as const satisfies readonly LetbuyySurface[];

export const letbuyySurfaceTokens = Object.fromEntries(
    letbuyySurfaceNames.map((surface) => [
        surface,
        {
            light: surfaceVariables(surface, 'light'),
            dark: surfaceVariables(surface, 'dark'),
        },
    ]),
) as Record<LetbuyySurface, Record<LetbuyyTheme, CssVariableMap>>;

function parseHexColor(color: string) {
    const normalized = color.trim().replace('#', '');
    if (!/^[0-9a-fA-F]{6}$/.test(normalized)) return undefined;
    return {
        r: Number.parseInt(normalized.slice(0, 2), 16),
        g: Number.parseInt(normalized.slice(2, 4), 16),
        b: Number.parseInt(normalized.slice(4, 6), 16),
    };
}

function relativeLuminance(color: string) {
    const rgb = parseHexColor(color);
    if (!rgb) return undefined;
    const channels = [rgb.r, rgb.g, rgb.b].map((channel) => {
        const value = channel / 255;
        return value <= 0.03928 ? value / 12.92 : ((value + 0.055) / 1.055) ** 2.4;
    });
    return channels[0] * 0.2126 + channels[1] * 0.7152 + channels[2] * 0.0722;
}

function contrastRatio(foreground: string, background: string) {
    const foregroundLuminance = relativeLuminance(foreground);
    const backgroundLuminance = relativeLuminance(background);
    if (foregroundLuminance === undefined || backgroundLuminance === undefined) return undefined;
    const lighter = Math.max(foregroundLuminance, backgroundLuminance);
    const darker = Math.min(foregroundLuminance, backgroundLuminance);
    return (lighter + 0.05) / (darker + 0.05);
}

export function validateLetbuyyBrandContrast(brand: LetbuyyBrandInput): LetbuyyBrandContrastCheck[] {
    const variables = createLetbuyyBrandVariables(brand);
    const checks: Array<Omit<LetbuyyBrandContrastCheck, 'ratio' | 'passes'>> = [
        {
            token: '--lb-color-primary-text',
            foreground: variables['--lb-color-primary-text'] ?? variables['--lb-color-primary'],
            background: primitive.color.white,
            minimum: 4.5,
        },
        {
            token: '--lb-color-primary-cta-text',
            foreground: variables['--lb-color-primary-cta-text'] ?? primitive.color.white,
            background: variables['--lb-color-primary-cta'] ?? variables['--lb-color-primary'],
            minimum: 4.5,
        },
        {
            token: '--lb-color-focus-ring',
            foreground: variables['--lb-color-focus-ring'] ?? variables['--lb-color-primary'],
            background: primitive.color.white,
            minimum: 3,
        },
    ];

    return checks.map((check) => {
        const ratio = contrastRatio(check.foreground, check.background) ?? 0;
        return {
            ...check,
            ratio,
            passes: ratio >= check.minimum,
        };
    });
}

export function createLetbuyyBrandVariables(brand?: LetbuyyBrandInput): CssVariableMap {
    if (!brand) return {};

    const primary = typeof brand === 'string' ? brand : brand.primary;
    const primaryText = typeof brand === 'string' ? brand : brand.primaryText ?? primary;
    const primaryHover = typeof brand === 'string' ? primary : brand.primaryHover ?? primary;
    const primaryActive = typeof brand === 'string' ? primaryHover : brand.primaryActive ?? primaryHover;
    const primarySubtle = typeof brand === 'string'
        ? `color-mix(in srgb, ${primary} 12%, transparent)`
        : brand.primarySubtle ?? `color-mix(in srgb, ${primary} 12%, transparent)`;
    const primaryCta = typeof brand === 'string' ? primary : brand.primaryCta ?? primary;
    const primaryCtaHover = typeof brand === 'string' ? primaryHover : brand.primaryCtaHover ?? primaryHover;
    const primaryCtaActive = typeof brand === 'string' ? primaryActive : brand.primaryCtaActive ?? primaryActive;
    const primaryCtaText = typeof brand === 'string' ? primitive.color.white : brand.primaryCtaText ?? primitive.color.white;
    const focusRing = typeof brand === 'string' ? primary : brand.focusRing ?? primary;

    return {
        '--lb-color-primary': primary,
        '--lb-color-primary-text': primaryText,
        '--lb-color-primary-hover': primaryHover,
        '--lb-color-primary-active': primaryActive,
        '--lb-color-primary-subtle': primarySubtle,
        '--lb-color-primary-soft': primarySubtle,
        '--lb-color-secondary-action': primary,
        '--lb-color-secondary-action-hover': primaryHover,
        '--lb-color-secondary-action-subtle': primarySubtle,
        '--lb-color-focus-ring': focusRing,
        '--lb-color-primary-cta': primaryCta,
        '--lb-color-primary-cta-hover': primaryCtaHover,
        '--lb-color-primary-cta-active': primaryCtaActive,
        '--lb-color-primary-cta-text': primaryCtaText,
        '--lb-semantic-accent-hover': primaryHover,
        '--lb-semantic-accent-active': primaryActive,
        '--lb-semantic-accent-subtle': primarySubtle,
        '--lb-component-button-primary-bg': primaryCta,
        '--lb-component-button-primary-hover': primaryCtaHover,
        '--lb-component-button-primary-active': primaryCtaActive,
        '--lb-component-button-primary-text': primaryCtaText,
        '--lb-component-button-primary-border': primaryCta,
        '--lb-component-input-focus-border': primary,
        '--lb-component-input-focus-ring': primarySubtle,
        '--lb-component-badge-accent-bg': primarySubtle,
        '--lb-component-badge-accent-text': primaryText,
        '--lb-component-badge-accent-border': primary,
        '--lb-component-empty-state-illustration-bg': primarySubtle,
        '--lb-component-empty-state-illustration-ink': primary,
    };
}

export const letbuyyTokenCssVariables = {
    light: {
        ...sharedCssVariables,
        ...colorVariables('light'),
    },
    dark: {
        ...sharedCssVariables,
        ...colorVariables('dark'),
    },
} as const satisfies Record<LetbuyyTheme, CssVariableMap>;

function serializeVariables(variables: CssVariableMap, indent = '  ') {
    return Object.entries(variables)
        .map(([name, value]) => `${indent}${name}: ${value};`)
        .join('\n');
}

function surfaceSelector(surface: LetbuyySurface, themes: Array<LetbuyyTheme | 'auto'>) {
    return themes
        .flatMap((theme) => [
            `[data-letbuyy-surface="${surface}"][data-letbuyy-theme="${theme}"]`,
            `[data-letbuyy-surface="${surface}"][data-theme="${theme}"]`,
            `[data-letbuyy-theme="${theme}"] [data-letbuyy-surface="${surface}"]`,
            `[data-theme="${theme}"] [data-letbuyy-surface="${surface}"]`,
        ])
        .join(', ');
}

function surfaceThemeCss(theme: LetbuyyTheme, themes: Array<LetbuyyTheme | 'auto'>, indent = '  ') {
    return letbuyySurfaceNames
        .flatMap((surface) => [
            `${surfaceSelector(surface, themes)} {`,
            serializeVariables(letbuyySurfaceTokens[surface][theme], indent),
            '}',
        ])
        .join('\n\n');
}

export const letbuyyTokenCss = [
    ':root, [data-theme="light"], [data-letbuyy-theme="light"] {',
    serializeVariables(letbuyyTokenCssVariables.light),
    '}',
    '',
    surfaceThemeCss('light', ['light']),
    '',
    '[data-theme="auto"], [data-letbuyy-theme="auto"] {',
    serializeVariables(letbuyyTokenCssVariables.light),
    '}',
    '',
    surfaceThemeCss('light', ['auto']),
    '',
    '@media (prefers-color-scheme: dark) {',
    '  :root, [data-theme="auto"], [data-letbuyy-theme="auto"] {',
    serializeVariables(letbuyyTokenCssVariables.dark, '    '),
    '  }',
    surfaceThemeCss('dark', ['auto'], '    '),
    '}',
    '',
    '[data-theme="dark"], [data-letbuyy-theme="dark"], .dark {',
    serializeVariables(letbuyyTokenCssVariables.dark),
    '}',
    '',
    surfaceThemeCss('dark', ['dark']),
    '',
    '[data-density="compact"], [data-letbuyy-density="compact"] {',
    serializeVariables(letbuyyDensityCssVariables.compact),
    '}',
    '',
    '[data-density="comfortable"], [data-letbuyy-density="comfortable"] {',
    serializeVariables(letbuyyDensityCssVariables.comfortable),
    '}',
    '',
    '[data-density="spacious"], [data-letbuyy-density="spacious"] {',
    serializeVariables(letbuyyDensityCssVariables.spacious),
    '}',
    '',
    '[data-letbuyy-design-system="true"] {',
    '  color: var(--lb-color-text);',
    '  background: var(--lb-color-bg);',
    '  font-family: var(--lb-font-family-body);',
    '  font-size: var(--lb-font-size-body);',
    '  line-height: var(--lb-line-height-body);',
    '}',
    '',
    '[data-letbuyy-design-system="true"] .letbuyy-icon {',
    '  width: var(--lb-density-action-icon-size);',
    '  height: var(--lb-density-action-icon-size);',
    '  flex-shrink: 0;',
    '}',
    '',
    '[data-letbuyy-design-system="true"] [data-lb-page-header-title="true"] {',
    '  margin: 0;',
    '  overflow: hidden;',
    '  text-overflow: ellipsis;',
    '  white-space: nowrap;',
    '  font-size: var(--lb-component-page-header-title-size);',
    '  line-height: var(--lb-component-page-header-title-line-height);',
    '  font-weight: var(--lb-font-weight-semibold);',
    '  color: var(--lb-color-text);',
    '}',
    '',
    '[data-letbuyy-design-system="true"] [data-lb-page-header-icon="true"] {',
    '  display: inline-flex;',
    '  align-items: center;',
    '  justify-content: center;',
    '  flex-shrink: 0;',
    '  color: var(--lb-component-page-header-icon-text);',
    '  line-height: 1;',
    '}',
    '',
    '[data-letbuyy-design-system="true"] [data-lb-page-header-icon="true"] .letbuyy-icon {',
    '  width: var(--lb-component-page-header-icon-size);',
    '  height: var(--lb-component-page-header-icon-size);',
    '  color: currentColor;',
    '  fill: var(--lb-component-page-header-icon-fill);',
    '  stroke-width: var(--lb-component-page-header-icon-stroke-width);',
    '}',
    '',
    '[data-letbuyy-design-system="true"] *,',
    '[data-letbuyy-design-system="true"] *::before,',
    '[data-letbuyy-design-system="true"] *::after {',
    '  box-sizing: border-box;',
    '}',
    '',
    '@media (prefers-reduced-motion: reduce) {',
    '  [data-letbuyy-design-system="true"] {',
    '    --lb-motion-fast: 0ms;',
    '    --lb-motion-hover: 0ms;',
    '    --lb-motion-menu: 0ms;',
    '    --lb-motion-carousel: 0ms;',
    '    --lb-motion-normal: 0ms;',
    '    --lb-motion-slow: 0ms;',
    '    --lb-motion-hover-lift: 0px;',
    '    --lb-motion-hover-scale: 1;',
    '  }',
    '  [data-letbuyy-design-system="true"] [data-lb-empty-float] { animation: none !important; }',
    '}',
    '',
    '@keyframes lb-empty-state-float {',
    '  0%, 100% { transform: translateY(0); }',
    '  50% { transform: translateY(-6px); }',
    '}',
    '',
    '@keyframes lb-empty-state-drift {',
    '  0%, 100% { transform: translate3d(0, 0, 0); opacity: 0.72; }',
    '  50% { transform: translate3d(4px, -5px, 0); opacity: 1; }',
    '}',
    '',
    '@media (prefers-reduced-motion: no-preference) {',
    '  [data-lb-empty-float="primary"] { animation: lb-empty-state-float 4.8s ease-in-out infinite; }',
    '  [data-lb-empty-float="secondary"] { animation: lb-empty-state-drift 5.6s ease-in-out infinite; }',
    '}',
].join('\n');
