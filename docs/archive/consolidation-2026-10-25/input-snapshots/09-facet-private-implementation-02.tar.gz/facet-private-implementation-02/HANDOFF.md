# Circuit private facet implementation

Ready for independent source review. The private patch changes the canonical discovery query and the existing storefront response projection. It adds accessory manufacturer equality and merchant device-reference presence, with no compatibility guarantee. The paired SQL is deliberately **UNNUMBERED** and changes only the existing shape/flat helper bodies. No canonical migration is emitted or applied.

Seven focused source tests and eight existing discovery regressions pass on the candidate. Strict scoped noEmit and nonmutating patch applicability checks exit0. The first two failing attempts, source snapshots and raw TAP are preserved; HANDOFF.json distinguishes a test invocation correction from the two real projection fixes. All111 original shared harness artifacts remain exact.

The existing browse RPC, model/connector search, measurement metadata, matching/stock/price/UUID rules and all other helper profiles are retained. Before/after all13 function profiles and per-function non-body metadata/comments/dependencies remain fenced by the standalone SQL proposals. Native proof is still required.

NATIVE_ACCEPTANCE.json contains eight future stages, all NOT_RUN. These include real A/B collections, dates/unknown facts, predicate/candidate/count/pagination checks, Unicode casefold parity, performance/index-plan evidence, paired DOWN/replay and actual installed browser acceptance. Source checks do not certify those stages. No source/runtime/database/provider/browser allocation is inferred.

The central Editor03 adapter probe passed with100 stable source pins and requires no rebind. Marginalia's observed current source identity/hash/pins remain a proposal awaiting independent allocator admission; the shared core/adapter/runner stay unchanged.

Automatic approval review rejected sending the adapter handoff to Themes, citing a later project pause. No retry or indirect dispatch was attempted. Actual latest human resumption and the partial-resume receipt were reverified, and only independently authorized private preparation continued. The existing file handoff is preserved.
