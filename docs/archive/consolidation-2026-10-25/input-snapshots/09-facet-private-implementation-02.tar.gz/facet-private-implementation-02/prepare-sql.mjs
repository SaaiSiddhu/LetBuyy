// Private authoring only: outputs unnumbered, standalone paired SQL proposals.
import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { resolve, dirname } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import vm from 'node:vm';
const root = process.cwd(), out = dirname(fileURLToPath(import.meta.url));
const read = path => readFileSync(resolve(root, path), 'utf8');
const hash = (text, algorithm = 'sha256') => createHash(algorithm).update(text).digest('hex');
const base386 = read('database/supabase/migrations/386_storefront_discovery.sql');
const base392 = read('database/supabase/migrations/392_storefront_electronics_search.sql');
const compilerPath = 'docs/implementation/niche-themes-2026-10-23/circuit/discovery/build-static-guards.cjs';
const compiler = read(compilerPath);
// Reuse the actual finite schema compiler without running its file-writing authoring entry point.
const compilerClosure = compiler.slice(compiler.indexOf('const quote ='), compiler.indexOf('const trim ='));
assert.ok(compilerClosure.includes('function compile(schema, value)'));
const context = vm.createContext({});
vm.runInContext('let serial = 0;\n' + compilerClosure + ';globalThis.compileQuery = value => compile(value, "value");', context);
const main = await import(pathToFileURL(resolve(root, 'packages/commerce-core/src/storefront-discovery.ts')));
const privateModule = await import(pathToFileURL(resolve(out, 'packages/commerce-core/src/storefront-discovery.ts')));
const oldSnapshot = main.storefrontDiscoverySchemaSnapshot(), nextSnapshot = privateModule.storefrontDiscoverySchemaSnapshot();
assert.deepEqual(nextSnapshot.product, oldSnapshot.product);
assert.deepEqual(nextSnapshot.variant, oldSnapshot.variant);
const oldQuery = context.compileQuery(oldSnapshot.query);
// Reset the bounded compiler's local serial so unchanged array aliases stay exact.
vm.runInContext('serial = 0;', context);
const nextQuery = context.compileQuery(nextSnapshot.query);
const definition = name => {
  const match = [...base386.matchAll(/CREATE OR REPLACE FUNCTION public\.(\w+)\([\s\S]*? AS \$fn\$[\s\S]*?\$fn\$;/g)].find(m => m[1] === name);
  assert.ok(match, `historical definition absent: ${name}`);
  return match[0];
};
const oldShape = definition('storefront_discovery_shape_v1');
const queryBranch = `IF namespace='$query' THEN RETURN ${oldQuery}; END IF;`;
assert.equal(oldShape.split(queryBranch).length, 2, 'exact current canonical query compiler output matches frozen SQL branch');
const newShape = oldShape.replace(queryBranch, `IF namespace='$query' THEN RETURN ${nextQuery}; END IF;`);
const oldFlat = definition('storefront_discovery_flat_v1');
const anchor = " IF facts->'electronics'?'kind' THEN";
assert.equal(oldFlat.split(anchor).length, 2);
const additions = ` IF facts?'electronics' THEN
  -- Accessory manufacturer only: host-device manufacturer is a separate fact.
  IF facts->'electronics'?'manufacturer' THEN result:=result||jsonb_build_object('electronics_manufacturer',jsonb_build_array(facts->'electronics'->'manufacturer'));END IF;
  -- Only the already validated common namespace contributes. A source-backed
  -- device reference describes merchant evidence, never a platform guarantee.
  result:=result||jsonb_build_object('compatibility_evidence',jsonb_build_array(
   CASE WHEN jsonb_array_length(coalesce(facts->'electronics'->'compatible_devices','[]'::jsonb))>0 THEN 'supplied' ELSE 'unconfirmed' END));
 END IF;
`;
const newFlat = oldFlat.replace(anchor, additions + anchor);
const changes = [
  { name: 'storefront_discovery_shape_v1', oldDdl: oldShape, newDdl: newShape },
  { name: 'storefront_discovery_flat_v1', oldDdl: oldFlat, newDdl: newFlat },
];
for (const change of changes) {
  change.signature = change.name === 'storefront_discovery_shape_v1'
    ? 'public.storefront_discovery_shape_v1(jsonb,text,boolean)'
    : 'public.storefront_discovery_flat_v1(jsonb,jsonb,boolean,jsonb,jsonb)';
  change.beforeMd5 = hash(change.oldDdl.split('$fn$')[1], 'md5');
  change.afterMd5 = hash(change.newDdl.split('$fn$')[1], 'md5');
}
const profiles = [...base392.matchAll(/DO \$profile\$[\s\S]*?END \$profile\$;/g)].map(m => m[0]);
assert.equal(profiles.length, 2);
const baselineProfile = profiles[1];
let nextProfile = baselineProfile;
for (const change of changes) {
  assert.equal(nextProfile.split(change.beforeMd5).length, 2);
  nextProfile = nextProfile.replace(change.beforeMd5, change.afterMd5);
}
const fence = base392.match(/DO \$managed_catalog_fence\$[\s\S]*?END \$managed_catalog_fence\$;/)?.[0];
const mutation = base392.match(/DO \$mutation\$[\s\S]*?END \$mutation\$;/)?.[0];
const oldBrowse = base392.match(/EXECUTE \$replacement\$([\s\S]*?)\$replacement\$;/)?.[1];
assert.ok(fence && mutation && oldBrowse);
const mutationFor = (change, ddl) => mutation.replace(oldBrowse, ddl)
  .replace("public.browse_storefront_products_v1(uuid,jsonb,uuid[])", change.signature)
  .replaceAll('DRAFT392', 'UNNUMBERED_CIR_C02_PRIVATE');
const header = `-- UNNUMBERED PRIVATE CIR-C02 PROPOSAL; NOT ADMITTED, EMITTED, APPLIED OR NATIVE QUALIFIED.
-- No migration number reserved. Only two existing invoker helper bodies change.
-- The canonical browse RPC including migration390 capabilities/392 model search is unchanged.
BEGIN;
SELECT pg_advisory_xact_lock(hashtextextended('proposal:circuit-manufacturer-evidence-facets',0));
`;
const up = header + fence + '\n' + baselineProfile + '\n' + changes.map(c => mutationFor(c, c.newDdl)).join('\n') + '\n' + nextProfile + "\nNOTIFY pgrst,'reload schema';\nCOMMIT;\n";
const down = header + fence + '\n' + nextProfile + '\n' + [...changes].reverse().map(c => mutationFor(c, c.oldDdl)).join('\n') + '\n' + baselineProfile + "\nNOTIFY pgrst,'reload schema';\nCOMMIT;\n";
const emit = (name, text) => writeFileSync(resolve(out, name), typeof text === 'string' ? text : JSON.stringify(text, null, 2) + '\n', { flag: 'wx' });
emit('UNNUMBERED_circuit_facets.up.proposal.sql', up);
emit('UNNUMBERED_circuit_facets.down.proposal.sql', down);
emit('canonical-schema.proposal.json', nextSnapshot);
emit('sql-source-conservation.json', {
  status: 'PRIVATE_STANDALONE_PAIR_PREPARED_NOT_NATIVE_QUALIFIED',
  migrationNumber: null, canonicalMigrationEmission: false, databaseExecuted: false,
  baseline: ['database/supabase/migrations/386_storefront_discovery.sql', 'database/supabase/migrations/392_storefront_electronics_search.sql', compilerPath].map(path => ({ path, sha256: hash(read(path)) })),
  compilerClosureSha256: hash(compilerClosure),
  exactOldQueryCompilerOutputMatchedFrozenSql: true,
  productAndVariantGuardsUnchanged: true,
  changedFunctions: changes.map(({ name, signature, beforeMd5, afterMd5 }) => ({ name, signature, beforeMd5, afterMd5 })),
  unchanged: ['browse RPC body/signature', '390 measurement metadata', '392 validated model/connector keyword search', 'match helper', 'fact validator/date/connector/device guard', 'same-candidate stock/price/variant witness', 'tenant/collection/pagination/count/sort', 'all RLS/ACL/OID/defaults/owner/dependencies'],
  fences: ['original managed catalog lock', 'all13 exact current discovery profiles before and after', 'per-function full pg_proc row except prosrc plus comments/dependencies conservation'],
  requiredNativeProof: 'Full owned current baseline, genuine positive-first A/B collection, schema/SQL parity, predicate/count/page/security/performance witnesses, DOWN and replay; no qualification claimed here.',
  files: [{ name: 'UNNUMBERED_circuit_facets.up.proposal.sql', sha256: hash(up) }, { name: 'UNNUMBERED_circuit_facets.down.proposal.sql', sha256: hash(down) }],
});
process.stdout.write(JSON.stringify({ status: 'PRIVATE_UNNUMBERED_PAIR_PREPARED', helpers: changes.length, nativeExecuted: false }) + '\n');
