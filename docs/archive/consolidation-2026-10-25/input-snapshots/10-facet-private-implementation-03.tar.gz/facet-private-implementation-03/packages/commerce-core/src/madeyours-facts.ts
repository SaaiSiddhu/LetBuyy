import { z } from 'zod';

const id = z.string().regex(/^[a-z][a-z0-9_-]{0,39}$/);
const label = z.string().min(1).max(100).refine(value => value.trim() === value && !/[\p{Cc}\p{Cf}]/u.test(value), 'Use a visible label without surrounding whitespace.');
const choice = z.object({ id, label }).strict();

/** Public, merchant-authored text capabilities. No file uploads, arbitrary patterns or inferred promises. */
export const PersonalizationFactsSchema = z.object({
  version: z.literal(1),
  revision: z.number().int().min(1).max(2147483647),
  methods: z.array(z.object({
    id, label,
    min_graphemes: z.number().int().min(1).max(80),
    max_graphemes: z.number().int().min(1).max(80),
    character_set: z.enum(['latin-name', 'unicode-letters']),
    styles: z.array(choice).min(1).max(8),
    placements: z.array(choice).min(1).max(8),
  }).strict()).min(1).max(4),
  production_note: z.string().max(1000).optional(),
}).strict().superRefine((facts, ctx) => {
  const unique = (rows: { id: string }[], path: (string | number)[]) => {
    const seen = new Set<string>();
    rows.forEach((row, index) => {
      if (seen.has(row.id)) ctx.addIssue({ code: 'custom', path: [...path, index, 'id'], message: 'Each identifier must appear once.' });
      seen.add(row.id);
    });
  };
  unique(facts.methods, ['methods']);
  facts.methods.forEach((method, index) => {
    if (method.min_graphemes > method.max_graphemes) ctx.addIssue({ code: 'custom', path: ['methods', index, 'max_graphemes'], message: 'Maximum length must be at least the minimum length.' });
    unique(method.styles, ['methods', index, 'styles']);
    unique(method.placements, ['methods', index, 'placements']);
  });
});
export type PersonalizationFacts = z.infer<typeof PersonalizationFactsSchema>;

/** Project only the validated namespace; private and malformed metadata never become public facts. */
export function readPersonalizationFacts(metadata: unknown): PersonalizationFacts | null {
  if (!metadata || typeof metadata !== 'object' || Array.isArray(metadata) || !Object.prototype.hasOwnProperty.call(metadata, 'personalization')) return null;
  const parsed = PersonalizationFactsSchema.safeParse((metadata as Record<string, unknown>).personalization);
  return parsed.success ? parsed.data : null;
}

export const PersonalizationDraftSchema = z.object({
  method_id: id, style_id: id, placement_id: id, text: z.string().max(1000),
}).strict();
export type PersonalizationDraft = z.infer<typeof PersonalizationDraftSchema>;
export const AcceptedPersonalizationSchema = z.object({
  version: z.literal(1), facts_revision: z.number().int().min(1).max(2147483647),
  method: choice, style: choice, placement: choice,
  text: z.string().min(1).max(1000).refine(value => value === value.normalize('NFC') && !/[\p{Cc}\p{Cf}\p{Cs}]/u.test(value), 'Accepted text must be NFC without control characters.'),
}).strict();
export type AcceptedPersonalization = z.infer<typeof AcceptedPersonalizationSchema>;
export interface PersonalizationIssue {
  field: 'configuration' | keyof PersonalizationDraft;
  code: 'INVALID_INPUT' | 'METHOD_UNAVAILABLE' | 'STYLE_UNAVAILABLE' | 'PLACEMENT_UNAVAILABLE' | 'NORMALIZE_TEXT' | 'INVALID_CHARACTERS' | 'INVALID_LENGTH';
  message: string;
  suggested_text?: string;
}
export type PersonalizationReview = { valid: true; accepted: AcceptedPersonalization; fingerprintInput: string; graphemes: number } | { valid: false; issues: PersonalizationIssue[]; graphemes?: number };
const segmenter = new Intl.Segmenter('und', { granularity: 'grapheme' });
export const countPersonalizationGraphemes = (value: string): number => Array.from(segmenter.segment(value)).length;

/** Deterministic INPUT to a server digest, never a security hash or a client authority. */
export function personalizationFingerprintInput(accepted: AcceptedPersonalization): string {
  return JSON.stringify([accepted.version, accepted.facts_revision, accepted.method.id, accepted.style.id, accepted.placement.id, accepted.text]);
}

/** The server must call this against current catalog facts before accepting or pricing a line. */
export function reviewPersonalization(factsInput: unknown, input: unknown): PersonalizationReview {
  const facts = PersonalizationFactsSchema.safeParse(factsInput);
  const draft = PersonalizationDraftSchema.safeParse(input);
  if (!facts.success || !draft.success) return { valid: false, issues: [{ field: 'configuration', code: 'INVALID_INPUT', message: 'Personalization information is missing or invalid. Reload the product and try again.' }] };
  const value = draft.data;
  const method = facts.data.methods.find(item => item.id === value.method_id);
  if (!method) return { valid: false, issues: [{ field: 'method_id', code: 'METHOD_UNAVAILABLE', message: 'Choose a personalization method available for this product.' }] };
  const style = method.styles.find(item => item.id === value.style_id);
  const placement = method.placements.find(item => item.id === value.placement_id);
  const issues: PersonalizationIssue[] = [];
  if (!style) issues.push({ field: 'style_id', code: 'STYLE_UNAVAILABLE', message: 'Choose a style available for this method.' });
  if (!placement) issues.push({ field: 'placement_id', code: 'PLACEMENT_UNAVAILABLE', message: 'Choose a placement available for this method.' });
  const normalized = value.text.normalize('NFC');
  if (normalized !== value.text) issues.push({ field: 'text', code: 'NORMALIZE_TEXT', message: 'This text needs Unicode normalization. Review the suggested text before accepting it.', suggested_text: normalized });
  const allowed = method.character_set === 'latin-name' ? /^[A-Za-z '\-]+$/u : /^[\p{L}\p{M} '\-]+$/u;
  if (!allowed.test(value.text) || !/\p{L}/u.test(value.text) || /[\p{Cc}\p{Cf}\p{Cs}]/u.test(value.text)) issues.push({ field: 'text', code: 'INVALID_CHARACTERS', message: method.character_set === 'latin-name' ? 'Use A–Z letters, spaces, apostrophes or hyphens. Include at least one letter.' : 'Use letters, spaces, apostrophes or hyphens. Include at least one letter.' });
  const graphemes = countPersonalizationGraphemes(value.text);
  if (graphemes < method.min_graphemes || graphemes > method.max_graphemes) issues.push({ field: 'text', code: 'INVALID_LENGTH', message: `Use ${method.min_graphemes}–${method.max_graphemes} characters. You entered ${graphemes}.` });
  if (issues.length || !style || !placement) return { valid: false, issues, graphemes };
  const accepted: AcceptedPersonalization = { version: 1, facts_revision: facts.data.revision, method: { id: method.id, label: method.label }, style: { ...style }, placement: { ...placement }, text: value.text };
  return { valid: true, accepted, fingerprintInput: personalizationFingerprintInput(accepted), graphemes };
}

export interface PersonalizationDraftState {
  draft: PersonalizationDraft;
  review: PersonalizationReview;
  lastValidPreview: AcceptedPersonalization | null;
}
/** Invalid edits retain their exact text while the illustration keeps the last valid configuration. */
export function updatePersonalizationDraft(facts: unknown, draft: PersonalizationDraft, previous?: PersonalizationDraftState): PersonalizationDraftState {
  const review = reviewPersonalization(facts, draft);
  const parsedFacts = PersonalizationFactsSchema.safeParse(facts);
  const prior = previous?.lastValidPreview;
  return { draft: { ...draft }, review, lastValidPreview: review.valid ? review.accepted : parsedFacts.success && prior?.facts_revision === parsedFacts.data.revision ? prior : null };
}
