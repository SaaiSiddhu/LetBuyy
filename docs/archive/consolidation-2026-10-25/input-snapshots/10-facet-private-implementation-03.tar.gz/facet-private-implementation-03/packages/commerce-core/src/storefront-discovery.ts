import { z } from 'zod';
import { PRODUCT_NICHE_FACT_SCHEMAS, VARIANT_NICHE_FACT_SCHEMAS } from './niche-product-facts';
import { ElectronicsConnectorSchema } from './circuit-facts';

const empty = (value: unknown) => typeof value === 'string' && value.trim() === '' ? undefined : value;
const text = (maximum: number) => z.preprocess(empty, z.string().trim().min(1).max(maximum).optional());
const numeric = (minimum: number, maximum: number, integer = false) => {
  const number = integer ? z.number().finite().int().min(minimum).max(maximum) : z.number().finite().min(minimum).max(maximum);
  return z.union([z.number().finite(), z.string().trim().regex(/^[+-]?(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?$/i)]).pipe(z.coerce.number<number | string>().pipe(number));
};
const number = (minimum: number, maximum: number) => z.preprocess(empty, numeric(minimum, maximum).optional());
const choice = <T extends readonly [string, ...string[]]>(options: T) => z.preprocess(empty, z.enum(options).optional());
const slug = z.preprocess(empty, z.string().trim().min(1).max(40).regex(/^[a-z][a-z0-9_-]*$/).optional());
const interest = z.preprocess(empty, z.string().trim().min(1).max(40).regex(/^[a-z][a-z0-9-]*$/).optional());
const giftKey = z.preprocess(empty, z.string().trim().min(1).max(40).regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/).optional());
const connector = ElectronicsConnectorSchema.shape.kind;
const lengthUnits = ['mm', 'cm', 'm', 'in'] as const;

/** One transport contract for every storefront theme. Unknown filters are never silently ignored. */
export const StorefrontDiscoveryQuerySchema = z.object({
  page: z.preprocess(empty, numeric(1, 10000, true).default(1)),
  limit: z.preprocess(empty, numeric(1, 100, true).default(20)),
  search: text(200), category: text(100), country_of_origin: text(100),
  sort: z.preprocess(empty, z.enum(['display_order', 'price-asc', 'price-desc', 'newest', 'name']).default('display_order')),
  collection_id: z.preprocess(empty, z.string().uuid().optional()),
  size: text(100), color: text(100),
  min_price: number(0, 100000000), max_price: number(0, 100000000),
  age_band: choice(['3-5', '6-8', '9-12']), interest,
  electronics_kind: choice(['hub', 'adapter', 'charger', 'cable', 'audio', 'device', 'other']),
  electronics_manufacturer: text(120),
  compatibility_evidence: choice(['supplied', 'unconfirmed']),
  connector: z.preprocess(empty, z.union([connector, z.array(connector).min(1).max(9).refine(rows => new Set(rows).size === rows.length, 'Choose each connector once.')]).optional()),
  power_input_w: number(Number.MIN_VALUE, 10000), power_output_w: number(Number.MIN_VALUE, 10000),
  power_capacity_w: number(Number.MIN_VALUE, 10000), pass_through_output_w: number(Number.MIN_VALUE, 10000),
  data_rate_mbps: number(Number.MIN_VALUE, 1000000), length_mm: number(Number.MIN_VALUE, 100000),
  pack_size: z.preprocess(empty, z.string().regex(/^(g|ml):[1-9]\d{0,9}$/).refine(value => Number(value.split(':')[1]) <= 1000000000, 'Pack quantity is too large.').optional()),
  material: text(200), finish: text(200), max_width_cm: number(Number.MIN_VALUE, 1000000), max_depth_cm: number(Number.MIN_VALUE, 1000000),
  occasion: giftKey, recipient: giftKey, personalization_method: slug,
  routine_stage: choice(['cleanse', 'care', 'colour']), format: text(80), shade: text(100),
  activity: text(80), equipment_type: choice(['racket', 'shuttles', 'storage', 'recreational-accessory']),
  length_value: number(Number.MIN_VALUE, 100000), length_unit: choice(lengthUnits),
  books_kind: choice(['book', 'stationery']), books_author: text(200), books_subject: text(100), books_language: text(80),
  books_format: choice(['paperback', 'hardback', 'board-book', 'spiral-bound', 'other']),
  books_ruling: choice(['blank', 'lined', 'dotted', 'grid', 'other']),
}).strict().superRefine((query, context) => {
  if (query.min_price !== undefined && query.max_price !== undefined && query.min_price > query.max_price)
    context.addIssue({ code: 'custom', path: ['min_price'], message: 'Minimum price must not exceed maximum price.' });
  if ((query.length_value === undefined) !== (query.length_unit === undefined))
    context.addIssue({ code: 'custom', path: ['length_value'], message: 'Supply an equipment length and its unit together.' });
});
export type StorefrontDiscoveryQuery = z.infer<typeof StorefrontDiscoveryQuerySchema>;
/** SDK inputs use canonical values; HTTP strings are normalized by the server schema. */
export type StorefrontDiscoveryQueryInput = Partial<StorefrontDiscoveryQuery>;
export const STOREFRONT_DISCOVERY_QUERY_KEYS = Object.keys(StorefrontDiscoveryQuerySchema.shape) as Array<keyof StorefrontDiscoveryQuery>;
export const STOREFRONT_DISCOVERY_FILTER_KEYS = STOREFRONT_DISCOVERY_QUERY_KEYS.filter(key => !['page', 'limit', 'sort', 'search'].includes(key));
export type StorefrontDiscoveryFilterKey = Exclude<keyof StorefrontDiscoveryQuery, 'page' | 'limit' | 'sort' | 'search'>;
export interface StorefrontDiscoveryFacet { key: StorefrontDiscoveryFilterKey; value: string; label: string; count: number }
export interface StorefrontDiscoveryMatch { product_id: string; price: number; variant_ids: string[] }
/** Explicit server capability only. Absent metadata remains unsupported on migration386. */
export const StorefrontDiscoveryMeasurementCapabilitiesSchema = z.object({
  equipment_length: z.object({
    available: z.boolean(), allowed_units: z.array(z.enum(lengthUnits)).max(lengthUnits.length),
  }).strict().superRefine((capability, context) => {
    if (capability.available !== (capability.allowed_units.length > 0))
      context.addIssue({ code: 'custom', path: ['allowed_units'], message: 'Available equipment length requires units; unavailable length must have none.' });
    let previous = -1;
    capability.allowed_units.forEach((unit, index) => {
      const position = lengthUnits.indexOf(unit);
      if (position <= previous) context.addIssue({ code: 'custom', path: ['allowed_units', index], message: 'Supply each length unit once in canonical order.' });
      previous = position;
    });
  }),
  max_width_cm: z.object({ available: z.boolean() }).strict(),
  max_depth_cm: z.object({ available: z.boolean() }).strict(),
}).strict();
export type StorefrontDiscoveryMeasurementCapabilities = z.infer<typeof StorefrontDiscoveryMeasurementCapabilitiesSchema>;
export interface StorefrontDiscoveryMetadata {
  query: StorefrontDiscoveryQuery;
  facets: StorefrontDiscoveryFacet[];
  matches: StorefrontDiscoveryMatch[];
  measurement_capabilities?: StorefrontDiscoveryMeasurementCapabilities;
}
export const StorefrontDiscoveryMetadataSchema = z.object({
  query: StorefrontDiscoveryQuerySchema,
  facets: z.array(z.object({ key: StorefrontDiscoveryQuerySchema.keyof().exclude(['page','limit','sort','search']), value: z.string().max(500), label: z.string().max(500), count: z.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER) }).strict()).max(2000),
  matches: z.array(z.object({ product_id: z.string().uuid(), price: z.number().finite().nonnegative().max(Number.MAX_SAFE_INTEGER), variant_ids: z.array(z.string().uuid()).max(100) }).strict()).max(100),
  measurement_capabilities: StorefrontDiscoveryMeasurementCapabilitiesSchema.optional(),
}).strict();

/** Read repeated connector checkboxes without losing a selected value; scalar repeats are invalid. */
export function storefrontDiscoveryQueryFromEntries(entries: Iterable<readonly [string, string]>, transportKeys: readonly string[] = []): Record<string, unknown> {
  const result: Record<string, unknown> = Object.create(null) as Record<string, unknown>;
  for (const [key, value] of entries) {
    if (transportKeys.includes(key)) continue;
    if (Object.hasOwn(result, key)) result[key] = Array.isArray(result[key]) ? [...result[key], value] : [result[key], value];
    else result[key] = value;
  }
  return result;
}

/** All navigation is relative to the current authorized store route. */
export function storefrontDiscoveryUrl(path: string, input: unknown, patch: Partial<Record<keyof StorefrontDiscoveryQuery, unknown>> = {}): string {
  if (!path.startsWith('/') || path.startsWith('//') || /[?#\\\u0000-\u001f]/.test(path)) throw new TypeError('Use a store-relative path without query or fragment.');
  const query = StorefrontDiscoveryQuerySchema.parse({ ...StorefrontDiscoveryQuerySchema.parse(input), ...patch });
  const params = new URLSearchParams();
  for (const key of STOREFRONT_DISCOVERY_QUERY_KEYS) {
    const value = query[key];
    if (value === undefined || key === 'page' && value === 1) continue;
    for (const item of Array.isArray(value) ? [...value].sort() : [value]) params.append(key, String(item));
  }
  return path + (params.size ? `?${params}` : '');
}
export function clearStorefrontDiscoveryFilterUrl(path: string, query: unknown, key: StorefrontDiscoveryFilterKey, selectedValue?: string): string {
  if (!STOREFRONT_DISCOVERY_FILTER_KEYS.includes(key)) throw new TypeError('Unknown discovery filter.');
  const parsed = StorefrontDiscoveryQuerySchema.parse(query), current = parsed[key];
  let next: unknown;
  if (selectedValue !== undefined) {
    if (Array.isArray(current)) { const remaining = current.filter(value => String(value) !== selectedValue);next = remaining.length ? remaining : undefined; }
    else if (current !== undefined && String(current) !== selectedValue) next = current;
  }
  return storefrontDiscoveryUrl(path, parsed, { [key]: next, page: 1 });
}
export function normalizeDiscoveryLengthMm(value: number, unit: (typeof lengthUnits)[number]): number | null {
  if (!Number.isFinite(value) || value <= 0 || value > 1000000 || !lengthUnits.includes(unit)) return null;
  return Math.round(value * { mm: 1, cm: 10, m: 1000, in: 25.4 }[unit] * 1000) / 1000;
}

/** Migration386 embeds these canonical schemas; its parity test rejects hand-maintained shape drift. */
export function storefrontDiscoverySchemaSnapshot() {
  return {
    query: z.toJSONSchema(StorefrontDiscoveryQuerySchema, { io: 'output' }),
    product: Object.fromEntries(Object.entries(PRODUCT_NICHE_FACT_SCHEMAS).map(([key, schema]) => [key, z.toJSONSchema(schema, { io: 'input' })])),
    variant: Object.fromEntries(Object.entries(VARIANT_NICHE_FACT_SCHEMAS).map(([key, schema]) => [key, z.toJSONSchema(schema, { io: 'input' })])),
  };
}
