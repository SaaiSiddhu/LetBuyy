# Corrected Circuit facet proposal03

The two-file canonical query/projection candidate is unchanged from source-qualified02. The SQL authoring defect in02 is corrected here with literal replacement callbacks. The old02SQL pair is rejected for execution and preserved. Corrected UP/DOWN are156349/155029bytes; only the query branch grows650bytes. Exact product/variant guard suffixes and embedded function definitions are checked independently.

Eight focused source tests pass. Eight existing discovery regressions and strict production typecheck are reused from byte-identical02source. A new eight-stage owned native qualifier passes strict checking at its proposed canonical path using a virtual compiler host; no Main file was created. Raw failed typecheck attempts remain preserved.

Native qualification has NOT run. The qualifier requires allocator-written exact admission, canonical owned runner, full defaultLATEST and source hashes; it stops after the first failed stage. It covers A/B real collections, both actual Worker routes, strict shape/evidence/unknown and role checks, stock/price/UUID identity, all prior fact namespaces, model search, product-distinct counts and pagination, SQL/frontend Unicode casefold, profile drift refusal, sanitized outage, bounded plan timing and exact DOWN/replay/all-public-table conservation. It performs no payment, browser or retained data operation.

The outer RPC plan cannot establish indexed-predicate M1 acceptance. That requirement and actual installed editor/buyer/COD/Razorpay/history/quality acceptance remain open. The standalone pair remains UNNUMBERED, outside canonical migration directories. The allocator must admit the exact source/native scope and resolve shared ordering before integration or execution.
