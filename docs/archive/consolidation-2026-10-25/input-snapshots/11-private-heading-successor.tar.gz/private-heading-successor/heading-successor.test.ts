import assert from 'node:assert/strict';
import test from 'node:test';
import { readFileSync, writeFileSync, appendFileSync, mkdirSync, existsSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createFirstPartyCatalogBundle, firstPartyThemeListings } from './packages/theme-engine/src/first-party-theme-catalog';
import { createFirstPartyCatalogBundle as mainBundle } from '../../../../../../packages/theme-engine/src/first-party-theme-catalog';
import { LiquidThemePackageBundleSchema, buildLiquidThemePackagePersistencePayload, type LiquidThemePackageBundle } from './packages/theme-engine/src/theme-bundle';
import { LiquidRenderer } from './packages/theme-engine/src/theme-renderer';
import { DEFAULT_THEME_SETTINGS } from './packages/theme-engine/src/theme-settings';
import { toThemeDocumentV2, fromThemeDocumentV2 } from './packages/theme-engine/src/theme-document';

const here = dirname(fileURLToPath(import.meta.url));
const epoch = process.env.CIRCUIT_PRIVATE_TEST_EPOCH;
assert.ok(epoch && /^red01$|^green01$/.test(epoch), 'provide a distinct finite source test epoch');
const artifacts = resolve(here, 'test-results', epoch);
assert.ok(!existsSync(artifacts), 'never overwrite a completed source test epoch');
mkdirSync(artifacts, { recursive: true });
const sha = (text: string) => createHash('sha256').update(text).digest('hex');
const original = () => createFirstPartyCatalogBundle('letbuyy-forge', { designVersion: '2.0.0' });
// Extra explicit option is deliberately ignored by the RED pre-correction source.
const successor = () => createFirstPartyCatalogBundle('letbuyy-forge', { designVersion: '2.0.0', circuitVersion: '2.0.1' } as Parameters<typeof createFirstPartyCatalogBundle>[1]);
function configured(bundle: LiquidThemePackageBundle, key: string, field: string, value: string) {
  const next = structuredClone(bundle);
  const type = key === 'customers/order' ? 'customer-order-detail' : 'collection-product-list';
  const instance = Object.values(next.templates[key].sections).find(s => s.type === type)!;
  instance.settings[field] = value;
  return next;
}
async function render(bundle: LiquidThemePackageBundle, key: 'collection' | 'search' | 'customers/order') {
  const result = await new LiquidRenderer().render({
    context: { storeId: '11111111-1111-4111-8111-111111111111', subdomain: 'circuit-private-successor', path: key === 'customers/order' ? '/account/orders/source-only' : `/${key}`, previewMode: false, locale: 'en-IN' },
    storeTemplate: { themeId: 'letbuyy-forge', themeSettings: DEFAULT_THEME_SETTINGS, sections: [] },
    routeTemplate: { id: key, type: key === 'customers/order' ? 'customer_order' : key, layoutKey: 'theme', sections: [] },
    liquidBundle: bundle, liquidTemplateKey: key,
    liquidContext: { shop: { name: 'Synthetic source-only Circuit' }, collection: { title: 'Accessories', products: [], total: 0, pagination: { page: 1 } }, buyer: { id: 'synthetic-source-only' }, order: { id: 'synthetic-unpersisted', number: 'SOURCE-101', status: 'pending', line_items: [{ title: 'Synthetic hub', quantity: 1, line_price: 120000, currency: 'INR', niche_facts_text: 'Model: Synthetic H1\nPower output maximum: 45 W' }], total: 120000, currency: 'INR' } },
  });
  assert.equal(result.status, 'rendered');
  assert.deepEqual(result.warnings, []);
  const value = { html: result.liquid!.contentForLayout, style: result.liquid!.headStyleText };
  const digest = sha(value.html);
  const target = resolve(artifacts, `${digest}.html`);
  if (!existsSync(target)) writeFileSync(target, value.html);
  appendFileSync(resolve(artifacts, 'renders.jsonl'), JSON.stringify({ key, packageVersion: bundle.package.version, htmlSha256: digest, styleSha256: sha(value.style ?? ''), status: result.status, warnings: result.warnings }) + '\n');
  return value;
}

test('Circuit successor selection is explicit; package identity is stable and version advances', () => {
  const next = successor();
  assert.equal(next.package.slug, 'letbuyy-forge');
  assert.equal(next.package.name, 'Circuit');
  assert.equal(next.package.version, '2.0.1');
  assert.equal(next.package.version_number, 3);
  assert.equal(original().package.version, '2.0.0');
});

test('all ten default 2.0.0 and legacy catalog outputs remain exactly equal to current Main', () => {
  for (const listing of firstPartyThemeListings({ designVersion: '2.0.0' })) {
    assert.deepEqual(createFirstPartyCatalogBundle(listing.slug, { designVersion: '2.0.0' }), mainBundle(listing.slug, { designVersion: '2.0.0' }), listing.slug);
    assert.deepEqual(createFirstPartyCatalogBundle(listing.slug), mainBundle(listing.slug), `${listing.slug} legacy`);
  }
});

test('Circuit explicit option does not change another theme or opt a legacy package into v2', () => {
  for (const slug of ['letbuyy-sense', 'letbuyy-bloom', 'letbuyy-nova']) assert.deepEqual(createFirstPartyCatalogBundle(slug, { designVersion: '2.0.0', circuitVersion: '2.0.1' } as Parameters<typeof createFirstPartyCatalogBundle>[1]), mainBundle(slug, { designVersion: '2.0.0' }));
  assert.deepEqual(createFirstPartyCatalogBundle('letbuyy-forge', { circuitVersion: '2.0.1' } as Parameters<typeof createFirstPartyCatalogBundle>[1]), mainBundle('letbuyy-forge'));
});

test('actual successor schema/manifest and JSON document roundtrip preserve explicit heading edits', () => {
  let next = configured(successor(), 'collection', 'title', 'Collection title');
  next = configured(next, 'search', 'title', 'Search title');
  next = configured(next, 'customers/order', 'heading', 'Your purchase');
  assert.ok(LiquidThemePackageBundleSchema.safeParse(next).success);
  const manifest = buildLiquidThemePackagePersistencePayload(next).schemaManifest;
  const schemas = manifest.section_schemas as Record<string, { settings_schema: Record<string, { type: string; default?: unknown }> }>;
  assert.equal(schemas['collection-product-list'].settings_schema.title.type, 'text');
  assert.equal(schemas['collection-product-list'].settings_schema.title.default, '');
  assert.equal(schemas['customer-order-detail'].settings_schema.heading.type, 'text');
  assert.deepEqual(fromThemeDocumentV2(JSON.parse(JSON.stringify(toThemeDocumentV2(next)))), next);
});

for (const key of ['collection', 'search'] as const) {
  test(`${key}: editing the declared title changes actual Liquid heading output`, async () => {
    const alpha = await render(configured(successor(), key, 'title', 'CIRCUIT_ALPHA'), key);
    const beta = await render(configured(successor(), key, 'title', 'CIRCUIT_BETA'), key);
    assert.ok(alpha.html.includes('<h2>CIRCUIT_ALPHA</h2>'));
    assert.ok(beta.html.includes('<h2>CIRCUIT_BETA</h2>'));
    assert.notEqual(alpha.html, beta.html);
  });
  test(`${key}: clearing removes only the optional heading and restores exact default HTML/styles`, async () => {
    const fresh = await render(successor(), key);
    const cleared = await render(configured(successor(), key, 'title', ''), key);
    assert.deepEqual(cleared, fresh);
    assert.deepEqual(fresh, await render(original(), key));
  });
  test(`${key}: merchant heading markup is escaped as text`, async () => {
    const value = await render(configured(successor(), key, 'title', '<script>CIRCUIT_UNTRUSTED</script>'), key);
    assert.ok(value.html.includes('&lt;script&gt;CIRCUIT_UNTRUSTED&lt;/script&gt;'));
    assert.ok(!value.html.includes('<script>CIRCUIT_UNTRUSTED'));
  });
}

test('order: declared heading edits render with the authoritative order number retained', async () => {
  const alpha = await render(configured(successor(), 'customers/order', 'heading', 'CIRCUIT_RECEIPT_ALPHA'), 'customers/order');
  const beta = await render(configured(successor(), 'customers/order', 'heading', 'CIRCUIT_RECEIPT_BETA'), 'customers/order');
  assert.ok(alpha.html.includes('<h1>CIRCUIT_RECEIPT_ALPHA #SOURCE-101</h1>'));
  assert.ok(beta.html.includes('<h1>CIRCUIT_RECEIPT_BETA #SOURCE-101</h1>'));
  assert.notEqual(alpha.html, beta.html);
});

test('order: clear falls back to Order; default HTML/styles and immutable saved facts stay unchanged', async () => {
  const old = await render(original(), 'customers/order');
  const fresh = await render(successor(), 'customers/order');
  const cleared = await render(configured(successor(), 'customers/order', 'heading', ''), 'customers/order');
  assert.deepEqual(fresh, old);
  assert.deepEqual(cleared, old);
  assert.ok(fresh.html.includes('Synthetic H1') && fresh.html.includes('45 W'));
});

test('order: merchant heading markup is escaped without changing the order number', async () => {
  const value = await render(configured(successor(), 'customers/order', 'heading', '<img src=x onerror=alert(1)>'), 'customers/order');
  assert.ok(value.html.includes('&lt;img src=x onerror=alert(1)&gt; #SOURCE-101'));
  assert.ok(!value.html.includes('<img src="x"'));
});

test('only package version and the two Circuit section outputs differ; electronics facts and styles unchanged', () => {
  const next = successor(), base = original(), rest = structuredClone(next);
  rest.package = base.package;
  rest.sections['collection-product-list'] = base.sections['collection-product-list'];
  rest.sections['customer-order-detail'] = base.sections['customer-order-detail'];
  assert.deepEqual(rest, base);
  assert.deepEqual(next.sections['product-detail'], base.sections['product-detail']);
  assert.deepEqual(next.layout, base.layout);
  assert.ok(next.sections['customer-order-detail'].source.includes('lb:niche-order-presentation:v1'));
});

test('new successor factory is idempotent and does not mutate its frozen input', async () => {
  const { createCircuitThemeV201 } = await import('./packages/theme-engine/src/circuit-theme-v201');
  const base = original(), before = JSON.stringify(base), next = createCircuitThemeV201(base);
  assert.equal(JSON.stringify(base), before);
  assert.deepEqual(createCircuitThemeV201(next), next);
});
