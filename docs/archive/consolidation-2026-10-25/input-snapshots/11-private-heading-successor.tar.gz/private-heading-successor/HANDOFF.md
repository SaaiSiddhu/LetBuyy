# Applied private Circuit heading successor

**Ready for exact source review; Main and runtime admission remain pending.** This extends the existing Circuit package through a proposed explicit2.0.1 selection. It does not alter the captured2.0.0 factory, implicit/default distribution, existing releases or M1.

The actual private source tree is rooted here. `packages/theme-engine/src/circuit-theme-v201.ts` is a new thin successor factory over the canonical Circuit factory and niche saved-order presentation. The private copy of `first-party-theme-catalog.ts` adds the explicit `circuitVersion:'2.0.1'` option only inside the existing explicit-v2/forge branch. The two exact production deltas are in `candidate.patch`; `git apply --check` against Main succeeds, without applying it. No source/catalogue migration has been emitted.

Both source-observed inert controls are corrected for this private Circuit successor:

- A nonempty collection/search results `title` renders as a heading. Its fresh default is empty, retaining the existing default layout; clearing removes the optional heading.
- Order-detail `heading` renders beside the authoritative order number. Empty heading falls back to `Order`, retaining the prior default output.

Ordinary Liquid escaping remains in place. No product/variant electronics facts, prices, stock, query keys, checkout, identity or ledger authority changes. The inherited shared engine source is untouched; the broader inherited-order-heading issue for other themes remains with its existing owner.

The same15 actual package/schema/render tests ran before and after private application: RED6PASS/9FAIL, then GREEN15PASS/0FAIL/0SKIP. The original RED is preserved, including the absent successor selector/module and ineffective control failures. The green tests prove explicit version selection, all ten default2.0.0 and legacy catalogue outputs unchanged, other-theme isolation, matching persistence schema and real JSON document roundtrip, explicit edits, clear/fallback, escaping, saved-order facts, default HTML/style equality on collection/search/order, scope, input immutability and idempotence. These are source tests, not fifteen installed lifecycle cases.

Three further tests execute the actual current editor and registry pure helpers through normalize → build save payload → JSON wire → matching engine validation → reload normalization → canonical Liquid compilation → actual render. Explicit and cleared values survive on all three templates, with zero validation issues/warnings, preserved header/footer identities and untouched other templates. Six actual HTMLs and six wire JSONs are in `test-results/editor-wire01/`. The Tamil/Hindi text case proves serialization/rendered text, not browser fonts or accessibility.

The final broad editor-file pin check detected an authorized shared Editor page change after the test. `EDITOR_WIRE_DRIFT_REVIEW.json` preserves both whole-file hashes. The exact25 extracted declarations and transpiled helper bytes remain identical; registry source remains exact. Reuse is restricted to those pure helpers. No current whole-page/callback/UI acceptance is claimed, and the original test receipt is unchanged. Do not rerun these unchanged helper tests merely because unrelated page wiring changed.

Scoped strict noEmit for the new leaf and private catalogue passes. The first standalone command omitted the package's strict setting and produced inherited discrimination/optional-property diagnostics; its exit2 log remains alongside the corrected strict exit0 log. No broad app build, lint gate, native PostgreSQL or browser run is claimed.

`SUCCESSOR_MANIFEST.json` pins the87 unchanged Main base inputs, the applied private overlay, exact patch and tests, schema/bundle hash, real outcomes, dependency boundary and admission needs. `CANDIDATE_SCHEMA.json` is the actual private package persistence schema, not a DB/catalogue emission. The proposed private version/number needs allocator catalogue/version admission before any install; there is no request to overwrite publisher393 or unqualified394.

The requesting monitor's `heading-corrections-independent-review.json` records independent Circuit source-render checks and a matching private catalogue pin. It predates this final sealed manifest and does not list every successor leaf/test/manifest hash. Retain its narrow positive findings; full exact sealed-candidate review remains pending. It is not whole-theme review acceptance.

Main application requires the current named writer lease, exact source review, explicit catalogue/version lineage and affected normal candidate gates. Then prove actual merchant save/full reload, private preview, publish/public readback and the remaining original/additional lifecycle cases. The shared Editor owner currently owns block-action source changes; Circuit takes no concurrent shared write or browser/native/build lease. Fixture936 has expired and is not used.

The earlier `private-title-proposal/` is preserved as the initial source experiment. **Use this successor patch for review; do not apply the initial same-version experiment.** Count02 is reused unchanged. Manufacturer/compatibility-evidence facets remain a separate design/contract question; this candidate adds neither data nor filters.
