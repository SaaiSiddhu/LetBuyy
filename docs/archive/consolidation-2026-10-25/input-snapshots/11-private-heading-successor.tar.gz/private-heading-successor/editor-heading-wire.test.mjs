// Actual current editor/registry pure helpers, not a substitute editor or browser test.
import assert from 'node:assert/strict';
import test from 'node:test';
import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import ts from 'typescript';
import * as domain from './packages/theme-engine/src/index.ts';
import { createFirstPartyCatalogBundle } from './packages/theme-engine/src/first-party-theme-catalog.ts';
import { LiquidRenderer } from './packages/theme-engine/src/theme-renderer.ts';
import { DEFAULT_THEME_SETTINGS } from './packages/theme-engine/src/theme-settings.ts';

const here = dirname(fileURLToPath(import.meta.url));
const root = resolve(here, '../../../../../..');
const out = resolve(here, 'test-results/editor-wire01');
assert.ok(!existsSync(out), 'keep each actual source test run immutable');
mkdirSync(out, { recursive: true });
const hash = value => createHash('sha256').update(value).digest('hex');
const pagePath = 'apps/merchant/web/src/app/[store]/online-store/themes/[themeId]/editor/page.tsx';
const registryPath = 'services/api-gateway/src/execution/schema-registry-execution.adapter.ts';
const pageText = readFileSync(resolve(root, pagePath), 'utf8');
const page = ts.createSourceFile(pagePath, pageText, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
const declarations = new Map();
for (const node of page.statements) {
  if (ts.isFunctionDeclaration(node) && node.name) declarations.set(node.name.text, node.getText(page));
  if (ts.isVariableStatement(node)) for (const decl of node.declarationList.declarations) if (ts.isIdentifier(decl.name)) declarations.set(decl.name.text, node.getText(page));
}
const needed = new Set(['normalizeSettingsSchema', 'normalizeEditorState', 'buildDraftConfig']);
for (const name of needed) {
  assert.ok(declarations.has(name), `actual editor declaration ${name}`);
  const tree = ts.createSourceFile('editor-helper.ts', declarations.get(name), ts.ScriptTarget.Latest, true);
  const visit = node => { if (ts.isIdentifier(node) && declarations.has(node.text)) needed.add(node.text); ts.forEachChild(node, visit); };
  visit(tree);
}
const dependencies = ['getDefaultStorefrontThemeTemplate', 'hasRenderableThemeTemplate', 'letbuyyPrimitiveTokens', 'isUnchangedCoreDemoCategoryBlocks', 'isFirstPartyCoreBundleSlug', 'MAX_BUNDLE_BLOCK_NESTING_DEPTH', 'ThemeEditorTemplateKeySchema', 'normalizeEditorSchemaField', 'resolveFieldDefault'];
const tokens = createRequire(resolve(root, 'apps/merchant/web/package.json'))('@letbuyy/ui/tokens').letbuyyPrimitiveTokens;
const editorCode = ts.transpileModule([...needed].map(name => declarations.get(name)).join('\n'), { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS } }).outputText;
const helpers = new Function(...dependencies, `${editorCode};return {normalizeSettingsSchema,normalizeEditorState,buildDraftConfig};`)(...dependencies.map(name => name === 'letbuyyPrimitiveTokens' ? tokens : domain[name]));
const registryText = readFileSync(resolve(root, registryPath), 'utf8');
const registry = ts.createSourceFile(registryPath, registryText, ts.ScriptTarget.Latest, true);
const registryCode = registry.statements.filter(node => ts.isFunctionDeclaration(node) && ['asRecord', 'isLiquidBundle', 'buildBundleTemplateConfig'].includes(node.name?.text)).map(node => node.getText(registry)).join('\n');
const buildConfig = new Function(`${ts.transpileModule(registryCode, { compilerOptions: { target: ts.ScriptTarget.ES2022 } }).outputText};return buildBundleTemplateConfig;`)();
const bundle = createFirstPartyCatalogBundle('letbuyy-forge', { designVersion: '2.0.0', circuitVersion: '2.0.1' });
assert.equal(bundle.package.version, '2.0.1');
const base = buildConfig(bundle);
const manifest = domain.buildLiquidThemePackagePersistencePayload(bundle).schemaManifest;
const settings = helpers.normalizeSettingsSchema(manifest.settings_schema);
const runtime = { sectionSchemas: manifest.section_schemas, settingsSchema: settings };
writeFileSync(resolve(out, 'actual-helper-inputs.json'), JSON.stringify({ classification: 'SOURCE_HELPER_EXTRACTION_NOT_MOUNTED_EDITOR_OR_AUTH_PROOF', inputs: [{ path: pagePath, sha256: hash(pageText) }, { path: registryPath, sha256: hash(registryText) }], actualEditorDeclarations: [...needed].sort(), extractionSha256: hash(editorCode), candidateBundleSha256: hash(JSON.stringify(bundle)) }, null, 2) + '\n');

for (const scope of [
  { key: 'collection', type: 'collection-product-list', field: 'title', label: 'Tamil சோதனை Hindi परीक्षण' },
  { key: 'search', type: 'collection-product-list', field: 'title', label: 'Search circuit heading' },
  { key: 'customers/order', type: 'customer-order-detail', field: 'heading', label: 'Your Circuit receipt' },
]) {
  test(`${scope.key}: actual editor normalize/build, JSON wire, validator and Liquid compile retain heading edit/clear`, async () => {
    for (const [index, value] of [scope.label, ''].entries()) {
      const state = helpers.normalizeEditorState(base, 'letbuyy-forge', scope.key, runtime.sectionSchemas, settings);
      const section = state.sections.template.find(row => row.type === scope.type);
      assert.ok(section);
      section.settings[scope.field] = value;
      const wire = JSON.parse(JSON.stringify(helpers.buildDraftConfig(base, 'letbuyy-forge', state, scope.key)));
      assert.deepEqual(domain.collectThemeTemplateValidationIssues({ templateConfig: wire, runtime, themeSlug: 'letbuyy-forge' }), []);
      const reloaded = helpers.normalizeEditorState(wire, 'letbuyy-forge', scope.key, runtime.sectionSchemas, settings);
      assert.equal(reloaded.sections.template.find(row => row.id === section.id).settings[scope.field], value);
      const compiled = domain.compilePortableToLiquidBundle(wire, { baseBundle: bundle });
      assert.deepEqual(compiled.warnings, []);
      assert.equal(compiled.bundle.package.version, '2.0.1');
      assert.equal(compiled.bundle.templates[scope.key].sections[section.id].settings[scope.field], value);
      for (const group of ['header', 'footer']) assert.deepEqual(compiled.bundle.templates[group].order, bundle.templates[group].order);
      for (const key of Object.keys(bundle.templates).filter(key => ![scope.key, 'header', 'footer'].includes(key))) assert.deepEqual(compiled.bundle.templates[key], bundle.templates[key], `untouched template ${key}`);
      const rendered = await new LiquidRenderer().render({
        context: { storeId: '11111111-1111-4111-8111-111111111111', subdomain: 'circuit-wire-only', path: '/', previewMode: false, locale: 'en-IN' },
        storeTemplate: { themeId: 'letbuyy-forge', themeSettings: DEFAULT_THEME_SETTINGS, sections: [] },
        routeTemplate: { id: scope.key, type: scope.key, layoutKey: 'theme', sections: [] },
        liquidBundle: compiled.bundle, liquidTemplateKey: scope.key,
        liquidContext: { shop: { name: 'Synthetic source wire' }, collection: { title: 'Accessories', products: [], total: 0 }, buyer: { id: 'synthetic-not-authenticated' }, order: { id: 'synthetic-unpersisted', number: 'SOURCE-102', status: 'pending', line_items: [], total: 0, currency: 'INR' } },
      });
      assert.equal(rendered.status, 'rendered');
      assert.deepEqual(rendered.warnings, []);
      const html = rendered.liquid.contentForLayout;
      if (value) assert.ok(html.includes(value));
      else if (scope.key === 'customers/order') assert.ok(html.includes('<h1>Order #SOURCE-102</h1>'));
      else assert.ok(!html.includes(scope.label));
      const name = `${scope.key.replace('/', '-')}-${index}`;
      writeFileSync(resolve(out, `${name}.wire.json`), JSON.stringify(wire, null, 2) + '\n');
      writeFileSync(resolve(out, `${name}.html`), html);
    }
  });
}
