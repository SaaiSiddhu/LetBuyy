#!/usr/bin/env python3
"""Report LetBuyy checkout metadata and document locators, without mutations.

No network, database, Docker, credential or signing reads. Does not read file
bodies or certify product readiness. Git optional locks are disabled.
"""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import subprocess
import sys


DEFAULT_WORKSPACE = Path('/Users/saai_mithra/Projects/LetBuyy-Workspace')
REPO_DOCUMENTS = (
    'AGENTS.md',
    'CLAUDE.md',
    'docs/README.md',
    'GOVERNANCE_REWRITE_2026_06_10/LETBUYY_CONSTITUTION.md',
    'GOVERNANCE_REWRITE_2026_06_10/LETBUYY_CANONICAL_SYSTEMS.md',
    'docs/evidence/foundation-programme-2026-09-26/FOUNDATION_PROGRAMME.md',
    'docs/evidence/foundation-programme-2026-09-26/DECISIONS_AND_ACCEPTANCE.md',
    'docs/evidence/foundation-programme-2026-09-26/RESEARCH_AND_CLOUD_FINDINGS.md',
    'docs/evidence/foundation-programme-2026-09-26/EXECUTION_CONTRACT.md',
    'docs/evidence/phase1r-integration-2026-09-27/INTEGRATION.md',
    'docs/evidence/phase2-2026-09-27/PHASE2_DECISIONS.md',
    'docs/evidence/phase2-2026-09-27/PHASE2_TRANSITION_PLAN.md',
    'docs/evidence/phase2-2026-09-27/PHASE2_LOCAL_QUALITY_AND_THEME_ISOLATION.md',
    'docs/evidence/phase2-2026-09-27/P2_OPERATOR_QUEUE_GATE_ACCEPTANCE.md',
    'docs/evidence/phase2-2026-09-27/P2_OPERATOR_MUTATION_INTEGRITY_ACCEPTANCE.md',
    'docs/evidence/local-environment-2026-09-28/RUNBOOK.md',
    'services/api-gateway/src/__tests__/owned-db/README.md',
    'package.json',
    'services/api-gateway/package.json',
)
WORKSPACE_DOCUMENTS = (
    'README_TRANSFER.md',
    'NewMacSetup/LETBUYY_NEW_MAC_CTO_CONTEXT.md',
    'NewMacSetup/README.md',
    'NewMacSetup/VERIFICATION.md',
    'NewMacSetup/PHASE_EXECUTION_STANDARD.md',
    'DatabaseBackups/BACKUP_SCOPE.txt',
)


def git(repo: Path, *args: str) -> str:
    env = os.environ.copy()
    env['GIT_OPTIONAL_LOCKS'] = '0'
    # Prevent ambient variables from redirecting the read into another repo.
    for key in ('GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_COMMON_DIR'):
        env.pop(key, None)
    result = subprocess.run(
        ['git', '--no-optional-locks', '-C', str(repo), *args],
        capture_output=True, text=True, timeout=20, env=env, check=False,
    )
    if result.returncode:
        # No stderr: Git configuration/hooks could disclose private details.
        raise ValueError('Git metadata unavailable (exit %d)' % result.returncode)
    return result.stdout.rstrip('\n')


def inside(path: Path, root: Path) -> bool:
    return path == root or root in path.parents


def locators(root: Path, names: tuple[str, ...]) -> list[str]:
    return [str(root / name) for name in names if (root / name).is_file()]


def checkout(repo: Path) -> dict:
    top = Path(git(repo, 'rev-parse', '--show-toplevel')).resolve()
    if top != repo.resolve():
        raise ValueError('Candidate is not a checkout root')
    branch = git(repo, 'branch', '--show-current') or '(detached HEAD)'
    head = git(repo, 'rev-parse', 'HEAD')
    # Disable external diff/text conversion. Untracked names only, no contents.
    status = git(repo, '-c', 'core.fsmonitor=false', 'status', '--short',
                 '--untracked-files=normal')
    evidence = repo / 'docs/evidence/phase2-2026-09-27'
    records = sorted(str(p) for p in evidence.glob('*.md') if p.is_file())
    return {
        'path': str(repo), 'branch': branch, 'head': head,
        'status_entries': status.splitlines() if status else [],
        'documents': locators(repo, REPO_DOCUMENTS),
        'phase2_record_locations': records,
        'verification': 'Git metadata only; no runtime/tests/cloud verified',
    }


def discover(workspace: Path) -> tuple[list[Path], list[str]]:
    candidates: set[Path] = set()
    warnings: list[str] = []
    if (workspace / '.git').exists():
        candidates.add(workspace)
    # Only immediate LetBuyy-named children, not backups, SDK or arbitrary repos.
    for path in workspace.iterdir():
        if path.name.lower().startswith('letbuyy') and path.is_dir():
            resolved = path.resolve()
            if inside(resolved, workspace) and (resolved / '.git').exists():
                candidates.add(resolved)
    # Registered worktrees may have different names. Inspect only paths inside
    # the selected workspace; external worktrees are not accessed automatically.
    for repo in sorted(candidates):
        try:
            inventory = git(repo, 'worktree', 'list', '--porcelain')
        except (ValueError, subprocess.TimeoutExpired):
            warnings.append('Could not read worktree inventory: ' + str(repo))
            continue
        for line in inventory.splitlines():
            if line.startswith('worktree '):
                path = Path(line[9:]).resolve()
                if inside(path, workspace) and (path / '.git').exists():
                    candidates.add(path)
                elif not inside(path, workspace):
                    warnings.append('External registered worktree not inspected')
    return sorted(candidates), sorted(set(warnings))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', type=Path, default=DEFAULT_WORKSPACE,
                        help='Workspace containing the LetBuyy checkouts')
    parser.add_argument('--repo', type=Path,
                        help='Inspect this explicit checkout only')
    args = parser.parse_args()
    workspace = args.workspace.expanduser().resolve()
    if args.repo:
        repo = args.repo.expanduser().resolve()
        if not repo.is_dir():
            print(json.dumps({'error': 'Explicit checkout directory unavailable'}))
            return 2
        candidates, warnings = [repo], []
        # Explicit single-repo use on another host must not inspect the default
        # Mac workspace or unrelated sibling repositories.
        if args.workspace == DEFAULT_WORKSPACE and not inside(repo, workspace):
            workspace = repo.parent
    else:
        if not workspace.is_dir():
            print(json.dumps({'error': 'Workspace unavailable; pass --workspace or --repo'}))
            return 2
        candidates, warnings = discover(workspace)
    result = {
        'workspace': str(workspace),
        'workspace_documents': locators(workspace, WORKSPACE_DOCUMENTS),
        'checkouts': [], 'warnings': warnings,
        'scope': 'Read-only metadata/locators; no auto-selection or readiness claim',
    }
    for repo in candidates:
        try:
            result['checkouts'].append(checkout(repo))
        except (ValueError, subprocess.TimeoutExpired, OSError) as exc:
            result['warnings'].append(str(repo) + ': ' + type(exc).__name__)
    print(json.dumps(result, indent=2))
    return 0 if result['checkouts'] else 2


if __name__ == '__main__':
    sys.exit(main())
