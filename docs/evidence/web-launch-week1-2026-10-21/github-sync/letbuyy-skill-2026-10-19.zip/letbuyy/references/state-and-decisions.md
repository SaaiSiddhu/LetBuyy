# State recovery, accepted decisions and next work

## Snapshot contract

Assembled 3 October 2026, Asia/Kolkata, from actual Git metadata, the predecessor
chat and current Phase 2 evidence. This is a last-known bootstrap, not an always
current claim. On invocation, compare actual branch/HEAD, existing evidence and
source changes. Never reset to this SHA or assume newer work is invalid.
Treat a missing source as unavailable, not as proof of deletion or completion.

| Checkout | Last observed full HEAD | Meaning |
| --- | --- | --- |
| Primary `LetBuyy` / `develop` | `130b669d86720c436385e4c6a604da4b57000276` | Phase 1R integrated locally |
| `LetBuyy-phase2` | `eb49fe27cae28612d10884dd5513242a40afd64a` | Phase 2 operator queue access and acceptance-command repair recorded |
| `LetBuyy-phase1r` | `7e23760aa046157e516d4661d292301d3082369c` | Accepted historical Phase 1R checkpoint |

Expected transfer HEAD `6eb01d95867e1c7d0eb15c704eeaf2195ca8cc68` is historical.
The new Mac restore preserved unpublished history and research; a fresh clone
must not replace it. The current state is newer legitimate work.

## Preservation inventory

Phase 2 had nine user-owned `analysis_options.yaml` modifications:
`apps/deferred/delivery/mobile`, `apps/merchant/mobile`, and
`packages/dart/{core,marketplace_core,marketplace_models,marketplace_services,
marketplace_ui_kit,models,ui_kit}`. Three untracked status paths:
`apps/deferred/delivery/mobile/ios/Flutter/ephemeral/.swift_pm.lock`,
`apps/deferred/delivery/mobile/ios/Flutter/ephemeral/Packages/`,
`docs/evidence/local-environment-2026-09-28/`.
These twelve status entries were observed on 3 October. Inventory again; do
not revert/stage them automatically or assume generated files are disposable.
Preserve local environment/signing material, old Mac/T7 backups, restored
database/storage, unrelated worktrees and EDYNOX resources.

## What has been established

| Area | Dated evidence and limits |
| --- | --- |
| Transfer/setup | Owned restore/toolchain and local backend established; initial migration-258 pristine copy and working restore kept. Backups are preserved. |
| Phase 1R | Canonical Android entry and account journeys; active Firebase product authority retired; account isolation and honest shipping/payment-unavailable behavior. Locally accepted and integrated. |
| Local/S26 use | Owner separately confirmed local apps and physical S26 verification. Do not restart runtime bring-up or reinstall because an old prompt asks for it. Reverify only missing or changed relevant behavior. |
| Staff mutations | Real staff provisioning/API path, permissioned create/read/edit/delete, forbidden/cross-store denial, downgrade taking effect on the existing identity; owner unaffected. Signed gateway credentials prove authorization, not independent browser login. |
| Target transition | Real target repository/backfill/reconciliation, deterministic known staff grants and target-only divergence proof. Legacy staff permission remains authoritative. |
| Shadow bound | 800 ms bounded shadow path recorded, cooperative cancellation plus concurrency controls. Verify current configuration; Promise.race is not cancellation of unsupported work. |
| Authentication | Atomic OTP consumption; console magic-link single use; session checks on formerly unprotected console actions. |
| Console revocation | Config allowlist rechecked per request, but changed hosting env must reach running instances; not a durable global per-session revocation authority. Re-adding an email can reactivate an unexpired cookie. |
| Test infrastructure | Cluster isolation and hermetic gateway DB lane; restored `snaz` data is no longer the test fixture. Do not delete old synthetic rows without a separately authorized plan. |
| Privacy intake | Production worker, concurrency uniqueness, buyer ownership, realm isolation, topic filtering, truthful lifecycle and internal-note separation verified against owned storage. Intake is not export/deletion fulfillment. |
| Support replies | Migration 264 makes message, ticket state, SLA clocks and audit atomic; failures are not false success. |
| Queue access O1 | Active platform viewer/reviewer, operator and lead, plus allowlisted super admins reach support through production mounting; other protected operations remain protected. |
| Package acceptance | Gateway contracts run from repository root, avoiding declaration-only Hono path alias runtime resolution under package tsconfig. |

Sources under `docs/evidence/phase2-2026-09-27/`:
`PHASE2_STAFF_MUTATION_AND_SHADOW_COMPLETION.md`,
`D03_TARGET_DATA_SHADOW_ACCEPTANCE.md`,
`PHASE2_TEST_BASELINE_RECONCILIATION.md`,
`PHASE2_LOCAL_QUALITY_AND_THEME_ISOLATION.md`,
`P2_HERMETIC_GATEWAY_DB_ACCEPTANCE.md`,
`P2_PRIVACY_CONCURRENCY_DB_ACCEPTANCE.md`,
`P2_OPERATOR_QUEUE_CORRECTNESS_ACCEPTANCE.md`,
`P2_OPERATOR_QUEUE_GATE_ACCEPTANCE.md` and `PHASE2_DECISIONS.md`.
Read the relevant later dated corrections; several older introductions remain
intentionally historical and no longer describe the current implementation.

## Accepted decisions: do not reask

- D03: local merchant/staff target transition preparation and independent
  shadow comparison; not authoritative cutover or buyer/operator migration.
- D04: proposed Reviewer/Moderator/Administrator capabilities for support,
  mapped to existing viewer/operator/lead tiers; separate recovery/high-risk
  policy was not bundled into that approval.
- D05: initial restricted export field scope: own profile, addresses,
  authored request content and own orders. Not route exposure or release policy.
- O1, owner answer 2 October: reviewer/operator/lead may read buyer privacy
  requests, buyer-authored notes and internal notes. Reviewer reads only;
  operator has existing action permissions; lead manages assignment/macros.
  Require active platform membership; merchants never inherit platform access.
- 3 October: Codex directly performs requested engineering, research, testing,
  security fixes and continuity. Claude prompts are now optional requested output.

## Open requirements, not silently approved

D03 cutover and sustained shadow observation; two F2.1 issuer deviations;
operator assignment authority, bootstrap/recovery, MFA enrollment/rotation,
high-risk dual control, console delivery and actual moderation/impersonation
callers; export requester verification and protected release; retention,
erasure, legal hold and incident ownership; hosted delivery/release.
The non-allowlisted platform `admin` tier remains denied by O1; admitting it
requires a concrete new decision. Existing restored synthetic rows (Q3) remain
untouched. Inspect actual dependencies before claiming these block all work.

Three operator read routes were observed returning tenant-guard 500s:
outbox, risk overview and trust-safety overview. Internal credential replay
protection was observed per-isolate in memory, not global. Package tsconfig
still traps tsx invoked under declaration-only aliases. These are recorded
findings, not fixed by the queue mandate. Reproduce the relevant one before
making a present claim or prioritizing a repair.

## Last recorded verification, not rerun by this skill

| Check | Source checkpoint | Result recorded |
| --- | --- | --- |
| Root test | `0dceffa4` | 2594 total; 2579 pass, 0 fail/cancel, 15 human-required skips, 0 TODO |
| Gateway package | `0dceffa4`, fresh clone `ac2e9f40` | Unit 1328 total: 1327 pass + 1 TODO; owned DB 75/75; contracts 322/322; exit 0 |
| Typecheck | `0dceffa4` | 81 tasks, 80 cached; exit 0 |
| Lint | `0dceffa4` | 5 cached tasks, 0 errors; gateway has no lint task |
| Governance tests | fresh clone `ac2e9f40` | 330/330, no skips |
| Real governance gate | fresh clone `ac2e9f40`; documents-tip result in task report | 114 pass, 0 fail; 1 outside lane selection |

Root does not include gateway unit lane. Do not sum overlapping checks into a
unique test total. Earlier red gate and invalid post-cleanup clone results are
documented; later repairs supersede them, not erase them. Affected tests should
be rerun for new source changes; reading records alone is not fresh execution.

## Next task at this snapshot

`P2-OPERATOR-MUTATION-INTEGRITY`: durable action idempotency and atomic mandatory
database writes for existing support actions (create, reply/internal note,
assign, escalate/case linkage, resolve, satisfaction, macros as applicable).
Current success retried can duplicate effects. Reply is atomic already, other
actions have split writes. Reproduce/design within current source before edits.
Preserve current authorization before cached replay; same action key with fresh
request credentials; worker + owned DB concurrency/fault/lost-response proof.

This task was proposed, not completed at `eb49fe27`. Full Phase 2 is still open.
Nine later parent phases have pending acceptance, though reusable components
already exist. Do not infer a completion percentage or launch date from phase
counts. When newer evidence completes this task, follow it and advance the
existing next-task record rather than reexecuting this snapshot.
