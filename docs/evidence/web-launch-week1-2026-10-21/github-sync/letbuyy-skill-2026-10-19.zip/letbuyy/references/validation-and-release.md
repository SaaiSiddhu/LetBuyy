# Validation, evidence review and phase closure

Choose validation that proves the requested behavior and its risk. A reversible
text-only edit does not need product-wide testing. Shared auth/tenancy/money
changes need meaningful integration and relevant negative cases. Run affected
checks first; broaden once the change stabilizes or a failure warrants it.

## Known commands: verify current scripts first

Run these from the selected repository root, as appropriate:

~~~sh
pnpm run test:unit:gateway
pnpm run test:db:gateway
pnpm --filter @letbuyy/api-gateway run test
pnpm run test:contracts
pnpm run test
pnpm run typecheck
pnpm run lint
~~~

One owned DB suite uses the executable runner, not direct tsx:

~~~sh
node scripts/governance/run-executable-suites.mjs --suite services/api-gateway/src/__tests__/owned-db/operator-queue-correctness.postgres.test.ts
~~~

Verify the suite name exists and flags remain supported. `requireOwnedDatabase()`
refuses direct execution without runner ownership. Root `pnpm run test` does not
include gateway unit tests; package acceptance includes unit, owned DB and
contracts. Counts overlap; do not invent a unique combined total.

Gateway contracts must run from the workspace root: the package's tsconfig
maps Hono helpers to declaration files for type checking, and package-cwd tsx
can resolve an empty runtime module. Do not casually restore the old command
or weaken the contract/governance pins. A current production-bundler result
must be established separately from tsx runtime resolution.

## Owned fixtures and real boundaries

Read `services/api-gateway/src/__tests__/owned-db/README.md` before database
acceptance. The runner provisions labelled owned clusters, pristine templates,
per-suite cloned databases and real PostgREST, verifies markers/REST ownership,
then runs the production worker harness. It must not fall back to `.dev.vars`,
the restored development store or hosted databases. Required acceptance must
execute, not skip/todo or silently succeed with no tests.

Create fresh synthetic tenant/account IDs and `.invalid` addresses. Model
actor identities, supported provisioning and real constraints. For concurrency
use barriers/named fault seams rather than luck or sleep. Check actual rows,
audit/outbox/receipt/message/SLA/case counts and invariant preservation.
Discard owned fixtures rather than disabling triggers to remove immutable rows.
Bound parallelism; cluster-global roles need cluster isolation or serial suites.

Worker + service-role storage proves application guards/constraints, not RLS.
Runtime-role claims/GUC/pool tests separately prove DB isolation. Normal browser
or phone authentication separately proves the product login journey.

## Governance cleanup trap

The real governance gate performs generated-artifact cleanup and can remove
workspace `node_modules`. It belongs in a fresh disposable local clone under
the established safe method, not the user's active checkout or restored stack.
Inspect the current script before running. Install frozen dependencies and run
package acceptance BEFORE the destructive gate in that clone. Then run relevant
governance tests and `node scripts/validate-governance.mjs --lane=gate`.
An acceptance run after cleanup is not a clean-clone result; reinstall first if
a new observation is justified. Clone by exact owned path and preserve relevant
logs before exact cleanup. Do not prune shared resources.

Root tests, governance test files and actual validators are distinct lanes.
Root can pass while a validator fails; run the applicable real lane. Stale-artifact
sweep behavior, lane selection, not-applicable validators, advisories and cached
task coverage need precise reporting. Cached lint is not newly inspected gateway
lint, especially when the gateway has no lint task.

## Test strength and regression accounting

Where needed, prove tests detect the defect by temporarily removing the relevant
safeguard in an isolated safe copy, observing a behavioral failure and restoring
exact bytes. Do not mutate assertions or count compile failures as behavioral
proof. Use a small decisive set rather than inflating mutation counts. Do not
run such destructive controls in a shared owner tree with unrelated changes.

Record failing names, command/exit, environment and tested SHA. Separate new,
resolved, known baseline and uncertain attribution. Matching names or no overlap
with the latest few commits is insufficient to call all failures pre-existing.
Compare a meaningful pre-phase/source baseline where feasible, in owned isolation.
Fix failures introduced by this task. Preserve unexplained or external failures
honestly instead of weakening rules, converting required tests to skips or calling
the entire gate green.

Repeat affected owned suites on final content when concurrency/fault correctness
or the phase contract requires it. Repeat broad gates only for changed relevant
source, actual failures or a specific acceptance requirement. Documentation-only
updates do not invalidate unrelated source tests automatically.

## Evidence vocabulary

| Label | What it establishes |
| --- | --- |
| PLANNED | Accepted/proposed work, no implementation claim |
| IMPLEMENTED | Source behavior exists, coverage and integration still specified |
| LOCAL VERIFIED | Stated local command/runtime path executed with observed result |
| DEVICE VERIFIED | Named real device/build/backend journey executed |
| SANDBOX VERIFIED | Real provider test-mode flow and IDs joined to canonical records |
| BLOCKED | Exact unmet external/policy/authority dependency, unblocked work separately completed |
| ACCEPTED | Required phase criteria met on identified evidence; not automatic deployment |
| DEPLOYED | Authorized hosted change observed on identified environment/lineage |

Keep own execution, prior reports, owner testimony and independent review separate.
Do not invent reviewer signatures, security certification, waivers or legal/CA
approval. If report/source conflict, identify exact gap and consequence.

## Closure and release

A parent phase closes against its actual requirements, including real actors,
reachable interfaces, persistence, allowed/forbidden actions and failure recovery.
Intake is not export/erasure, balanced local ledger is not provider settlement,
debug APK is not release signing, startup is not login and review is not launch.

Prepare a reviewable release candidate, migration/rollback plan, artifact/config
lineage, known limits and recovery proof before a missing release approval.
Existing standing limits exclude merge/push/deploy/hosted cutover/live messages/
payments; use a later explicit authorization if supplied. Do not ask twice for
an already-authorized step or use skill invocation as blanket release authority.
