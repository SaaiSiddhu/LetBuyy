# Security analysis and fixes

Apply to requested security work and the actual security boundary changed by
identity, tenancy, money, privacy, files or privileged operations. Use source,
runtime role and concrete exploit/failure evidence. Scope security depth to the
change; do not create an unsolicited platform-wide audit for a cosmetic edit.

## Record and prove findings

For each actionable defect state boundary, attacker/caller prerequisites,
reproduction, expected versus observed behavior, impact and current exposure.
Distinguish confirmed runtime defects, source-level candidates, configuration
limitations and policy questions. Reproduce in an owned fixture before claiming
present exploitability. Preserve sanitized proof and focused regression coverage.

When authorized to fix, implement the coherent correction and exercise allowed
behavior beside the denial. A blocked action without a positive control can be
a broken fixture, kill switch or missing dependency. Never weaken a guard just
to let a test reach the feature. Inspect every caller of shared security helpers.

## LetBuyy security boundaries

| Domain | Required reasoning and useful negative cases |
| --- | --- |
| Identity | Issuer/signature/algorithm/audience/realm/token-use/expiry/replay/session epoch; unverified email cannot link ownership; consumers do not gain mint authority |
| Browser sessions | PKCE, callback/redirect allowlists, state, cookie origin/CSRF and scoped merchant-domain access; custom domains cannot obtain platform credentials |
| Staff | Supported provisioning and independent identity; live membership/permission on each action; downgrade/revocation on the existing session; resource/site substitution denied |
| Operators | Active platform membership, distinct endpoint scopes, reviewer read-only, approved tier gate and existing MFA/step-up; merchant role names do not admit platform access |
| Routing | Production registration/mount order is part of authorization; global/wildcard middleware can protect siblings or silently prevent intended access |
| Tenant isolation | App query predicates + ownership + RLS/FORCE/per-transaction GUC; missing/wrong context denies; context cannot cross pooled transactions |
| Privacy | Buyer ownership and realm isolation; requester versus internal note visibility; truthful request/fulfillment states; supported export release authority; no unauthorized erasure |
| Files/media | Authorized tenant/reviewer, private pending assets, upload size/type/duration, callback signature, immutable revision binding, signed URL expiry/revocation limits |
| Money | Server totals/order authority, verified capture, durable replay safety, balanced immutable ledger, integer money, no custody; refunds and settlements one effect |
| Ads | Captured funding, billable event validity, budget races, duplicate events, attribution/reversal; sponsored placement shares product/reel eligibility |
| Secrets/logs | No credential/PII/bearer URL leakage, no real secret in evidence, sanitized 5xx responses and bounded telemetry |

## Production path versus substitutes

The gateway owned DB harness invokes the real worker export, middleware and
production dependencies with generated real signed credentials. That verifies
the API authorization chain. Router-only tests cannot prove mount-order access;
injected auth context cannot prove signature/login behavior. Signed HMAC requests
alone cannot prove normal browser sign-in, consent or Android callback navigation.

The owned lane uses service_role through PostgREST and bypasses RLS. It proves
application guards, RPC constraints and triggers, not runtime-role RLS. RLS tests
need a real non-superuser role, live claims/GUC semantics, positive and denied
reads/writes, and commit/rollback/pool-isolation checks. Do not report superuser
SQL results as tenant-security evidence.

## Current sensitive seams to retain

- O1 admits only viewer/operator/lead platform members plus allowlisted super
  admins to support. Non-allowlisted `admin` tier remains excluded. Do not narrow
  incident-command's global gate: four sibling routers historically rely on it.
- Fresh signed internal credentials are single-use in an isolate. The recorded
  in-memory replay map is not a global cross-isolate replay guarantee. Action
  idempotency receipts cannot substitute for credential security.
- Console config allowlist checks require env updates to reach running instances.
  They are not durable per-session invalidation; re-adding an email may revive
  an unexpired cookie. The console shared backend token identifies a service,
  not the individual human operator. Verify where person/MFA checks actually run.
- OTP and magic-link consumption remain atomic under simultaneous redemption.
- Privacy ticket creation excludes generic privacy injection; migration 262
  uniqueness and migration 264 reply transaction remain intact.
- Resolved support tickets do not imply export/deletion completed. No fulfillment
  metadata may be injected by an ordinary requester/operator action.
- Target shadow failure cannot grant or deny actual legacy-authoritative access;
  cutover has a separate decision and observation gate.

## Fix and release discipline

Use constrained migration privileges, explicit safe search_path on definer
functions, narrow EXECUTE and validated context. Do not remove security checks
globally, disable constraints, relabel all failures as unrelated or bypass an
approval restriction. If a tool auto-review rejects an action, take a safer
authorized approach or explain the rejection/action/reason precisely if blocked.

Build a reviewable fix, run meaningful regression and behavioral failure proof,
record remaining exposure/limits and candidate source. Own testing is not an
independent audit or professional certification. Hosted deployment requires its
actual authorization; don't quietly ship a security fix under a local-only task.
