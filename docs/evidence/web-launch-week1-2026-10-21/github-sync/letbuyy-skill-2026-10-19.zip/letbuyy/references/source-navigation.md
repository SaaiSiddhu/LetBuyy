# Sources, checkout selection and authority

## Known workspace and discovery

Original workspace: `/Users/saai_mithra/Projects/LetBuyy-Workspace`.
Original personal skill location: `/Users/saai_mithra/.codex/skills/letbuyy`.
These are locators, not a requirement that future hosts share these paths.
Use the user's workspace/CWD or `--workspace`; if relocated, discover checkouts
and confirm ownership rather than asking to restore an old absolute path.

As of 3 October 2026:

| Checkout | Branch | Purpose |
| --- | --- | --- |
| `LetBuyy` | `develop` | Primary integrated Phase 1R baseline |
| `LetBuyy-phase2` | `letbuyy/phase2-shared-buyer-identity` | Current isolated Phase 2 implementation |
| `LetBuyy-phase1r` | `letbuyy/phase1r-firebase-free-marketplace` | Historical accepted Phase 1R branch/evidence |
| `LetBuyy-agrimate-cleanup` | `letbuyy/agrimate-branding-cleanup` | Separate branding; not current phase authority |

Use Git worktree metadata, task purpose and source evidence together. Do not
choose the newest folder, largest codebase or highest phase name. Prefer an
existing suitable checkout. Inspect app-managed artifacts if a new managed
worktree is needed. Never detach/reset or clone over the restored repository.
Cached remote refs do not establish remote state.

The probe reads Git metadata with optional locks disabled. It prints no remote
URL, environment file content, database credential, signing asset or log body.
It cannot establish services, Docker ownership, cloud identity or test results.

## Source precedence

System/developer constraints and current direct owner instructions apply first.
Within project governance, read the applicable chain:

1. `GOVERNANCE_REWRITE_2026_06_10/LETBUYY_CONSTITUTION.md` and approved amendments.
2. Root `AGENTS.md`, relevant local `AGENTS.md` and applicable `CLAUDE.md`.
3. `GOVERNANCE_REWRITE_2026_06_10/LETBUYY_CANONICAL_SYSTEMS.md`.
4. Current foundation/transition plans and domain governance.
5. Dated evidence and reconstructed conversations.

This skill, JSON locator and snapshots are navigation aids. They cannot override
direct instructions, create release authority or relabel scaffolds as canonical
implementation. June governance has known stale path/count/commercial claims;
reconcile current amendments and owner decisions. For small text edits, do not
read every architecture document. For identity, tenancy, schema, money or topology
decisions follow required reads. When source and an old report disagree, inspect
changes and date the correction instead of deleting history or trusting length.

## Relevant locations

| Need | Repository/workspace location |
| --- | --- |
| Product handoff | Workspace `NewMacSetup/LETBUYY_NEW_MAC_CTO_CONTEXT.md` |
| Transfer/setup | Workspace `README_TRANSFER.md`, `NewMacSetup/README.md`, `NewMacSetup/VERIFICATION.md`, `DatabaseBackups/BACKUP_SCOPE.txt` |
| Execution standard | Workspace `NewMacSetup/PHASE_EXECUTION_STANDARD.md` (reviewer/Claude role superseded) |
| Programme/research/acceptance | `docs/evidence/foundation-programme-2026-09-26/{FOUNDATION_PROGRAMME,RESEARCH_AND_CLOUD_FINDINGS,DECISIONS_AND_ACCEPTANCE,EXECUTION_CONTRACT}.md` |
| Commercial roadmap/research | `docs/evidence/commerce-2026-09-26/` |
| Phase 1R integration | Primary `docs/evidence/phase1r-integration-2026-09-27/INTEGRATION.md` |
| Phase 2 decisions/requirements | `docs/evidence/phase2-2026-09-27/PHASE2_DECISIONS.md`, `PHASE2_LOCAL_QUALITY_AND_THEME_ISOLATION.md` and dated acceptance files |
| Local runtime runbook | Phase 2 `docs/evidence/local-environment-2026-09-28/RUNBOOK.md` (untracked, user-owned) |
| Staff permissions/transition | Gateway `src/middleware/staff-permission.ts`, `src/lib/staff-permission-decision.ts`, `src/identity-foundation/` |
| Operator routing/security | Gateway `src/index.ts`, `src/routes/operations/`, `src/middleware/rbac.ts`, `src/lib/internal-auth.ts` |
| Buyer support/privacy | Gateway `src/routes/storefront/buyer-{support,privacy}-routes.ts` |
| Owned database tests | Gateway `src/__tests__/owned-db/README.md`, `owned-db-support.ts`, `gateway-harness.ts` |
| Database runner | `scripts/governance/run-executable-suites.mjs`, `owned-database-provision.mjs` |
| Actual commands | Root/package `package.json`, executable runner and validation scripts; verify before reuse |
| Apps | `apps/commerce/web`, `apps/merchant/{web,mobile}`, `apps/marketplace/mobile`, `apps/platform/identity`, `apps/internal/console`, `apps/marketing/web` |

Search with `rg`/`rg --files` within relevant roots; avoid SDK/node_modules/
backup-wide scans. Read secrets only through the needed authorized path and
never expose values. Detect moved files rather than resurrecting old locations.

## Conversation recovery

Main predecessor chat: `Verify LetBuyy Mac transfer setup`, local thread
`01a0dc82-a8e9-7842-8e1d-ce0bb1263679`. Read it through the thread tool before
relying on newly retrieved contents. Paginate when needed; a title, retrieval
summary or recent page is not the full transcript. Recover an exact decision
or missing artifact selectively rather than rereading the entire chat every
invocation. Its prompts are historical; its CTO-only arrangement is superseded
by the owner's 3 October direct implementation mandate.

EDYNOX provided an execution-quality example, not LetBuyy's data model. Do not
import Organization → Institution → Branch or ERP modules into LetBuyy.
