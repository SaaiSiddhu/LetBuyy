# Reachable product surfaces and real journeys

The phase outcome is a usable capability for its intended actor. Connect normal
navigation, typed clients, backend authorization, persistence and readback.
An adapter with no reachable caller is not a delivered product feature.

## Select maintained surfaces

Inspect current runtime classifications and relevant app/package instructions.
Typical surfaces: commerce web/Liquid storefront and hosted checkout; merchant
web/mobile; marketplace mobile; canonical identity; internal console; marketing.
Platform tools, deferred delivery/quick-commerce, frozen portals and reference
donors have different scopes. Do not activate them by directory existence or
rebuild the frozen portal while completing a narrow typed-client retry change.

Use available browser/native tools for actual UI inspection. Prefer purpose-built
APIs/CLIs for data. Follow the computer-use tool's documentation; do not claim
screens you did not inspect or ask for screenshots when the tool can inspect.
If UI facilities are unavailable, complete real authenticated API testing and
mark browser/device acceptance explicitly unverified.

## Normal actor journeys

| Actor | Examples to verify when relevant |
| --- | --- |
| Buyer | Guest browse → normal canonical login/callback → own profile/address → cart → supported checkout/order → restart/logout/A→B→A isolation |
| Storefront merchant | Draft/onboarding → channel eligibility → products → theme preview/publish → fulfill/support/refund → statements |
| Marketplace seller | Additional verification → product revision review → reel/product-match review → eligibility → commerce and settlement statements |
| Restricted staff | Owner provisions through supported flow → staff signs in independently → allowed task/forbidden task/cross-store denial → owner downgrades → existing session loses only withdrawn authority |
| Reviewer/operator/lead | Actual platform identity and normal console path → permitted queue/read/action → rejected privilege escalation → audit and revocation |

Do not substitute owner mutation for staff acceptance, fixture provisioning for
the provisioning behavior under test, direct token injection for normal login,
emulator for an explicitly required physical phone, or a static screen for a
backend connection. Synthetic fixtures may establish prerequisites, but not
replace the feature being certified.

## UI correctness

Respect canonical tokens/themes and useful responsive/mobile layouts. Include
loading/empty/denied/validation/unavailable/failure/retry states needed for the
feature. Unknown values stay unknown. Clear prior-account data synchronously
on session changes; guard pending responses and save completion. Serialize
entire mutation/persist/rollback behavior when local state consistency needs it.
Retry keys live at the logical action boundary, stable across retries and new
for deliberate new actions. Avoid double taps and false completion claims.

Use accessible labels/focus/keyboard/TalkBack where relevant. Check actual
rendering and normal navigation, not only tree snapshots. Authentication,
moderation and provider honesty should help users make decisions; internal
implementation details should not clutter product flows.

## Local stack and physical S26

The owner reported local apps and physical S26 already verified. Existing
runbook is `docs/evidence/local-environment-2026-09-28/RUNBOOK.md` in Phase 2.
Reuse it and recheck source/config only when requested or a change invalidates
evidence. Do not repeat full bring-up/reinstall from old prompts.

For a requested runtime/device task: inventory owned services and occupied
ports, start dependencies in supported order, check functional calls, match
app/backend source, discover actual adb serial/model/authorization, restore
necessary adb reverse rules after reconnect/reboot, build/install a fresh
relevant APK and exercise real backend persistence. Preserve app ID/signing.
Do not stop unrelated processes or silently clear phone/app data.

Heavy emulator/Gradle/gate concurrency previously caused severe resource pressure.
Schedule controlled sequential runs. A load snapshot is a plausible contributor,
not proof of every reboot or UI bug. Report source SHA, APK hash/build mode,
signing evidence, device and backend/config version; debug success does not
establish Android release signing, hosted app-link association or iOS runtime.

Keep working URLs/restart/stop/log references sanitized and useful. Listening
ports establish process presence, not login or a complete user journey.
