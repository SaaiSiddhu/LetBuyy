# Implementation through complete integration

Use this for requested builds/fixes/migrations/refactors/integration. The owner
now expects direct Codex delivery, not automatic handoff to Claude. A request
for another tool's prompt remains a prompt request, not permission to execute it.

## Establish scope with bounded discovery

Recover current checkout/HEAD and user changes. Read applicable governance and
local instructions, relevant phase acceptance and source. Inspect active callers,
schema/RPCs, adapters, configuration and actual UI before deciding what is missing.
Do not reproduce every historic audit or run every service before a small change.

Define the desired observable outcome and its failure/negative cases. Trace the
actual chain: screen → typed client → mounted worker route/middleware → service
or execution contract → data/transaction/outbox → readback/UI. Source evidence
must distinguish active, transitional, frozen, reserved, reference-only and dead
implementations. Extend the canonical winner instead of adding a rival stack.

Research only relevant current provider/cloud/security facts, then choose a
coherent design. Take routine engineering decisions yourself. For materially
unresolved policy, prepare examples/options and request that specific answer;
continue unblocked work. Do not fabricate approval from the phase mandate.

## Make the whole change

- Keep transport validation and permission checks at the appropriate boundary;
  follow service-owned execution contracts for business sequencing. A lower
  helper must not become an unchecked public entry point after removing a guard.
- Update canonical shared types and actual TS/Dart consumers together. Handle
  loading, validation, denied access, unavailable dependency, failure and retry
  states where the feature is presented, not only its backend implementation.
- Use actual data semantics. Unknown stock, price, shipping or timing stays
  unknown/unavailable until supported; do not invent stock=1, ₹40 or 2–3 days.
- Respect generator ownership and current module/manifests. Edit inputs rather
  than generated outputs; inspect applied migrations and rollback requirements.
- For important multi-write behavior, make mandatory state/audit/outbox/receipt
  writes atomic. Distinguish local SQL transaction effects from external calls.
- For retries, define actor/operation/target/key scope, deterministic validated
  payload fingerprint, replay result, mismatch conflict, concurrency and failed
  attempt behavior. Persist successful mutation and receipt atomically.
- Revalidate current authority before replay. Fresh signed request credentials
  and the same logical action key solve different problems. A fresh key on every
  HTTP retry defeats action deduplication.
- Do not assert cancellation from Promise.race. Propagate AbortSignal where
  supported and bound abandoned/outstanding work where cancellation is absent.
- Tenant/resource ownership is established server-side. Caller-supplied site
  identifiers, role strings, totals or stale approved revisions are not authority.

## Database work

Identify owned local/test resources before writes. Use the repository's hermetic
runner and `requireOwnedDatabase()` for gateway DB acceptance; it refuses missing
ownership and does not fall back to restored data. Inspect migration numbering,
compatibility, privileges/search_path, locks, rollback and migration-ledger state.
Do not replay migrations over restored schema, import global roles blindly or
change hosted/shared state under a throwaway-test mandate.

A restore and an owned disposable test cluster are different resources. Preserve
pristine/restored data. Never delete protected financial/invoice records to tidy
fixtures; discard the specifically owned test database instead. Postgres roles
are cluster-global, so database-per-suite alone does not isolate role mutations.

## Working-tree and resource discipline

Preserve unrelated patches, unpublished commits, environment/signing assets and
untracked documents. Use explicit staging paths if local commits are authorized
or implied by the existing execution mandate; inspect the staged diff. Do not
commit secrets, unrelated analysis configuration or ephemeral build artifacts.
Keep commits focused and descriptions tied to behavior and validation.

Use quoted heredocs/structured tool arguments for prose and exact replacements.
Never interpolate Markdown with backticks/$() into executable shell text. Observe
zsh array semantics and exact process/resource ownership. Stop/clean only resources
created for this task by exact identity/labels. No Docker prune or broad process
kill. Bound heavyweight test/build concurrency on the shared Mac.

## Persist to completion

Run affected validation after the design stabilizes. Fix failures introduced by
the change; broaden tests when shared behavior/risk justifies it. Include the
real user/role path and meaningful database/failure assertions. Negative controls
should remove a behavior safeguard, produce the expected behavioral failure and
restore exact source; changing an assertion is not implementation proof.

Complete all feasible authorized work despite unrelated external blockers. If
required provider/device/authority is unavailable, preserve the working result,
name exactly which acceptance remains blocked and its dependency. Do not replace
missing device/browser/provider evidence with a false success claim.

Finish with outcome, exact tested source/config/artifacts, changes/commits/dirty
paths, verification and material limitations; update existing evidence/next task.
Do not finish by offering to implement the work already requested.

## Optional Claude prompt export

Only when requested: provide a complete self-contained prompt with current
checkout/branch/HEAD, recovered decisions, finite outcome, dependency order,
preservation/authorization boundaries, actual code pointers, user journeys,
negative/failure tests, commands to verify, evidence and completion criteria.
Recommend model/effort using currently verified official configuration; do not
reuse historical model names as fact. Avoid giant boilerplate or repeating fixed
work. A prompt export is not execution or proof of acceptance.
