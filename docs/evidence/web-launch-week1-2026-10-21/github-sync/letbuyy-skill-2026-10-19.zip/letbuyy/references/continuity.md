# Continuity without stale-state authority

Durable context is maintained knowledge plus live verification, not a promise
of permanent model memory or automatic access to every chat. Keep stable product
decisions, source navigation, dated state and acceptance evidence discoverable.
Load only the detail needed for the current request.

## Read-only versus maintenance

A status/explanation/research-only request does not automatically authorize
rewriting project records. After substantive implementation or explicitly requested
continuity work, maintain the existing phase/evidence records that document it.
Do not create another constitution, second execution programme or a parallel
status system. The bundled skill snapshot is a bootstrap; newer project evidence
is the source of changing progress. Update the installed skill when requested or
needed within an authorized skill-maintenance task, not to make an old snapshot
appear current without verification.

## What to capture

- Date in the user's timezone; selected checkout/branch/full source HEAD.
- Actual outcome, affected consumers/schema/config/artifacts and focused commits.
- Accepted owner decision with source/date/scope; superseded historical rule.
- Exact commands/exit codes and separate pass/fail/skip/TODO/cancel counts.
- Cached versus fresh coverage; real actor/runtime role; provider/device mode.
- Failure/negative-control results and any invalid observations excluded.
- Fixture ownership and cleanup evidence, preserved dirty paths and restored data.
- Remaining original phase requirements, concrete dependency and next task.
- Separate local/device/sandbox/cloud/release verdicts and unverified limits.

Never save passwords, keys, raw .env, bearer download URLs, private evidence
contents or real personal data. Use sanitized references to controlled evidence.
Do not stage unrelated owner files to make the continuity commit convenient.

## Corrections and supersession

Preserve old reports as dated history; add a clear dated correction at the stale
claim and point to decisive evidence. Make the current next-task/decision matrix
easy to find. Examples from LetBuyy:

- Firebase login prerequisite superseded by direct canonical Phase 1R.
- Target comparator fed legacy grants was not independent target authorization.
- Owner product mutation did not prove authorized staff mutation.
- Re-login after revocation did not prove existing-session revocation.
- Tier tests on an isolated router did not prove production mount reachability.
- Support closed did not mean privacy fulfillment completed.
- Old Hono CJS/ESM diagnosis replaced by the proven declaration-alias cause.
- Twenty-five old root failures and the stale shadow-timeout gap were superseded
  by later repairs; don't propose them again from old document introductions.
- Automatic handoff to Claude superseded by direct Codex engineering on 3 October.

Do not erase earlier failure evidence or quietly narrow parent acceptance to fit
completed work. A changed recommendation is not an owner decision.

## Compact handoff format

Use existing repository formats when present. A useful handoff contains:

| Field | Information |
| --- | --- |
| Requested outcome | Finite task/phase and actual scope |
| Working position | Checkout, branch, source HEAD, current dirty paths |
| Decisions | Accepted choices and specifically unresolved policy |
| Completed | Observable behavior and relevant evidence |
| Verification | Commands, source/artifacts, real boundaries and limits |
| Remaining | Required phase work, defects and external dependencies |
| Next action | Concrete dependency-ready implementation/research task |

Each new chat should recover this position and reconcile actual Git/evidence.
If documents are inaccessible, use the dated bootstrap and mark current state
unverified; never claim that inaccessible work is complete. Use thread reads to
recover missing decisions selectively, with pagination and attribution.

## Communication

Use plain English, warm "bro" tone when appropriate, professional evidence and
tables for roadmap/comparisons. Lead with outcome. During work explain meaningful
findings and what the next check resolves; do not narrate repeated unchanged polls.
Final reports should be self-contained and link real files with absolute paths.
Explain what changed, why, verification and material limits without a giant
command transcript. No fabricated overall completion percentage or launch date.
