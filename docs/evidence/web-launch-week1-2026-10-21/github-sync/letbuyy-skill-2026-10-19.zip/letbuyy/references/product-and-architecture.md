# Product model and architecture

Curated from the owner handoff and accepted programme on 3 October 2026;
not a live deployment inventory. Resolve changes against current decisions.

## Purpose and V1 journey

LetBuyy is an India-first commerce platform for micro and small merchants.
V1 combines merchant-branded storefronts with a reel-led LetBuyy marketplace
that also offers normal product search and browsing. A merchant creates an
account, completes appropriate verification, selects a plan/channel, manages
one catalog/inventory, publishes eligible products, fulfills orders, handles
returns and understands fees and settlements. Buyers use canonical identity,
profile/addresses and appropriately scoped order views. Operators review,
investigate and support with bounded permissions and audit history.

Quick commerce, supermarkets/dark stores and delivery expansion are V2.
Do not activate deferred apps merely because their folders exist. Scaffolding
and old Firebase screens are not evidence of delivered V1 features.

## Accepted owner choices

| Domain | Preserved contract |
| --- | --- |
| Buyer identity | One canonical issuer; shared buyer identity/profile/addresses across channels, with scoped audiences and tenant/order access. Never merge by unverified email. |
| Storefront | Merchant-branded, Liquid-first, server-authoritative commerce. Storefront orders stay scoped to the authorized store. |
| Marketplace | Reel-led discovery plus ordinary browse/search; buyer views span their applicable marketplace purchases, not other buyers' orders. |
| Merchant onboarding | Proportionate storefront checks; stronger entity-aware marketplace seller verification. Reuse established information rather than duplicating merchant identity. |
| Capability states | Account, plan, storefront readiness, seller approval, provider readiness, product approval, reel approval and product-match approval remain separate. Paid plans never bypass eligibility. |
| Catalog | One canonical product/variant catalog and shared inventory; explicit selected-channel listings. Acquisition attribution does not determine selling authority. |
| Product review | Humans approve marketplace product revisions. Material changes require the applicable renewed review; rejection explains correction/appeal. |
| Reels | Humans review exact media and its product/variant match, caption, thumbnail, claims and disclosures. External URLs or successful transcoding never skip review. |
| Eligibility | Enforce seller/product/reel approval on feeds, search, sponsored placements, relevant detail/deep-link paths and checkout. Current prices/stock override cached reel values. |
| Payments | Marketplace collection/checkout through a licensed provider with seller mapping. LetBuyy does not custody funds or invent an independent payout rail. |
| Commission | Storefront 0% LetBuyy sales commission; marketplace effective-dated category commission. Provider/subscription/shipping/tax amounts are distinct. Rates and exact plan values remain owner configuration. |
| Settlement | Weekly eligible settlement via the provider; paid is not necessarily eligible. Show holds, refund/adjustment effects and estimated versus finalized payout. |
| Advertising | Captured-payment-backed credits, separate from seller proceeds; CPC, CPM and purchase-based campaigns, budgets/caps, attributable charges and reversals. |
| Trust claims | Video review checks representations and matches; it cannot certify physical quality or imply laboratory/sample testing without such a process. |

Do not indiscriminately collect every personal document or assume every seller
has the same GST/KYC requirements. Current legal applicability and exact
responsibilities need primary-source research and relevant professional review.
Open questions include launch categories, whether every listing needs a reel,
upload limits, review capacity, rates/plans, provider eligibility and ad attribution.

## Canonical engineering direction

- One commerce modular monolith: `services/api-gateway`.
- Approved satellites: queue workers, mobile BFF, identity platform and webhook
  service; approved web/mobile surfaces discovered from current manifests.
- One RLS/GUC Postgres; `sites` is the tenant root ("store" is a product/UI term).
  Trace transitional `store_id` uses; do not create a rival `stores` system.
- `apps/platform/identity` is the sole asymmetric token issuer. Consumers verify;
  buyer, merchant/staff and operator privileges stay separate.
- Canonical append-only double-entry ledger, integer minor-unit money,
  derived balances and compensating reversals; server-authoritative checkout
  and canonical order creation with idempotent provider processing.
- Domain changes and their outbox rows commit together. The worker relays;
  delivery may repeat and needs durable effect deduplication.
- Liquid/portable-theme renderer and `packages/theme-engine` contracts survive;
  web and Flutter editors stay canonical. A renderer winner does not authorize
  deleting a currently serving predecessor before parity/retirement gates.
- India envelope 100 → 1,000 → 10,000 merchants. Approved Cloudflare/Vercel
  direction, one region; current deployed resources must still be verified.
- Reserved services remain empty seams. No CQRS/event-sourcing/saga engine,
  speculative sharding/multi-region/service mesh, live Wasm extension runtime,
  rival auth/ledger/notification platform or second merchant OS.
- Design tokens, shared TS/Dart contracts and governed dependency boundaries
  are part of correctness. Apps do not import other app internals.

## Governance conflict to preserve explicitly

June governance still contains blanket permanent zero commission and older
merchant-payment assumptions. The owner's September decisions choose zero
storefront commission plus category-based marketplace commission and
provider-managed marketplace checkout. The direction is settled; exact rates
and scoped governance/configuration/validator alignment remain work.
Do not use old prose to reask the settled direction, silently change money
behavior, rewrite financial history or manufacture ARB signatures. Current
direct human instructions govern the task under higher-level rules.

## Firebase and local cart lessons

The owner confirmed no real marketplace users required a legacy migration
bridge. Phase 1R removed Firebase product SDK/project authority from the active
marketplace and made canonical sign-in the ordinary entry. ML Kit may retain
Firebase-named component/encoding libraries without FirebaseApp/project
dependency; investigate actual dependencies rather than matching names alone.
Do not reintroduce Firebase login or dual-session linking.

Guest and each buyer have separate cart/wishlist ownership. Explicit guest
transfer must survive failed writes/restarts without duplicate quantities.
Switching accounts clears stale addresses/state immediately, and late responses
cannot restore another buyer's data. Local baskets and address selection are
not evidence of working payments or canonical order creation.

## Durable origins

Workspace `NewMacSetup/LETBUYY_NEW_MAC_CTO_CONTEXT.md` contains old-Mac decisions
and embedded roadmap/research reports; it is a reconstruction, not a verbatim
export. The programme lives in the selected repository's
`docs/evidence/foundation-programme-2026-09-26/`. These are dated context, not
present-day commands or runtime certification.
