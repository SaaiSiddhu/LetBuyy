# Decision-driven web and cloud research

Use this for a requested research task or the unstable facts that affect a
phase implementation. Scope research to decisions, not a general technology
tour. Begin with the current phase contract, canonical adapters and relevant
versions; existing code may already solve most of the problem.

## Evidence workflow

1. State the concrete questions: e.g. can the owned provider account support
   seller onboarding and weekly eligible settlement; what revocation bound
   does this video provider offer; how does this DB client cancel work?
2. Search official/primary sources and actually open the supporting pages.
   Prefer provider documentation, official SDK/source, government Acts/rules/
   gazettes and executed agreements available through authorized access.
   Technical answers rely on primary sources. Do not upgrade a search snippet,
   marketing comparison or archived research into current supported behavior.
3. Record retrieved date, relevant API/library version and effective date where
   applicable. Separate current rules, future commencement, proposal and
   interpretation. Research legal/financial facts afresh when accuracy matters;
   do not blindly copy old rates or declare a legal conclusion from table names.
4. Inspect the actual accessible account/resource where relevant. Public API
   documentation establishes capability, not the owner's approval, enabled
   feature, eligible entity, regional availability or provider agreement.
5. Compare findings with current adapters/schema/consumers and governance.
   Document the chosen contract, alternatives that matter, implementation
   consequence and still-needed owner/provider decision.
6. Save meaningful findings in existing phase research/evidence files when
   authorized; link primary sources close to claims. Avoid duplicating manuals.

Useful evidence table:

| Question | Primary source/version/date | Account fact | Implementation implication | Confidence/open dependency |
| --- | --- | --- | --- | --- |

For uncertain findings say what was established and what was not. A provider
page about Route/splits does not prove LetBuyy can go live. A screenshot of a
healthy endpoint does not identify deployed SHA or active runtime configuration.

## Cloud ownership and access

Discover available connectors/MCP tools, supported CLIs and account access.
Prefer purpose-built tools. A missing integration is reported honestly; this
skill neither installs a provider nor grants credentials. Use browser/UI tools
when appropriate and available; do not manufacture a tool result.

Before querying sensitive resources or preparing any cloud change, establish
account, project/resource identity, environment, ownership and source lineage.
The old accessible Supabase project list did not match the LetBuyy reference;
the old Cloudflare CLI lacked authentication. These are historical observations
to recheck, not assumptions that all future sessions lack access. Never modify
an unrelated project to overcome a mismatch.

Read-only inventory should connect:

- Environment and project ID, domain/DNS ownership, region and runtime.
- Deployment commit/build/config/schema lineage, migration ledger and flags.
- Provider mode (unavailable/mock/sandbox/live) and actual account eligibility.
- Queue/storage/video resources, lifecycle rules and relevant permissions.
- Secret reference/custody and rotation responsibility, without exposing values.
- Relevant quotas, price units, cost drivers and rate limits verified currently.
- Backups, storage bytes, encryption/key recovery, restore and rollback scope.

Do not print raw environments, signed download URLs, database URLs with secrets
or real user documents. Redact private identifiers when necessary; preserve
enough sanitized resource identity to make evidence reviewable.

Cloud readiness and deployment are separate. Prepare code/config, sandbox
verification and a reviewable change before seeking any missing release
authority. Existing authorization governs; do not reask already-approved action.
Do not provision resources, set flags, deploy, send messages or run real money
operations solely to answer a research question.

## LetBuyy provider boundaries

- Payment: licensed-provider collection/seller mapping and eligible settlement.
  Verify entity/contract, onboarding, provider evidence, refund/chargeback and
  reconciliation behavior. No self-custody workaround if the provider is blocked.
- Video: provider-adapted processing/playback behind existing canonical domain
  boundaries; DB owns reviewed product/media linkage. Managed video does not
  authorize filling the reserved media microservice.
- KYC: distinguish sandbox result, manual review, provider verification and
  LetBuyy seller approval. Sandbox cannot unlock real selling or payouts.
- Shipping/notifications: reuse existing adapters/outbox, explicit delivery
  status and consent. Unconfigured delivery is unavailable, not successful.
- Recovery: database backup is not storage/media bytes or decryption-key
  recovery. Measure owned restore integrity where requested.

Use honest mock/sandbox seams to finish independent engineering while a human
provider gate remains open. Label them in code/UI/evidence. They cannot fulfill
provider sandbox acceptance or certify live delivery.

## Professional and owner decisions

Convert research into precise configurable fields and examples. Seek a material
owner choice only when it cannot be derived from accepted intent or source
evidence. Legal/tax/provider-responsibility interpretations needing professional
or contractual confirmation remain explicitly unverified until obtained.
Do not invent plan/rate/cutoff values or make professional approvals up.
Continue dependency-independent implementation rather than leaving all work
blocked behind an unrelated policy question.
