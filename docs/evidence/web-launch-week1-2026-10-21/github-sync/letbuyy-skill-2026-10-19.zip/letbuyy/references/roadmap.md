# Eleven-phase programme and research routing

This is a navigation summary of the accepted parent roadmap and the September
foundation programme. The current repository programme owns detailed criteria;
this skill does not replace it. Read the full relevant phase section before
implementation. Seven packages per phase: F1.1–F11.7, 77 total.

| Phase | Outcome | Seven work packages in order | Closure evidence |
| --- | --- | --- | --- |
| 1 / 1R | Reproducible local runtime and canonical Android | Transfer/toolchain; owned restore; services/fixtures; ordinary account journey; link/error handling; honest gates; reproducible handoff | Normal login/profile/address/restart/logout/buyer-switch with matching backend; precise source/APK; safe local isolation |
| 2 | Shared identity, scoped access, privacy/order ownership | Issuer/consumer map; cross-origin sessions; profile/addresses; order ownership; staff convergence; operator controls; privacy/DB isolation | Buyer across channels; owner/staff/operator distinct; existing-session revocation; runtime cross-tenant negative cases; scoped transition acceptance |
| 3 | Commercial, compliance and provider/cloud contracts | Authority alignment; commercial configuration; provider/fund-flow eligibility; category/tax matrix; consumer/privacy/content rules; cloud/recovery; transaction/evidence contracts | Versioned executable contracts and worked examples; unresolved activation/configuration values named |
| 4 | Progressive onboarding and usable merchant operations | Capability lifecycle; basic storefront onboarding; marketplace verification; private documents; plans/entitlements; theme publish; operations/accessibility | Storefront publication, marketplace rejection/correction/approval, plan restrictions, real staff and theme rollback |
| 5 | One catalog and accurate inventory | Catalog/legacy mapping; products/variants; compliance attributes; channel publishing; inventory; discovery/geography; migration/parity | Merchant edit → allowed channel → buyer browse/detail; accurate variant/price/stock; concurrent last-item protection |
| 6 | Revision-bound product approval | Eligibility revisions; review workbench; concurrency/appeal; read-surface eligibility; purchase eligibility; complaints/takedown; review capacity | Limited reviewer UI; stale decision denial; rejected/edited/revoked product cannot escape via ads, links or checkout |
| 7 | Canonical approved reel commerce | Provider/media authority; secure uploads; immutable product match; human review/rights; playback/commerce; revocation/abuse; legacy media disposition | Submit/process/review → actual Android playback → current product/cart; replacement/rejection/takedown enforced |
| 8 | Shared checkout, payments and order lifecycle | Server cart/totals; multi-seller structure; payment initiation/evidence; retry/recovery; fulfillment/notifications; returns/refunds/COD; channel certification | Normal provider test-mode purchase/fulfillment/partial refund/complaint; late capture and timeout recovery with one effect |
| 9 | Explainable accounting and weekly settlement | Ledger invariants; commission snapshots; tax/withholding exports; eligibility/cutoff; atomic batches; reconciliation/recovery; statements | Full provider sandbox settlement cycle including holds/refunds/retries; book balances to provider evidence |
| 10 | Accountable advertising | Credit funding; campaign/budget lifecycle; CPC validity; CPM precision; purchase attribution; ranking/disclosure; analytics/disputes | All three models work through UI, delivery, debit, exhaustion/pause/reversal; ledger and reports agree |
| 11 | Whole-product release readiness | Exact candidate matrix; security/privacy; performance/accessibility; recovery/cloud lineage; operator rehearsal; validated retirement; first-merchant packet | Exact candidate full journeys and recovery; separate local/device/sandbox/hosted/launch verdicts; release authorization |

The old Phase 1 Firebase-credential prerequisite is superseded by Phase 1R.
Phase 7's old migration wording does not mean rebuilding Firebase or inventing
legacy users/content; inspect any owned media that actually needs preservation.
Phase 1R is locally integrated. Phase 2 remains current at the bundled snapshot;
later phase summaries describe required outcomes, not absent code or completion.

## Dependencies and early discovery

Closure order: 1 → 2; 2 + 3 → 4 → 5 → 6 → 7; 2 + 3 + relevant
eligibility/media → 8 → 9; product/reel eligibility + money events → 10;
mandatory acceptance across 1–10 → 11. Provider eligibility, cloud ownership,
legal applicability and financial invariants can be researched early.
Do not wait until Phase 8 to discover provider approval is unavailable.

One implementation agent works a bounded dependency-ready phase/task at a
time. A parent phase can contain several focused changes and checkpoints.
Do not schedule eleven equal one-day jobs, promise unlimited uninterrupted
execution or treat each package as permission for a new service.

## Phase-specific discovery

| Phase | Research that materially changes implementation |
| --- | --- |
| 1 | Pinned Node/pnpm/Flutter/Java/Android versions, backup compatibility, supported launchers, app-link/signing behavior |
| 2 | Issuer/session contracts, browser cookie/PKCE behavior, current runtime middleware, DB roles/pool transaction context, privacy decisions |
| 3 | Provider account eligibility/agreements, official Indian category/tax/privacy/consumer sources, effective dates, cloud ownership/cost/recovery |
| 4 | Existing plan commitments, provider KYC flow, secure document handling, theme publishing/rollback and merchant accessibility |
| 5 | Category fields, variant/inventory writers, current search requirements and applicable geographical constraints |
| 6 | Revision semantics, review capacity/permissions, stale decision concurrency and eligibility enforcement across every surface |
| 7 | Actual video upload/playback limits/costs, signed/private asset behavior, webhook authenticity, moderation rights and revocation windows |
| 8 | Provider sandbox flows, capture/refund evidence, webhook retries/order, shipping/COD semantics, normal checkout recovery |
| 9 | Current effective tax policy/professional review, immutable ledger invariants, provider payout schedules and reconciliation reports |
| 10 | Defined event validity/attribution windows, captured credit funding, precision, cross-device policy and refund reversal |
| 11 | Current app distribution/domain requirements, measured load, backup/storage/secret recovery, actual hosted lineage and operator capacity |

Do not repeat research whose premise/version remains valid. Refresh unstable
facts before depending on them. For every relevant finding explain the decision,
code/contract affected, confidence and verification needed.

## Definition of a complete phase

Read existing acceptance, inspect remaining actual gaps, implement necessary
domain behavior and reachable interfaces, verify authorized and forbidden user
journeys plus failure recovery, reconcile introduced/baseline failures, and
record exact artifacts and unresolved dependencies. Distinguish component
completion from formal parent-phase acceptance and live activation.
