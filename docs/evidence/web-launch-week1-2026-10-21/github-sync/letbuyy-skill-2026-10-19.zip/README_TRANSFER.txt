LETBUYY SKILL TRANSFER
Packaged: 19 October 2026 (Asia/Kolkata)

CONTENTS
The complete installed LetBuyy skill: SKILL.md, all 10 reference documents,
agents/openai.yaml, and scripts/context_probe.py. All 13 source files are
preserved byte-for-byte. SHA256SUMS.txt records their integrity hashes.

INSTALL ON THE NEW MACHINE
1. Extract this ZIP.
2. Copy the entire letbuyy folder into your Codex personal skills directory,
   so the entry file is ~/.codex/skills/letbuyy/SKILL.md.
   If your installation uses a custom CODEX_HOME, use its skills directory.
3. Open a new Codex chat in your transferred LetBuyy workspace and invoke
   $letbuyy. Tell it the workspace location if the path has changed.

WORKSPACE LOCATION
Historical absolute paths in the references are locators. The skill explicitly
supports another username or location. For the optional context probe, pass
the new workspace explicitly, for example:

python3 /path/to/letbuyy/scripts/context_probe.py --workspace /path/to/LetBuyy-Workspace

SCOPE
This ZIP contains the skill only. Transfer the project repositories, unpublished
Git history/worktrees, evidence, database backups, environment/signing files,
and any required chat history separately. The skill does not bundle them.
The bundled state snapshot is dated 3 October 2026; the packaging date does
not imply that project status has been refreshed. Recover current state from
the transferred workspace before beginning new project work.

OPTIONAL INTEGRITY CHECK (macOS/Linux, from the extracted directory)
shasum -a 256 -c SHA256SUMS.txt
