# Phase B Risk Closure Report
## Storefront Liquid Discovery — Certification Authority Sign-Off

**Document ID:** RISK-CLOSURE-2026-07-04  
**Date:** 2026-07-04  
**Branch:** stepup/main  
**Certification Authority:** Phase B static audit (no live runtime execution)  
**Authored by:** Subagent — certification author role  
**Supersedes:** All open-question markers and unverified claims in docs 01–12  

---

## 1. Summary Counts

| Category | Total |
|---|---|
| Register items evaluated | 56 |
| **CLOSED-VERIFIED** | 12 |
| **OPEN-CONFIRMED-RISK** | 26 |
| **OPEN-UNVERIFIABLE** | 2 |
| Items refuted (risk was overstated or wrong) | 7 |
| Items partially verified (PARTIAL — nuanced) | 9 |

> **Count correction (adversarial review 2026-07-04):** The prior CLOSED-VERIFIED count of 14 was incorrect. Actual rows with CLOSED-VERIFIED closure status: R-07, R-10, OQ-04, OQ-05, OQ-08, OQ-10, OQ-20, UC-02, UC-03, UC-04, UC-08, UC-20 = 12. Two items previously counted as CLOSED — R-14 (has OPEN-CONFIRMED-RISK corrected risk in its row) and OQ-02 (REFUTED verdict; corrected risk is OPEN-CONFIRMED-RISK in Phase D) — are not CLOSED-VERIFIED; they are OPEN-CONFIRMED-RISK. OPEN-CONFIRMED-RISK is therefore corrected from 24 to 26.

> **Reading the table:** CONFIRMED risks are not failures of Phase B — they are verified inputs delivered to the phases that own each fix. Each OPEN-CONFIRMED-RISK row names the owning phase explicitly. OPEN-UNVERIFIABLE rows name the exact resource that would be needed to close them. Runtime suites (pnpm test, validate-governance) were BLOCKED by a temporarily unavailable safety classifier; the four blocked suite results are logged but do not change individual item verdicts, which rest on static evidence.

---

## 2. Register — Grouped by Kind then Domain

### Kind: RISK (R-*)

#### Domain: Performance

| ID | Claim | Verdict | Evidence | Closure Status |
|---|---|---|---|---|
| **R-01** | `cache: false` is set on the LiquidJS engine; no cross-request engine reuse; 23 sections re-parsed per pageview | **CONFIRMED** | `packages/theme-engine/src/theme-renderer.ts:436–437` (`new Liquid({ cache: false, ... })`); line 365 shows engine created fresh per `LiquidRenderer.render()` call; line 299 shows `parseAndRender()` called per section with no cached parse result | **PARTIALLY-CLOSED-IMPLEMENTED (Phase F — F1+F2)** — `cache: true` enabled in `createLiquidEngine()` (line 643); `Promise.allSettled` parallel section rendering in `renderLiquidTemplateSections()`. **Remaining gap:** LRU is engine-instance-local — `createLiquidEngine()` is called fresh per request (lifecycle assumption documented at line 643 with a `LIFECYCLE ASSUMPTION` comment). Cross-request LRU benefit requires engine pooling (not implemented; requires re-evaluation for tenant-isolation safety before adding). Intra-request steady-state parse reduction confirmed; cross-request parse cost unchanged. See PHASE_F_REPORT.md §F1. |
| **R-03** | Every storefront request triggers an uncached gateway fetch to `/v1/internal/store-access/resolve` — a SPOF for access-control integrity | **CONFIRMED** | `apps/storefront-runtime/src/proxy.ts:106` (`cache: 'no-store'`); lines 98–120 show no in-memory/KV/edge cache; `services/api-gateway/src/routes/internal-store-access.ts:30–62` has no `Cache-Control` response header. Nuance: gateway outage degrades to `NextResponse.next()` (access bypass) rather than hard 500. | **PARTIALLY-CLOSED (Phase F — H3 validGateCookie staleness fix)** — `validGateCookie()` in `proxy.ts:208` now re-validates against `site.access_mode` fetched live from the DB, closing the staleness window where a cached gate cookie would not reflect a merchant's `access_mode` change. **Remaining gap:** The `cache: 'no-store'` gateway fetch on every request (the KV-backed cache) is NOT implemented. R-03 core resilience risk (gateway-outage → access bypass) remains OPEN-CONFIRMED-RISK. KV caching still deferred. See PHASE_F_REPORT.md §H3. |

#### Domain: Error Handling

| ID | Claim | Verdict | Evidence | Closure Status |
|---|---|---|---|---|
| **R-02** | A throw from `engine.parseAndRender()` propagates unhandled through `renderLiquidTemplateSections` → `LiquidRenderer.render()` → `renderLiquidPlan` → Next.js Server Component (hard 500 / error boundary); no try/catch at any layer | **CONFIRMED** | `theme-renderer.ts:271–331` — `renderLiquidTemplateSections()` has no try/catch, `parseAndRender()` called bare at line 299; line 383 — bare `layoutHtml = await engine.parseAndRender(...)` in `LiquidRenderer.render()`; `apps/storefront-runtime/src/lib/theme-engine/composition-engine.tsx:432–433, 482` — no try/catch around `renderer.render()` or `renderLiquidPlan()`. No error-path test coverage confirmed. | **CLOSED-IMPLEMENTED (Phase C — C1 + C2)** — Per-section, per-region, layout, and block-level try/catch added in `theme-renderer.ts`; `ThemeRendererStatus` extended with `'error'`; `renderLiquidPlan` catch added in `composition-engine.tsx`. Evidence: `theme-renderer.ts:32, 288–370, 411–487, 619–647`; `composition-engine.tsx:433–479`. Tests: `C1 section crash isolation`, `C1 all sections fail`, `C1 layout crash`, `C1 block crash isolation` (89/89 theme-engine tests pass); `composition engine catches renderer failures` test 19 (19/19 storefront-runtime tests pass). Residual: data fetches outside try/catch in renderLiquidPlan (MEDIUM, Phase D); allMainSectionsFailed miscount for missing-file sections (LOW, Phase D). |

#### Domain: Schema / Type Safety

| ID | Claim | Verdict | Evidence | Closure Status |
|---|---|---|---|---|
| **R-04** | Naming mismatch: React registry uses `'newsletter'`; Liquid bundle uses `'newsletter-signup'` — lookup miss risk | **PARTIAL** | The mismatch is real (`theme-registry.ts:283–285` vs `theme-bundle.ts:1178–1179`). However `PORTABLE_TO_LIQUID_TYPE_OVERRIDES` in `portable-to-liquid.ts:46` maps `newsletter → newsletter-signup` at compile time, and both migrations 171 and 172 store the section with `type:'newsletter-signup'`. The stated failure scenario does not occur on compiler-produced bundles. Residual risk: a Liquid bundle written directly to the DB bypassing the compiler could contain `type:newsletter`, which the renderer would not find in `bundle.sections`. | **CLOSED-IMPLEMENTED (Phase C — C4)** for the render-time path. `LIQUID_SECTION_TYPE_ALIASES` frozen constant added in `theme-renderer.ts:256–261`; render loop resolves alias before bundle lookup at line 306. Cross-reference comment added in `portable-to-liquid.ts:43–44`. Evidence: `theme-renderer.ts:256–261, 306`; exported via `index.ts:18`. Tests: `C4 LIQUID_SECTION_TYPE_ALIASES constant is exported and correct`; `C4 newsletter alias resolves at render time` (89/89 theme-engine tests pass). Residual (Phase D): Zod guard in `parseLiquidThemePackageBundle` to reject bundles with `type:'newsletter'` at parse time. |

#### Domain: Feature Parity / Section Content

| ID | Claim | Verdict | Evidence | Closure Status |
|---|---|---|---|---|
| **R-05** | Liquid `hero-banner` is missing four fields present in the React `heroBanner` schema: `image`, `overlay`, `height`, `textAlign` | **CONFIRMED** | `theme-bundle.ts:1013–1026` — Liquid hero-banner settings/body contain only `eyebrow`, `heading`, `subheading`, `ctaText`, `ctaLink`; `theme-registry.ts:86–110` — React heroBanner schema includes `image`, `overlay`, `height`, `textAlign`. Extra finding: Liquid adds `eyebrow` not present in React schema. | **CLOSED-IMPLEMENTED (Phase D — D6)** — `image` (image_picker), `overlay` (range 0–1, default 0.4), `height` (select: full/large/medium/small), `textAlign` (select: left/center/right) added to `hero-banner` in `theme-bundle.ts:1009–1035` and the Urban Kicks fixture override (`theme-bundle.ts:2534`). Section body uses `data-height`, `data-text-align`, `data-image-url` attributes. Residual (LOW — open): these three `data-*` attributes are not yet in `ADD_ATTR` in `LIQUID_RENDERED_HTML_DOMPURIFY_CONFIG`; DOMPurify strips them at render time (Phase D F-05). Tests: `D6 hero-banner Liquid section has image, overlay, height, textAlign schema fields`; `D6 hero-banner renders with image, overlay, height, textAlign settings` (101/101 theme-engine tests pass). |
| **R-06** | Liquid bundle validation fallback uses `createUrbanKicksLiquidThemeBundleFixture()` — stores failing schema validation inherit Urban Kicks branding | **CONFIRMED** | `apps/storefront-runtime/src/lib/store-service.ts:3` — only Urban Kicks fixture imported; line 671–673 — Urban Kicks fixture used as fallback; `theme-bundle-core.ts:66–82` — `createLetbuyyCoreLiquidThemeBundleFixture()` exists, is exported from `@letbuyy/theme-engine` (index.ts:22), and requires only a one-line import swap and call change in `store-service.ts`. | **CLOSED-IMPLEMENTED (Phase C — C3)** — Fallback removed entirely; stores with invalid or absent `liquidBundle` now yield `undefined` and fall back to the React renderer (no branding leak). Evidence: `store-service.ts:670–673` (`const liquidBundle = liquidBundleResult.success ? liquidBundleResult.data : undefined;`). `createUrbanKicksLiquidThemeBundleFixture` is no longer imported in `store-service.ts`. Urban Kicks demo path (`getUrbanKicksDemoStore`) is unaffected. 19/19 storefront-runtime tests pass. |
| **R-07** | `POST /storefront/customer/register` endpoint did not exist | **REFUTED** | `services/api-gateway/src/routes/storefront/customer-registration.ts:33` — route fully implemented with rate-limit, Turnstile, bcrypt, HS256 session issuance; wired through `registerCustomerRegistrationRoute → registerStorefrontCustomerEngagementRoutes → registerStorefrontPublicRoutes → storefrontRouter` (confirmed via import chain). Commit `a391c1f4` closed LB-12. Stale `BLOCKED on LB-12` comment in `liquid-l9-auth.test.ts:2–3` should be cleaned up. | **CLOSED-VERIFIED** — LB-12 was closed prior to Phase B audit. No fix required. |
| **R-08** | `StoreModel.navigation` is never forwarded to the Liquid scope; `{{ shop.navigation }}` and `linklists` resolve to nil | **CONFIRMED** | `apps/storefront-runtime/src/lib/store-service.ts:60–64, 721` — navigation fetched and stored; `composition-engine.tsx:339–397` — `buildLiquidCommerceContext()` return object has no `navigation` key; `theme-renderer.ts:552–591` — `buildLiquidScope()` does not include navigation; `LiquidCommerceDrops` interface (theme-renderer.ts:41–52) has no navigation field. `strictVariables: false` means `{{ shop.navigation }}` renders as empty string. | **CLOSED-IMPLEMENTED (Phase D — D1)** — `navToLinklists()` helper added in `composition-engine.tsx:320–355` converts `StoreModel.navigation` to Shopify-convention linklists (underscore-keyed handles: `main_menu`, `footer_menu`, `policy_menu`). `linklists?: unknown` added to `LiquidCommerceDrops` interface (`theme-renderer.ts:57`). `linklists: toLiquidDrop(input.liquidContext?.linklists) ?? {}` added to `buildLiquidScope` return (`theme-renderer.ts:722`). Underscore key form confirmed correct via runtime integration test (D1-B runtime). Tests: `D1-A linklists key is in LiquidCommerceDrops`; `D1-A linklists falls back to empty object`; `D1-B navToLinklists helper exists`; `D1-B navToLinklists runtime: underscore keys survive toLiquidDrop sanitizer` (101/101 + 31/31 tests pass). |

#### Domain: Security / Information Disclosure

| ID | Claim | Verdict | Evidence | Closure Status |
|---|---|---|---|---|
| **R-09** | Font loading functions `buildGoogleFontsHref()` and `buildExperienceFontLinkHref()` are dead code; presets Aura, Craft, Dawn render system-font fallback | **CONFIRMED** | `experience-fonts.ts:57–69` — both functions defined but never imported in `apps/storefront-runtime/src/`; `layout.tsx:21–32` — `FONT_MAP` missing Cormorant Garamond, Libre Baskerville, Source Sans Pro, Lato; `theme-presets.ts:224–225, 246–247, 312–313` — Aura, Craft, Dawn use those missing families; `layout.tsx:121–122` — falls back to Inter on miss. Source comments at presets.ts:238 confirm team awareness. | **CLOSED-IMPLEMENTED (Phase D — D7)** — `buildGoogleFontsHref` imported and wired into `layout.tsx:17,138`. `FONT_MAP` extended with `Cormorant Garamond`, `Libre Baskerville`, `Source Sans Pro`, `Lato` (`layout.tsx:35–38`). Google Fonts preconnect + stylesheet link emitted conditionally when `googleFontsHref` is non-null (`layout.tsx:148–157`). `--font-playfair` corrected from `var(--font-letbuyy-display)` to `"Playfair Display", Georgia, "Times New Roman", serif` (`globals.css:28`). CSP `style-src` extended with `https://fonts.googleapis.com`; `font-src` extended with `https://fonts.gstatic.com` (`next-security-headers.ts:66–67`). Test: `D7 font loading wires experience fonts for active theme settings` (31/31 storefront-runtime tests pass). |
| **R-10** | `CenterPanel` sends `LETBUYY_THEME_EDITOR_SELECTION`; section frame listens for `letbuyy:theme-editor:section-selected` — mismatched event keys; section selection broken | **REFUTED** | `apps/storefront-runtime/src/app/preview/storefront-preview-bridge.tsx:5` defines `LEGACY_SELECTION_MESSAGE = 'LETBUYY_THEME_EDITOR_SELECTION'`; line 70 explicitly handles it; line 44 re-dispatches `letbuyy:theme-editor:section-selected` same-origin via `selectSection()`; `editor-preview-section-frame.tsx:42–44` receives it. Bridge component is mounted at `preview/page.tsx:390` on every preview render. Full chain confirmed functional. C-04 CLOSED. | **CLOSED-VERIFIED** — `StorefrontPreviewBridge` (commit 76d3bee3) resolves the key mismatch at runtime. Discovery docs predated this component. No fix required. |
| **R-11** | The Liquid `search` drop is always null; `{{ search.results }}` renders nothing | **CONFIRMED** | `composition-engine.tsx:380–396` — `buildLiquidCommerceContext()` never sets `search` key; `theme-renderer.ts:50` — `LiquidCommerceDrops` declares `search?: unknown`; line 604–631 — `buildLiquidCommerceDrops()` sets `search: toLiquidDrop(context?.search) || null`; context.search is always undefined so evaluates to null; `theme-renderer.ts:587` propagates null into scope. | **CLOSED-IMPLEMENTED (Phase D — D5)** — `searchDrop` built in `buildLiquidCommerceContext()` (`composition-engine.tsx:451–480`) when `plan.route.path` contains `?search=` or `plan.route.type === 'search'`. Uses `storefront.listProducts({ search: term, limit: 20 })`; maps results via `productToLiquidDrop()`. On error returns structural placeholder `{ terms, results: [], results_count: 0, performed: true, error: true }`. Non-search routes receive `search: null` (unchanged). Test: `D5 search drop is populated when route carries a search term` (31/31 storefront-runtime tests pass). |
| **R-12** | Zero `.liquid` files exist anywhere in the repository; all 23 Liquid section templates are TypeScript string literals inside `createLiquidParitySectionFiles()` | **CONFIRMED** | `find` of repo returns 0 `.liquid` files outside `node_modules`; `theme-bundle.ts:794–1194` — 23 keyed entries returned as TypeScript string literal arrays joined with newlines; `theme-bundle.ts:767–793` — `createLiquidSectionFile()` assembles source from `body: string[]` arrays. Theme Check and Liquid-aware tooling cannot operate without extracting from the build artifact. | **OPEN-CONFIRMED-RISK — Phase D (DX/Tooling)** owns the decision: either extract `.liquid` source files as a build step or accept that template iteration requires a full TypeScript build. |
| **R-13** | `getStoreCustomers()` and `getProductsBySellerId()` are stub implementations returning empty data silently | **CONFIRMED** | `apps/storefront-runtime/src/lib/customer-service.ts:252–255` — `void storeId; void options; return { customers: [], total: 0 };`; `product-service.ts:85–88` — `void sellerId; return [];`. Nuance: repo-wide grep finds zero callers outside definition files; immediate blast radius is zero active features. Stubs are a latent defect if callers are added without fixing them first. | **OPEN-CONFIRMED-RISK — Phase D (Stubs)** owns the fix: implement real API-backed data fetching for both functions before any feature is built that depends on them. |
| **R-14** | Missing `INTERNAL_API_SECRET` causes all gateway requests to proceed without the secret, allowing unauthorized access to internal routes | **REFUTED** | `proxy.ts:67–74` — `internalHeaders()` returns null when secret is absent; `proxy.ts:79–84` — `backendConfig()` returns null; `proxy.ts:98–100` — `resolveAccess()` short-circuits with `{ status: 'unavailable' }`, NO network fetch is made; `proxy.ts:244–249` — unavailable status causes `NextResponse.next()`. The actual risk is different and more severe: all store access-control enforcement (password protection, offline mode, preview-only) is silently bypassed. Doc `04_REACT_DEPENDENCY_MAP.md:298` title is ambiguous and was corrected. | **OPEN-CONFIRMED-RISK (corrected risk)** — The real risk is access bypass, not unauthorized gateway access. **Phase C (Configuration / Security Hardening)** owns the fix: add an explicit error response or alert when `INTERNAL_API_SECRET` is absent rather than silently bypassing access control. |
| **R-15** | `resolveThemeLiquidRenderingEnabled()` has 11 canary-key aliases and zero ARB enforcement; any store with a matching key in `templateConfig` silently activates Liquid | **CONFIRMED** | `theme-governance.ts:162–181` — 11 literal candidates; `theme-governance.ts:125–142` — `readBooleanDecision()` also recurses into object-typed candidates checking nested keys (`enabled`, `liquid_enabled`, `liquidCanary`, `canary`, `value`) — effective surface broader than 11; `THEME_LIQUID_PLATFORM_WIDE_FLIP_DECISION` (line 16–21) records ARB intent but is never checked in `resolveThemeLiquidRenderingEnabled()`; `template-resolver.ts:235–245` calls the function directly with no ARB gate; gateway stores.ts has no `liquidRenderingCanary` reference. | **OPEN-CONFIRMED-RISK — Phase E (Governance)** owns the fix: add an ARB-keyed environment variable check (e.g. `LIQUID_RENDERING_ARB_APPROVED`) that must be truthy before any canary path activates Liquid outside explicit `rendererEngine: 'liquid'` assignments. |

---

### Kind: OPEN QUESTION (OQ-*)

#### Domain: Rendering / Engine Behavior

| ID | Claim | Verdict | Evidence | Closure Status |
|---|---|---|---|---|
| **OQ-01** | Behavior of `stripLiquidSchemaBlocks()` when `{% endschema %}` is absent was unknown | **CONFIRMED** | `theme-renderer.ts:477` — non-greedy regex `/\{%\s*schema\s*%\}[\s\S]*?\{%\s*endschema\s*%\}/gi`; without `endschema`, regex finds no match, returns full source unchanged; LiquidJS then encounters `{% schema %}` as an unknown tag with `strictFilters: true`, throws a parse error, crashes the Next.js server component (compounds R-02). | **CLOSED-IMPLEMENTED (Phase C — C1, coupled to R-02)** — The per-section and per-block try/catch introduced by C1 catches the `{% schema %}` parse error that `stripLiquidSchemaBlocks` passes through. The malformed section emits an `lb:section-error` placeholder; the page continues to render with other sections. Evidence: same as R-02. The underlying gap in `stripLiquidSchemaBlocks` (no detection of unclosed schema tag) remains as a Phase D hardening item. |
| **OQ-02** | `--font-playfair` may be undefined; Sense experience heading may silently fall back to bare system font | **REFUTED** | `apps/storefront-runtime/src/app/globals.css:25` — `--font-playfair: var(--font-letbuyy-display), Georgia, "Times New Roman", serif;` — variable IS defined; `layout.tsx:14–18` — `letbuyyDisplay` loads Geist Sans Latin Ext woff2 as `--font-letbuyy-display`. The CSS variable chain is intact. Real finding: no Playfair Display typeface binary is loaded; the Sense heading renders as Geist (sans-serif geometric) not a serif display face. Gap is a missing font loader, not an undefined variable. | **CLOSED-IMPLEMENTED (Phase D — D7)** — `--font-playfair` corrected in `globals.css:28` to `"Playfair Display", Georgia, "Times New Roman", serif` (honest fallback stack). Google Fonts stylesheet load wired via `buildGoogleFontsHref` in `layout.tsx:138` so Playfair Display is fetched when the Sense experience is active. CSP `style-src` + `font-src` updated to permit `fonts.googleapis.com` / `fonts.gstatic.com`. Test: `D7 font loading wires experience fonts for active theme settings`. |
| **OQ-03** | Whether `themes.section_schemas` remains `{}` after migrations and whether TypeScript static schemas are the live source | **PARTIAL** | Migrations 171–181 never touch `section_schemas`. However, `database/supabase/seeds/urban-kicks-theme.sql` populates `section_schemas` with 6 lightweight stubs (`type`+`name` only: header, heroBanner, categoryGrid, productGrid, trustBadges, footer). On seed-applied DBs the TypeScript fallback in `schema-registry-execution.adapter.ts:111–117` is NOT triggered; stub-thin schemas are used instead. On migration-only DBs (CI/staging without seeds), `section_schemas` is `{}` and TypeScript static `SECTION_SCHEMAS` is the effective live source. | **OPEN-CONFIRMED-RISK — Phase D (Schema Completeness)** owns the fix: replace seed stubs with full schema entries (settings_schema, blocks_schema, defaults) or rely entirely on the TypeScript static source via `getSectionSchemas()`. |
| **OQ-04** | Whether `resolveDevEngineOverride()` is truly disabled in production was unconfirmed | **CONFIRMED** | `apps/storefront-runtime/src/lib/theme-engine/template-resolver.ts:228–229` — `if (process.env.NODE_ENV === 'production' || !engine) return {};` — standard Next.js `NODE_ENV` guard; JSDoc says "Ignored in production." NODE_ENV is injected by the build system, not overridable at runtime. | **CLOSED-VERIFIED** — Guard confirmed by static analysis. No fix required. |
| **OQ-05** | Whether the `liquidPage` gate in `layout.tsx` prevents React chrome double-render was unconfirmed | **CONFIRMED** | `layout.tsx:119` — `const liquidPage = renderPlan.rendererEngine === 'liquid';`; line 218 — `{liquidPage ? children : (<><StorefrontSectionGroupRenderer groupKey="header" .../>...</>)}`; line 245 — identical pattern in non-store-site branch; `composition-engine.tsx:460–465` — comment explicitly documents contract. | **CLOSED-VERIFIED** — Double-render defect closed. Both branches gate correctly. No fix required. |
| **OQ-06** | Whether `ALLOW_ARIA_ATTR` absence strips aria-* attributes from Liquid-rendered HTML | **PARTIAL** | `ALLOW_ARIA_ATTR` is not set. However two mechanisms protect aria-*: (1) `CUSTOM_ELEMENT_HANDLING.attributeNameCheck` regex at `theme-renderer.ts:170–174` explicitly allows `aria-[a-z0-9-]+` on `lb-*` custom elements; (2) `USE_PROFILES: { html: true }` at line 120 preserves aria-* on all standard HTML elements. Gap: aria-* on hypothetical custom elements whose tag name does NOT match the `lb-` tagNameCheck regex would be stripped. Current section templates do not use such elements. | **OPEN-CONFIRMED-RISK (narrow) — Phase D (DOMPurify)** owns the belt-and-suspenders fix: add `ALLOW_ARIA_ATTR: true` to cover any future custom element types outside the tagNameCheck regex. |
| **OQ-07** | How `rendererEngine: 'liquid'` from migration 180 reaches per-store rendering | **PARTIAL** | Migration 180 sets `themes.default_template.rendererEngine = 'liquid'` for the `urban-kicks` theme row at the DB level. However, the gateway storefront query (`public-routes.ts:23–30` `STOREFRONT_SITE_SELECT`) does NOT join the `themes` table — `themes.default_template` never reaches the store payload. `rendererEngine` reaches a store only via (a) `release_manifest.renderer_engine` in a published `theme_releases` row (set during publish), or (b) `templateConfig.rendererEngine` in `template_snapshot`. Stores with no published release continue to render React regardless of migration 180. | **OPEN-CONFIRMED-RISK — Phase C (Release/Publish)** owns the gap: ensure that stores on Urban Kicks theme that have never published a release are either auto-published or that the gateway query joins `themes.default_template` to propagate `rendererEngine`. |
| **OQ-08** | Whether `removeFromCart`, `updateQuantity`, and `clearCart` were implemented in the Liquid hydration islands | **CONFIRMED** | `liquid-hydration-islands.tsx:355–358` — `lb-cart-drawer` implements remove via `data-lb-cart-remove` filter; `liquid-hydration-islands.tsx:973–991` — `lb-cart` implements remove and quantity update via `data-lb-cart-remove` and `stepQuantity()` +/- delta with quantity ≤ 0 removal; `liquid-hydration-islands.tsx:136–139` — `writeCart()` persists to localStorage and triggers server sync. `clearCart` has no named method or UI affordance. | **CLOSED-VERIFIED** — Remove and update-quantity confirmed implemented. clearCart gap: **OPEN-CONFIRMED-RISK — Phase D (Cart UX)** — no clear-cart button or public API surface exists; `writeCart([])` is the only path. |
| **OQ-09** | Whether stores created via web onboarding with no template selection receive `theme_id = 'modern'`, and whether a `'modern'` row exists in the themes catalog | **CONFIRMED** | `apps/identity-platform/src/app/api/auth/create-store/route.ts:90` — `theme_id: templateId || 'modern'`; `services/api-gateway/src/routes/stores.ts:687` — stored verbatim; `database/supabase/migrations/000_baseline.sql:11978` — `sites.theme_id DEFAULT 'modern'`; no `INSERT INTO themes … 'modern'` found in any migration or seed; only `'urban-kicks'` row exists. Theme-editor query filters by `theme_slug` → 404 expected for any store with `theme_id = 'modern'`. | **OPEN-CONFIRMED-RISK — Phase C (Onboarding)** owns the fix: either insert a `'modern'` theme row (or alias) or default `theme_id` to `'urban-kicks'` in `create-store/route.ts`. |
| **OQ-10** | Whether LiquidJS `parseAndRender()` is re-entrant / safe to parallelize with `Promise.all()` | **REFUTED** | `liquidjs@10.27.0/dist/liquid.node.mjs:4929–4931` — `_render()` creates `new Context(scope, this.options, renderOptions)` per call; `3097–3114` — `Context` constructor creates independent `Limiter` instances per call from numeric options; `1280–1295` — `Renderer.renderTemplates` generator uses only context-local state; no shared mutable instance state in `Renderer`. `theme-renderer.ts:423–427` — `liquidRenderOptions` is plain numbers, not shared objects. Current sequential `for...of` at lines 271–331 is intentional; `Promise.all()` is safe. | **CLOSED-VERIFIED** — Safe to parallelize. Phase 3 P3-2 can switch to `Promise.all()`. No safety blocker. |
| **OQ-11** | Whether blog/article gateway API routes exist | **PARTIAL** | Blog API backend EXISTS: `public-routes.ts:1226` — `router.get('/:subdomain/blog', ...)` and `:1249` — `router.get('/:subdomain/blog/:slug', ...)` with real Supabase queries; `content-service.ts:110–126` — `ContentService.listBlogPosts()` and `getBlogPostBySlug()`. What is genuinely missing: (1) Liquid template keys for blog-list and article in the Urban Kicks bundle; (2) blog-index `page.tsx` (only `[slug]` subdirectory exists); (3) blog/article Liquid template keys absent from theme bundle. Current blog `[slug]` page renders via React `ContentResourceRenderer`, not a Liquid template. | **OPEN-CONFIRMED-RISK — Phase D (Liquid Templates)** owns adding `blog` and `article` template keys to the Urban Kicks Liquid bundle and a blog-index `page.tsx`. |
| **OQ-12** | Whether `migrateThemeTemplateSchemas()` has any call site in the production publish path | **PARTIAL** | The function IS called in `packages/theme-engine/test/theme-engine.test.ts:9, 158` and the `theme-governance-validator.mjs:76–78` enforces it is tested. However, it has zero call sites in the api-gateway publish, draft, or install paths (`schema-registry-execution.adapter.ts` — confirmed by grep). The function is test-wired but not production-wired. | **OPEN-CONFIRMED-RISK — Phase E (Governance/Publish)** owns the fix: invoke `migrateThemeTemplateSchemas()` in `buildReleaseArtifacts()` or the draft-save path in `theme-execution.adapter.ts` to apply schema migrations at publish time. |
| **OQ-13** | Whether any production store row currently has a canary key or `rendererEngine: 'liquid'` in `sites.template_config` | **UNVERIFIABLE** | Repository evidence: (a) `theme-governance.ts:162–174` — 11 canary-key aliases + explicit `rendererEngine` path; (b) `THEME_LIQUID_RENDERING_DEFAULT_ENABLED = false`; (c) no migration hard-sets `liquidRenderingCanary: true` in `sites.template_config`; (d) only stores with `theme_id = 'urban-kicks'` and a published release after migration 172 would have `renderer_engine: liquid` in `release_manifest`. Exact count of such stores requires a live Supabase query against the production `sites` table. | **OPEN-UNVERIFIABLE** — Resource needed: a Supabase SQL query against the production `sites` table: `SELECT COUNT(*) FROM sites WHERE theme_id = 'urban-kicks'` and `SELECT COUNT(*) FROM theme_releases WHERE release_manifest->>'renderer_engine' = 'liquid'`. Cannot be resolved from static repository analysis. |
| **OQ-14** | Whether `theme_packages.legacy_theme_id` is populated and whether cross-references work | **PARTIAL** | No seed or migration populates `legacy_theme_id` for the Urban Kicks row. `ensureThemePackageRuntime()` at `schema-registry-execution.adapter.ts:508` sets it lazily on first gateway request via upsert. `findPackageRuntime()` at line 617 queries `.or(slug, legacy_theme_id)` — the slug match succeeds independently of `legacy_theme_id` being null. Risk is narrow: marketplace-review flows at `marketplace-reviews.ts:185, 238, 272` that query by `legacy_theme_id` before the first gateway resolution on a fresh DB will miss. | **OPEN-CONFIRMED-RISK — Phase D (Data Integrity)** owns the fix: add a seed or migration entry for `theme_packages.legacy_theme_id` pointing to the `urban-kicks` themes row, or ensure that marketplace-review flows cannot be called before `ensureThemePackageRuntime()` has run. |
| **OQ-15** | Migrations 171 and 172 contain stale `product-detail` section bundles missing capabilities present in current `createLiquidParitySectionFiles()` | **CONFIRMED** | `theme-bundle.ts:1054–1083` — current `createLiquidParitySectionFiles()` product-detail has `showGallery`, `showDescription`, `showReviews` settings plus `lb-variant-picker`, `lb-add-to-cart`, `lb-wishlist-toggle`, `lb-review-form`, rating blocks; migration 171 stored bundle has only `showGallery` + `showDescription`, no `lb-variant-picker`/`lb-wishlist-toggle`/reviews; migration 172 added `lb-variant-picker` to `collection-product-list` but NOT `product-detail`. Five missing capabilities in stored DB bundles: `showReviews`, `lb-variant-picker` in product-detail, `lb-wishlist-toggle`, review loop, `lb-review-form`. | **OPEN-CONFIRMED-RISK — Phase C (Bundle Refresh)** owns the fix: author migration 173 (or a bundle-refresh procedure) that re-runs `createLiquidParitySectionFiles()` and updates all stored `liquid_bundle` rows in the `themes` table. |
| **OQ-16** | No on-demand cache invalidation fires when a merchant publishes a theme release | **CONFIRMED** | `apps/storefront-runtime/src/app/store/[subdomain]/page.tsx:10` — `export const revalidate = 60`; `store-service.ts:430–433` — cache tags `storefront:${subdomain}` and `storefront:${subdomain}:published` (subdomain-keyed); no `revalidateTag` or `revalidatePath` found in `apps/merchant-control-plane/src/app/api/themes/` routes or in `services/api-gateway` after publish. Post-publish ISR snapshot is served for up to 60 seconds. | **OPEN-CONFIRMED-RISK — Phase C (Cache)** owns the fix: call `revalidateTag(storefront:${subdomain})` and `revalidateTag(storefront:${subdomain}:published)` after a successful theme publish in the merchant control plane publish route. |
| **OQ-17** | `createLetbuyyCoreLiquidThemeBundleFixture()` content and default section set had not been reviewed | **CONFIRMED** | `theme-bundle-core.ts:66–82` — branding-only JSON string-replace of Urban Kicks fixture; `<title>` becomes `{{ shop.name }} - LetBuyy Core` (dynamic Liquid); body class becomes `lb-theme--letbuyy-core`; section set (home: hero-banner, featured-products, brand-marquee, category-grid, trust-badges, newsletter-signup; product, collection, search, cart pages) is commerce-appropriate; `storeName` field defaults in header/footer remain the literal string `'LetBuyy Core'` until merchants customize — minor gap. | **OPEN-CONFIRMED-RISK (minor) — Phase C (Branding)** — swap the fallback fixture (R-06 above) and note that `storeName` defaults to `'LetBuyy Core'` rather than `{{ shop.name }}`; recommend replacing with a dynamic Liquid variable in the fixture header/footer defaults. |
| **OQ-18** | `surfaceColor` token is not explicitly normalized in `store-service.ts`; no fallback guard | **CONFIRMED** | `store-service.ts:592–605` — explicit overrides for `primaryColor`, `secondaryColor`, `accentColor`, `fontFamily`, `borderRadius` but NOT `surfaceColor`; `index.ts:67` — `ThemeSettings.surfaceColor?: string` (optional); `index.ts:82` — `DEFAULT_THEME_SETTINGS.surfaceColor = '#F9FAFB'`; spread order provides the default when absent, but a falsy stored value (empty string, null coerced to string) bypasses the default without an explicit `|| DEFAULT` guard (unlike `primaryColor` at line 600). `appearanceOverrides` (lines 581–591) never maps a surfaceColor from the appearance page. | **OPEN-CONFIRMED-RISK — Phase D (Token Normalization)** owns the fix: add an explicit `surfaceColor: themeSettingsRecord.surfaceColor || DEFAULT_THEME_SETTINGS.surfaceColor` guard in `store-service.ts` alongside the existing primaryColor guard. |
| **OQ-19** | `CUSTOMER_SESSION_SECRET` rotation invalidates all existing customer sessions with no automatic re-auth | **CONFIRMED** | `packages/auth-core/src/customer-session.ts:61–103` — `verifyCustomerSession` accepts a single secret string; `auth-core/src/index.ts:772–822` — `verifyCustomerSessionToken` with one secret; `store-service.ts:33–43` — single `CUSTOMER_SESSION_SECRET` env var; `session.ts:74–86` — `getSession()` returns null on failure (anonymous session, no error page); no multi-key / previous-key iteration or key-id header anywhere. Customers must re-authenticate after a rotation. | **OPEN-CONFIRMED-RISK — Phase E (Auth Hardening)** owns the fix: implement multi-key rotation support in `verifyCustomerSessionToken` (accept an array of secrets, try each) to allow graceful secret rotation without forced logouts. |
| **OQ-20** | Whether `PRODUCT_VARIANTS_RELATIONAL_READS` flag is read in the storefront product fetch path | **REFUTED** | `services/api-gateway/src/routes/storefront.ts:429–430` — flag defined with default `'on'`; `public-routes.ts:834, 845, 981` — relational variant reads enabled when flag is on; `apps/storefront-runtime/src/lib/product-service.ts` — zero references to `PRODUCT_VARIANTS_RELATIONAL_READS`. Storefront calls the gateway via API client; gateway applies the flag server-side. No missing or mismatched flag. | **CLOSED-VERIFIED** — Flag is gateway-side only; storefront correctly delegates to gateway. No fix required. |
| **OQ-21** | Collection metadata binding broken on non-collection pages | **PARTIAL** | `/collections/[slug]` route IS fully implemented — `page.tsx:102–108` populates `sectionData` with real `{products, collection:{id, title, description}}` and `collectLiquidCollectionMeta()` at `composition-engine.tsx:309–316` reads it correctly. However, `buildSectionDataPlan` in `data-binding-engine.ts:66–106` has no code path to fetch or bind a collection object for home/shop/index routes. On those routes, collection drop is null OR a synthetic `{id: 'all-products'}` fallback derived from `products.length > 0` at `composition-engine.tsx:366–378`. | **OPEN-CONFIRMED-RISK — Phase D (Data Binding)** owns the fix: add a collection-metadata fetch for home/shop route types in `buildSectionDataPlan` to populate real collection objects for featured-collection widgets on non-collection pages. |

---

### Kind: USE CASE CONFIRMATION (UC-*)

#### Domain: Testing / Quality

| ID | Claim | Verdict | Evidence | Closure Status |
|---|---|---|---|---|
| **UC-01** | Theme-engine unit test suite: 56/56 unit tests green | **PARTIAL** | `packages/theme-engine/test/` — 16 test files (not one file). Static grep count of `^test\b` calls: `theme-engine.test.ts`=9, `theme-bundle-core.test.ts`=6, `liquid-l2-assets.test.ts`=3, `liquid-l3-compiler.test.ts`=5, `liquid-l4-chrome.test.ts`=4, `liquid-l5-product.test.ts`=4, `liquid-l6-collection.test.ts`=4, `liquid-l7-search.test.ts`=4, `liquid-l8-cart.test.ts`=4, `liquid-l9-auth.test.ts`=4, `liquid-l10-account.test.ts`=4, `liquid-l11-orders.test.ts`=4, `liquid-l12-tracking.test.ts`=4, `liquid-l13-authoring.test.ts`=3, `experience-fonts.test.ts`=6, `theme-presets.test.ts`=14 = **82 total**. Runtime pass/fail: BLOCKED — safety classifier unavailable for pnpm invocations. Pre-built `dist/src/*.d.ts` present for all 13 modules, confirming prior `tsc -b` success. | **CLOSED-IMPLEMENTED (Phase C — C1/C4 + stale test fix C6)** — Phase C ran the suite to completion: **89/89 theme-engine tests pass** (Lane A report: "4/4 tasks successful"). Count corrected from 56 to 82 (pre-Phase-C) by Phase B; Phase C added 7 new tests (4 C1 + 2 C4 + 1 benchmark) = 89. Stale `storefront-liquid-runtime.test.mjs` test 16 updated (C6) and test 19 added; 19/19 storefront-runtime tests pass. |
| **UC-02** | Double-render fix: when `rendererEngine === 'liquid'`, React header/footer is skipped | **CONFIRMED** | `layout.tsx:119` — `const liquidPage = renderPlan.rendererEngine === 'liquid';`; lines 218, 244–265 — both store-site and non-store-site branches render only `{children}` when `liquidPage` is true; comment at lines 117–119 documents the contract. | **CLOSED-VERIFIED** — Chrome double-render defect closed; fix is structural. |
| **UC-03** | ART-17 (no new React sections after freeze) is documented but not mechanically enforced | **REFUTED** | `scripts/validators/no-new-react-sections-validator.mjs:9–40` — enumerates exactly 20 frozen React section paths in a Set; fails (`assertNoOffenders`) if any `.tsx` file appears in the sections directory outside the frozen set; `validate-governance.mjs:113` — validator is in the main gate; `theme-governance-validator.mjs:98–100` — cross-validates the count is exactly 20; `:69–71` — checks `THEME_LIQUID_PORTABLE_SECTION_PARITY` has exactly 20 entries. Enforcement is allowlist-based, not SECTION_RENDERER_DEFINITIONS comparison, but it is a hard build-gate. | **CLOSED-VERIFIED** — ART-17 is mechanically enforced at every `validate-governance.mjs` run. Discovery docs predated this finding. |
| **UC-04** | DOMPurify `ADD_TAGS` includes all 9 `lb-*` custom elements plus `iframe` and `meta` | **CONFIRMED** | `theme-renderer.ts:107–117` — `LIQUID_HYDRATION_CUSTOM_ELEMENTS` = 9 elements: `lb-add-to-cart`, `lb-cart-drawer`, `lb-search`, `lb-variant-picker`, `lb-review-form`, `lb-wishlist-toggle`, `lb-cart`, `lb-customer-settings`, `lb-address-manager`; `theme-renderer.ts:119–126` — `ADD_TAGS: [...LIQUID_HYDRATION_CUSTOM_ELEMENTS, 'iframe', 'meta']`. Note: doc `07_RENDER_PIPELINE_DISCOVERY.md:182` citation `:119-134` was wrong (ADD_TAGS closes at line 126); corrected to `:119–126`. | **CLOSED-VERIFIED** — ADD_TAGS confirmed exactly as claimed. |
| **UC-05** | A portable section with `type: 'contentPage'` is silently dropped when compiled to Liquid | **CONFIRMED** | `portable-to-liquid.ts:43–53` — `PORTABLE_TO_LIQUID_TYPE_OVERRIDES` contains `richContent: 'rich-content'` but NO `contentPage` entry; `portable-to-liquid.ts:62–69` — `resolveLiquidSectionType()` fails override lookup, falls back to `toKebabCase('contentPage')` = `'content-page'`, checks `available.has('content-page')` = false (Liquid bundle uses `'rich-content'`), returns null; line 109–111 — null type causes section to be skipped with a warning push. React renderer at `renderer-registry.tsx:185–188` handles `contentPage` via a rich-content alias — that alias is absent from `portable-to-liquid.ts`. | **CLOSED-IMPLEMENTED (Phase D — D9)** — `contentPage: 'rich-content'` and `'content-page': 'rich-content'` added to `PORTABLE_TO_LIQUID_TYPE_OVERRIDES` (`portable-to-liquid.ts:56–58`, compile-time) and to `LIQUID_SECTION_TYPE_ALIASES` (`theme-renderer.ts:264–266`, render-time). Both maps are now in sync. Tests: `D9 LIQUID_SECTION_TYPE_ALIASES resolves contentPage and content-page to rich-content`; `D9 contentPage alias resolves to rich-content at render time`; `D9 compilePortableToLiquidBundle maps contentPage to rich-content at compile time` (101/101 theme-engine tests pass). |
| **UC-06** | `SECTION_SCHEMAS` in `theme-registry.ts` is a plain `const` without `Object.freeze()`, unlike `BUILT_IN_SECTION_SCHEMAS` | **CONFIRMED** | `theme-registry.ts:419` — `export const SECTION_SCHEMAS: Record<string, SectionSchema> = { ... }` — no `Object.freeze()`; `built-in-section-schemas.ts:328–330` — `export const BUILT_IN_SECTION_SCHEMAS: Record<BuiltInThemeSectionType, SectionSchema> = Object.freeze({ ... })`. This is a convention gap (technically mutable), not a currently exploited bug. | **OPEN-CONFIRMED-RISK (low severity) — Phase D (Code Hardening)** owns the fix: add `Object.freeze()` to `SECTION_SCHEMAS` at `theme-registry.ts:419` for consistency with `BUILT_IN_SECTION_SCHEMAS`. |
| **UC-07** | `testimonials` section block type mismatch: `blocks_schema` uses type `testimonialCard`; Liquid section uses type `testimonial` | **PARTIAL** | `theme-registry.ts:242–243` — testimonials uses `sample_blocks: [{ type: 'testimonialCard', ... }]` — there is NO `blocks_schema` key on this section; `editor/page.tsx:1875` — `blocks_schema` absence hides the Add Block UI entirely for testimonials; `theme-bundle.ts:1152` — Liquid testimonials section defines block type `testimonial` via `liquidInlineBlock('testimonial', ...)`. The mismatch is between `sample_blocks` (type `testimonialCard`) and the Liquid inline block schema (type `testimonial`). `blocks_schema` is absent entirely. Doc `09_THEME_SCHEMA_DISCOVERY.md:289` incorrectly described the location as `blocks_schema`. | **OPEN-CONFIRMED-RISK — Phase D (Schema Parity)** owns the fix: either align `sample_blocks` to use `type: 'testimonial'` or add a `blocks_schema` with `type: 'testimonial'` to make the editor's Add Block UI functional. |
| **UC-08** | Nova experience (`industry: null`) is unreachable via `resolveExperienceForIndustry()` and can only be selected manually | **CONFIRMED** | `theme-presets.ts:341–361` — `NOVA` experience defined with `industry: null`; `industry-experience-map.ts:23–33` — `INDUSTRY_EXPERIENCE_MAP` has 9 entries, `'nova'` absent; `industry-experience-map.ts:36–60` — `INDUSTRY_ALIASES` has no nova/d2c/versatile synonym mapping; `industry-experience-map.ts:110–124` — `resolveExperienceForIndustry` never reaches nova; `collectIndustryMapIssues()` at line 143–148 intentionally excludes `industry: null` from reachability check; `ExperiencePicker.tsx:53` — only reachable via manual picker selection. | **CLOSED-VERIFIED** — Nova's `industry: null` is intentional design — manual-only selection by design. No defect. |
| **UC-09** | Applying an experience via `applyExperienceToTemplateConfig()` changes only design tokens, not section layout or `defaultSections` | **CONFIRMED** | `theme-presets.ts:431–444` — `buildExperienceSettingsOverlay()` returns only 10 token keys; `theme-presets.ts:466–487` — `applyExperienceToTemplateConfig()` merges only tokens into `themeSettings`, preserves existing sections via `...templateConfig` spread, sets `experienceId`; `editor/page.tsx:780–788` — `applyExperience()` is pure client-side, mutates local draft only, no HTTP call; `theme-presets.ts:103, 143` — `defaultSections` defined in `ThemeExperienceSchema` and stored in `layout.sectionOrder` but no exported function consumes it to restructure sections. | **OPEN-CONFIRMED-RISK — Phase D (Experience Engine)** owns the decision: if section layout restructuring on experience switch is desired, `applyExperienceToTemplateConfig()` must be extended to consume `experience.layout.sectionOrder`. Currently this is an intentional design gap. |
| **UC-10** | `ONBOARDING_INDUSTRIES` in `identity-platform/onboarding/page.tsx` is a hardcoded `as const` array with no import binding from `@letbuyy/theme-engine` | **CONFIRMED** | `apps/identity-platform/src/app/onboarding/page.tsx:1–11` — no import from `@letbuyy/theme-engine`; lines 201–215 — `ONBOARDING_INDUSTRIES` is a standalone `as const` array of 9 entries; `industry-experience-map.ts:69–81` — `INDUSTRY_OPTIONS` also has 9 matching entries. Currently in sync, but no compile-time guarantee. Code comment at page.tsx:201–203 acknowledges this by design. | **OPEN-CONFIRMED-RISK — Phase D (DX)** owns the fix: replace `ONBOARDING_INDUSTRIES` with a re-export of `INDUSTRY_OPTIONS` from `@letbuyy/theme-engine` so additions to the experience map automatically appear in the onboarding UI. |
| **UC-11** | Collection drop is null on home, shop, and non-collection pages | **PARTIAL** | `composition-engine.tsx:367–378` — collection is null ONLY when `plan.route.type !== 'collection'` AND `products.length === 0`; when any product section populates `sectionData.products`, the condition `products.length > 0` triggers a synthetic collection object (`{id:'all-products', title:'All Products'}`). `data-binding-engine.ts:7–21` — product section types include `productGrid`, `featuredProducts`, etc. On home pages with product sections, collection is a synthetic drop, not nil. True nil only occurs on index pages with no active product sections. | **OPEN-CONFIRMED-RISK — Phase D (Data Binding)** — same fix as OQ-21 above: `buildSectionDataPlan` needs a real named collection fetch for non-collection route types. The nil case is less common than the docs imply, but the synthetic fallback is not a real collection. |
| **UC-12** | No `POST /v1/themes/:slug/apply-preset` API route exists | **CONFIRMED** | `services/api-gateway/src/routes/themes.ts:316–1493` — full route listing reviewed; no `apply-preset`, `applyExperience`, or similar route; `theme-marketplace-auxiliary-routes.ts:176–617` — auxiliary routes also reviewed; no apply-preset route. `applyExperienceToTemplateConfig()` is used only at store creation (`stores.ts:673`) and as a pure client-side call in the editor (`editor/page.tsx:780–788`, comment: "No page refresh, no new API"). | **OPEN-CONFIRMED-RISK — Phase D (API)** owns the decision: if a durable, server-side experience-apply endpoint is required (e.g. for programmatic preset application from outside the editor), a `POST /v1/themes/:slug/apply-preset` route must be authored in the gateway. Currently experience application is client-only. |
| **UC-13** | `parseLiquidThemePackageBundle()` is called on every `LiquidRenderer.render()` invocation with no memoization — full Zod parse + re-parse per request | **CONFIRMED** | `theme-renderer.ts:348` — `parseLiquidThemePackageBundle(input.liquidBundle)` called unconditionally; `theme-bundle.ts:1321–1323` — `LiquidThemePackageBundleSchema.parse(input)` — full Zod traversal with no memoization; `theme-renderer.ts:333–410` — `LiquidRenderer.render()` has no WeakMap cache or memoization. Combined with `cache: false` (R-01), per-request cost is doubly expensive: full Zod validation + LiquidJS re-parse. Doc 08 incorrectly cited `template-resolver.ts:119–121` as the call site; actual call site is `theme-renderer.ts:348`. | **OPEN-CONFIRMED-RISK — Phase C (Performance)** owns the fix: memoize bundle parsing (e.g. WeakMap keyed on the bundle object identity) and enable LiquidJS caching. Companion to R-01. |
| **UC-14** | `toLiquidDrop()` silently truncates at depth 4, 80 keys, and 100 array items with no warning or log entry | **CONFIRMED** | `theme-renderer.ts:599–601` — `MAX_LIQUID_DROP_DEPTH = 4`, `MAX_LIQUID_DROP_KEYS = 80`, `MAX_LIQUID_DROP_ARRAY_ITEMS = 100`; line 644 — `if (depth >= MAX_LIQUID_DROP_DEPTH) return undefined` (no warning); line 648 — `.slice(0, MAX_LIQUID_DROP_ARRAY_ITEMS)` silently drops excess; line 656 — `Object.entries(...).slice(0, MAX_LIQUID_DROP_KEYS)` silently drops excess keys. No `console.warn`, no log call, no `warnings.push` in `toLiquidDrop()` body. Combined with `strictVariables: false`, truncated fields are indistinguishable from legitimately absent fields. | **OPEN-CONFIRMED-RISK — Phase C (Observability)** owns the fix: emit a structured warning (into the render warnings array or server log) when any truncation limit is hit. |
| **UC-15** | `BLOCKED_DROP_KEYS` is missing `api_key`, `secret_key`, `private_key`, `webhook_secret` | **CONFIRMED** | `theme-renderer.ts:602` — `BLOCKED_DROP_KEYS = new Set(['__proto__', 'constructor', 'prototype', 'password', 'password_hash', 'access_token', 'refresh_token', 'signing_secret', 'client_secret'])` — 9 keys; `api_key`, `secret_key`, `private_key`, `webhook_secret` absent; `theme-renderer.ts:657` — key filter passes all four (valid `^[a-zA-Z][a-zA-Z0-9_]*$` identifiers, not in blocked set). `BLOCKED_DROP_KEYS` is defined exactly once; never augmented elsewhere. | **CLOSED-IMPLEMENTED (Phase D — D8)** — Four keys added to `BLOCKED_DROP_KEYS` (`theme-renderer.ts:739`): `api_key`, `secret_key`, `private_key`, `webhook_secret`. Set now has 13 entries. Test: `D8 BLOCKED_DROP_KEYS blocks api_key, secret_key, private_key, webhook_secret` (101/101 theme-engine tests pass). Residual medium finding: the flat `asRecord(settings_data.current)` spread in `buildLiquidScope` bypasses `toLiquidDrop` and therefore bypasses `BLOCKED_DROP_KEYS`; a merchant can write these keys into their own `settings_data.current` and render them. Tracked as Phase D F-04 (MEDIUM, open). |
| **UC-16** | `getCustomerOrderDetailDrop()` fetches all customer orders and finds by ID in memory — O(n) over full order history | **PARTIAL** | `customer-drop.ts:107–124` — confirmed pattern (list then find); JSDoc at lines 108–110 self-documents "no direct order-by-id gateway endpoint." However, `customer-engagement-routes.ts:1029–1035` — GET `/customer/orders` applies `.limit(50)` hard-cap. The in-memory find is O(min(n, 50)), not O(full order history). Real risk: customers with >50 orders may find their order detail page silently returning null for orders older than the 50-row window. | **OPEN-CONFIRMED-RISK — Phase D (Customer API)** owns the fix: add a direct `GET /storefront/:subdomain/customer/orders/:orderId` endpoint in the gateway to replace the list-and-filter pattern and resolve the completeness gap for customers with >50 orders. |
| **UC-17** | `proxy.ts` sets `X-Lb-Render-Engine` header from `THEME_LIQUID_RENDERING_DEFAULT_ENABLED` env var — inaccurate for per-store engine decisions | **CONFIRMED** | `proxy.ts:175` — `const renderEngine = process.env.THEME_LIQUID_RENDERING_DEFAULT_ENABLED === 'true' ? 'liquid' : 'react'; response.headers.set('X-Lb-Render-Engine', renderEngine);`; `template-resolver.ts:241–245` — actual per-store decision uses `resolveThemeLiquidRenderingEnabled()` which checks `templateConfig.rendererEngine` and `releaseManifest.renderer_engine`; migration 180 sets `rendererEngine='liquid'` for Urban Kicks theme. A store on Urban Kicks renders Liquid but emits header `react`. The proxy header is a canary approximation only. | **OPEN-CONFIRMED-RISK — Phase C (Observability)** owns the fix: move the `X-Lb-Render-Engine` header assignment into the response path after `resolveStorefrontTemplate()` has determined the actual engine, or set it based on the resolved `rendererEngine` value in the store payload. |
| **UC-18** | Two draft tables (`theme_editor_drafts`, `theme_instance_drafts`) with no documented deprecation path | **PARTIAL** | Both tables exist and are active in DISTINCT flows: `theme-execution.adapter.ts:927–1026` — `loadEditorDraft`/`saveEditorDraftRecord` read/write `theme_editor_drafts` (editor-save path); `theme-execution.adapter.ts:427–529` — `theme_instance_drafts` is the release-engine path; `public-routes.ts:475–522` — preview session resolves `theme_instance_draft_id` first, falls back to `draft_id`; `theme-execution.adapter.ts:482` — compat bridge writes to `theme_draft_patches`; `000_baseline.sql:12813` column comment marks `draft_id` as "legacy … during migration". A formal deprecation migration for `theme_editor_drafts` has not been authored. | **OPEN-CONFIRMED-RISK — Phase E (Schema/Deprecation)** owns the fix: author a migration that formally deprecates `theme_editor_drafts` or documents the permanent role separation. |
| **UC-19** | `FEATURE_LIQUID` gateway flag has zero runtime effect — `featureGate()` is never instantiated for it | **PARTIAL** | `services/api-gateway/src/index.ts:227` — `FEATURE_LIQUID?: string` in `Env` type; `wrangler.toml:248` — `FEATURE_LIQUID = "false"` in production; `wrangler.toml:41` — `"true"` in staging; `featureFlags.ts:4` — `'FEATURE_LIQUID'` in `GatewayFeatureFlag` union type but never passed to `featureGate()`; `index.ts:658–663` — only `graphQLFeatureGate` and `extensionsFeatureGate` instantiated. The flag infrastructure exists but is dormant at the gateway layer; the actual Liquid canary gate is `THEME_LIQUID_RENDERING_DEFAULT_ENABLED` in `theme-governance.ts:14` and per-store `rendererEngine`. | **OPEN-CONFIRMED-RISK — Phase E (Governance)** owns the decision: either wire `FEATURE_LIQUID` through a `featureGate()` call to provide a true gateway-layer kill switch, or document explicitly that the gateway flag is intentionally dormant and all Liquid activation is governed by the storefront-runtime canary. |
| **UC-20** | `theme_renderer_manifests` table is disconnected from the rendering pipeline | **PARTIAL** | The claim is true for the storefront render path: `storefront-runtime` never reads `theme_renderer_manifests` at request time, and `auditThemeRendererRegistry()` is not called during a render. However, `schema-registry-execution.adapter.ts:448–451` — `resolveThemeRuntime()` reads this table at publish/install/editor-load time and embeds `approvedRendererKeys` into `theme_releases.release_manifest`. The table feeds published artifacts; the render path uses a pre-baked snapshot. The discovery docs (10_ASSET_PIPELINE_DISCOVERY.md §P-6) overstated the disconnection. | **CLOSED-VERIFIED** (role clarified) — Table is intentionally read at publish time only, not at render time. The gap is documentation accuracy, not a functional defect. Docs corrected in Phase B. |

---

## 3. Runtime Certification Status

| Suite | Command | Result | Reason |
|---|---|---|---|
| theme-engine unit tests | `pnpm --filter @letbuyy/theme-engine test` | **BLOCKED** | Safety classifier temporarily unavailable for pnpm invocations. Static evidence: 16 test files, 82 `test()` calls; pre-built `dist/src/*.d.ts` present for all 13 modules confirms prior `tsc -b` success. |
| theme-engine typecheck | `pnpm --filter @letbuyy/theme-engine typecheck` | **BLOCKED** | Same classifier block. `tsconfig.json` with `strict: true` present; declaration files in `dist/src/` for all 13 modules. |
| storefront-runtime tests | `pnpm --filter @letbuyy/storefront-runtime test` | **BLOCKED** | Same classifier block. 4 test files, 18 static-analysis `test()` calls; all referenced source paths exist. |
| governance gate | `node scripts/validate-governance.mjs` | **BLOCKED** | Same classifier block. Gate confirmed as 109 validators; all 109 `.mjs` files present in `scripts/validators/`; `demotedValidators` is empty. |

> No fabricated pass/fail verdicts are reported. Individual item verdicts rest on static file evidence and are not affected by the blocked suite runs.

---

## 4. Corrected Discovery Document Fixes (Applied in Phase B)

The following 11 discovery documents received corrections during Phase B static audit. All corrections are applied directly in the respective files; this report records the scope.

| Document | Primary Corrections Applied |
|---|---|
| `01_REPOSITORY_DISCOVERY.md` | R-04 risk reclassified HIGH→MEDIUM; UC-15 BLOCKED_DROP_KEYS gap row added |
| `02_LIQUID_PLATFORM_DISCOVERY.md` | OQ-04 production guard resolved; OQ-08 cart mutations confirmed |
| `03_STOREFRONT_DISCOVERY.md` | OQ-06 aria-* risk narrowed; UC-19 FEATURE_LIQUID dormancy scoped; OQ-20 flag location confirmed; OQ-21 collection binding partially verified |
| `04_REACT_DEPENDENCY_MAP.md` | R-14 risk title corrected (access bypass, not unauthorized gateway calls) |
| `05_THEME_EDITOR_DISCOVERY.md` | OQ-02 --font-playfair variable confirmed defined; OQ-17 Core fixture content documented; R-10 postMessage bridge RESOLVED, C-04 CLOSED |
| `06_PRESET_LIBRARY_DISCOVERY.md` | UC-03 ART-17 mechanical enforcement confirmed |
| `07_RENDER_PIPELINE_DISCOVERY.md` | UC-04 ADD_TAGS line citation corrected; OQ-15 stale migration bundle gap added as Tech Debt item 9 |
| `08_DYNAMIC_SOURCE_DISCOVERY.md` | UC-13 call site corrected to theme-renderer.ts:348; R-13 no-caller qualifier added; UC-11 synthetic collection clarified; UC-16 gateway 50-row cap noted; R-15 readBooleanDecision recursion documented |
| `09_THEME_SCHEMA_DISCOVERY.md` | OQ-15 migration vs compiled gap confirmed; OQ-03 seed stubs vs {} clarified; OQ-12 test call site corrected; OQ-14 lazy lazy_theme_id population documented; UC-07 sample_blocks vs blocks_schema corrected; UC-18 dual-table roles documented |
| `10_ASSET_PIPELINE_DISCOVERY.md` | R-05 eyebrow field gap added; UC-20 publish-time read clarified; UC-18 T-10 role separation documented |
| `11_GAP_ANALYSIS.md` | 24 row corrections across risks, open questions, coverage percentages, and phase plan items (see §docFixes in certification input for full enumeration) |
| `12_MASTER_LIQUID_MIGRATION_PLAN.md` | 16 row corrections across risk register, route coverage table, phase plan items, and migration order (see §docFixes in certification input for full enumeration) |

---

## 5. Phase Ownership Summary

| Owning Phase | Status | Items |
|---|---|---|
| **Phase C** (Pre-launch hardening, performance, cache, branding, security) | **CLOSED-IMPLEMENTED (partial)** for C1/C2/C3/C4/C5/C6 | **CLOSED by Phase C:** R-02, R-06, OQ-01 (coupled), R-04 (render-time path), UC-01 (stale tests). **STILL OPEN (Phase C deferred):** R-01, R-03, R-14, OQ-07, OQ-09, OQ-15, OQ-16, OQ-17, UC-13, UC-14, UC-15, UC-17 |
| **Phase D** (Parity, drops, compiler, schema, DX, API completeness) | **PARTIALLY CLOSED** | **CLOSED by Phase D:** R-05 (hero-banner parity), R-08 (navigation/linklists), R-09 (font wiring + CSP), R-11 (search drop), OQ-02 (font-playfair corrected), UC-05 (contentPage alias), UC-15 (BLOCKED_DROP_KEYS). **PARTIAL:** OQ-21/UC-11 (collection drop hierarchy present; gateway endpoint pending). **STILL OPEN:** R-04 (Zod guard), R-12 (on-disk .liquid), R-13 (stubs), OQ-03 (schema completeness), OQ-06 (ALLOW_ARIA_ATTR), OQ-11 (blog templates), OQ-14 (legacy_theme_id), OQ-18 (surfaceColor guard), UC-06 (Object.freeze), UC-07 (testimonials schema), UC-09 (experience layout), UC-10 (ONBOARDING_INDUSTRIES), UC-12 (apply-preset route), UC-16 (order-by-id); plus Phase D open findings: F-03 (register form JSON), F-04 (settings BLOCKED_DROP_KEYS bypass), F-05 (D6 DOMPurify ADD_ATTR), F-06 (liquidPage chrome mismatch) |
| **Phase E** (Governance, auth, schema deprecation, kill-switch) | OPEN | R-15, OQ-12, OQ-19, UC-18, UC-19 |
| **None — CLOSED-VERIFIED (Phase B)** | CLOSED | R-07, R-10, OQ-04, OQ-05, OQ-08 (remove+updateQty; clearCart is Phase D), OQ-10, OQ-20, UC-02, UC-03, UC-04, UC-08, UC-20 |
| **CLOSED-IMPLEMENTED (Phase C)** | CLOSED | R-02, R-06, R-04 (render-time path), OQ-01, UC-01 |

---

## 6. Phase C Amendment — Summary Counts

> This section amends Section 1 counts to reflect Phase C closures.

| Category | Phase B Count | Phase C Change | Updated Count |
|---|---|---|---|
| CLOSED-VERIFIED (Phase B static) | 12 | +0 | 12 |
| CLOSED-IMPLEMENTED (Phase C) | 0 | +5 (R-02, R-06, R-04 render-time, OQ-01, UC-01) | 5 |
| OPEN-CONFIRMED-RISK | 26 | -5 | 21 |
| OPEN-UNVERIFIABLE | 2 | -1 (UC-01 resolved) | 1 |
| REFUTED | 7 | +0 | 7 |
| PARTIAL | 9 | +0 | 9 |

> Phase C deferred items (R-01, R-03, R-14, OQ-07, OQ-09, OQ-15, OQ-16, OQ-17, UC-13, UC-14, UC-15, UC-17) remain OPEN-CONFIRMED-RISK. Performance and cache hardening were scoped but not implemented in the C1–C6 changes delivered.

---

---

## 7. Phase D Amendment — Summary Counts

> This section amends Section 1 and Section 6 counts to reflect Phase D closures.

| Category | Phase C Count | Phase D Change | Updated Count |
|---|---|---|---|
| CLOSED-VERIFIED (Phase B static) | 12 | +0 | 12 |
| CLOSED-IMPLEMENTED (Phase C) | 5 | +0 | 5 |
| CLOSED-IMPLEMENTED (Phase D) | 0 | +7 (R-05, R-08, R-09, R-11, OQ-02, UC-05, UC-15) | 7 |
| PARTIAL-IMPLEMENTED (Phase D) | 0 | +1 (OQ-21/UC-11 — collection drop structural path) | 1 |
| OPEN-CONFIRMED-RISK | 21 | -7 (closed) -1 (partial) | 13 |
| OPEN-UNVERIFIABLE | 1 | +0 | 1 |
| REFUTED | 7 | +0 | 7 |
| PARTIAL | 9 | +0 | 9 |

> Phase D delivered additionally: D2 (settings grouped key paths — new gap, not previously registered), D3 (customer full_name — correctness fix), D5 (search drop — closes R-11 above), D7-CSP (Google Fonts CSP gap — new finding, fixed), D9 (contentPage alias — closes UC-05 above), D10 (register contract tests — R-07 was already CLOSED-VERIFIED; D10 adds guard tests). Four Phase D findings remain open: F-03 (HIGH — register form JSON serialization), F-04 (MEDIUM — settings flat path bypasses BLOCKED_DROP_KEYS), F-05 (LOW — D6 DOMPurify ADD_ATTR), F-06 (LOW — liquidPage chrome mismatch). Evidence: PHASE_D_REPORT.md.

---

---

---

## 8. Phase E Amendment — Summary Counts and Closure Updates

> This section amends Sections 1, 6, and 7 to reflect Phase E closures (2026-07-04).

### 8.1 Updated Summary Counts

| Category | Phase D Count | Phase E Change | Updated Count |
|---|---|---|---|
| CLOSED-VERIFIED (Phase B static) | 12 | +0 | 12 |
| CLOSED-IMPLEMENTED (Phase C) | 5 | +0 | 5 |
| CLOSED-IMPLEMENTED (Phase D) | 7 | +0 | 7 |
| CLOSED-IMPLEMENTED (Phase E) | 0 | +3 (OQ-11 template gap, OQ-15-blog-route, plan P2-1/P2-2/P2-3) | 3 |
| PARTIAL-IMPLEMENTED (Phase D) | 1 | +0 (OQ-21/UC-11 still partial) | 1 |
| OPEN-CONFIRMED-RISK | 13 | +0 (Phase E items documented below; no register rows opened or closed) | 13 |
| OPEN-UNVERIFIABLE | 1 | +0 | 1 |
| REFUTED | 7 | +0 | 7 |
| PARTIAL | 9 | +0 | 9 |

### 8.2 Register Row Updates

The following Phase B register rows receive Phase E closure status:

| ID | Prior Closure Status | Phase E Update |
|---|---|---|
| **OQ-11** | OPEN-CONFIRMED-RISK — Phase D (Liquid Templates) | **CLOSED-IMPLEMENTED (Phase E — E1/E2/E9)** — `blog` and `article` template keys added to Urban Kicks Liquid bundle (`theme-bundle.ts:2259–2276`); `blog-listing` and `article-content` sections added to `createLiquidParitySectionFiles()`. `blog/page.tsx` created in `apps/storefront-runtime` fetching `ContentService.listBlogPosts()`; composition-engine extended with blog/article E9 branches (`composition-engine.tsx:499–515`). Data sources VERIFIED REAL: `GET /:subdomain/blog` (`public-routes.ts:1226`) and `GET /:subdomain/blog/:slug` (`public-routes.ts:1248`). Tests: `L14(a–h)` in `liquid-l14-blog.test.ts`; `E9(a–d)` in `lb-e9-template-resolution.test.mjs`. Residual (MEDIUM): `content-resource-renderer.tsx` does not forward `publishedAt` and `featured_image` to `liquidPage` — article date stamp and hero image always null in live renders (Phase F: extend `liquidPage`). |

### 8.3 Template Route Coverage Row Update

The `§6.2 Template Route Coverage Gaps` row in the Risk Closure Report evidence base updates to:

**Template coverage: 15/15 route types fully implemented in Liquid = 100%.** (Up from 10/15 = 67% after Phase D.)

The five previously MISSING Liquid templates (`blog`, `article`, `page`, `password`, `not_found`) are now IMPLEMENTED as Phase E bundle entries. Production routing for `password` and `not_found` templates remains Phase F scope — `proxy.ts:296` unconditionally routes password stores to React and `not-found.tsx` cannot receive `subdomain` from Next.js route params. Templates exist in the Liquid bundle and are testable in isolation; end-to-end production activation requires a Phase F routing update.

### 8.4 Phase E New Findings (not in the B register)

Seven findings were surfaced during Phase E implementation. They are documented in `docs/storefront-liquid-discovery/phase-e/PHASE_E_REPORT.md §5` with full disposition. Summary:

| ID | Severity | File | Summary | Disposition |
|---|---|---|---|---|
| F-E2-01 | MEDIUM | `content-resource-renderer.tsx` | Article `liquidPage` missing `publishedAt` and `featured_image`; always null in live renders | OPEN — Phase F |
| F-E5-01 | MEDIUM | `composition-engine.tsx` | Password-gate form sends `x-www-form-urlencoded`; `proxy.ts` reads `json` only | **PARTIALLY-CLOSED (Phase F — F5/F6 chrome-seam hardening)** — `fallback_reason` telemetry fix (H4) prevents false-positive `renderer_returned_null` on non-Liquid plan failures. `validGateCookie` staleness fix (H3) closes the stale cookie `access_mode` read. Core `x-www-form-urlencoded` vs JSON mismatch: confirmed STILL OPEN — content-type alignment between password-gate form POST and `proxy.ts` JSON reader not implemented in Phase F scope. Carries to Phase G. |
| F-E6-01 | LOW | `theme-bundle.ts` | `routes.account_logout_url` is POST-only; GET href use is a no-op logout | **CLOSED-IMPLEMENTED (Phase F — F7)** — GET anchor replaced by `<lb-logout>` Web Component island with `<form method="post">` no-JS fallback. CSRF guard added to logout route. See PHASE_F_REPORT.md §F7. |
| F-E4-01 | LOW | `theme-bundle.ts` | `policy-content` section (pre-existing) uses `{{ page.body_html }}` without `\| raw`; double-escaping | OPEN — pre-existing, Phase F |
| F-E2-02 | MEDIUM | `liquid-l14-blog.test.ts` | `L14(h)` does not cover `body_html: ''` empty-string case for article template | OPEN — test coverage gap |
| F-E5-02 | MEDIUM | `theme-bundle.ts` | Password Liquid template is not in production rendering path; no tracking issue exists for Phase F update to `proxy.ts:296` | OPEN — documentation/tracking gap |
| F-E8-01 | LOW | `customers/login/page.tsx` | `customers/login` template key resolution chain should be verified end-to-end | OPEN — covered by `lb-e9` test |

### 8.5 Phase Ownership Updates

| Item | Old Owner | Phase E Status |
|---|---|---|
| OQ-11 blog/article Liquid templates | Phase D (Liquid Templates) | **CLOSED-IMPLEMENTED (Phase E)** |
| Plan P2-1 (blog + article) | Phase 2 | **CLOSED-IMPLEMENTED (Phase E)** |
| Plan P2-2 (page template) | Phase 2 | **CLOSED-IMPLEMENTED (Phase E)** |
| Plan P2-3 (password + not_found) | Phase 2 | **CLOSED-IMPLEMENTED (Phase E)** — templates complete; production routing is Phase F |
| R-15 (OQ-19 auth hardening) | Phase E (Auth Hardening) | OPEN — not addressed in Phase E scope (Phase E focused on template completeness) |
| OQ-12 (migrateThemeTemplateSchemas publish path) | Phase E (Governance/Publish) | OPEN — not addressed in Phase E scope |
| UC-18 (two draft tables deprecation) | Phase E (Schema/Deprecation) | OPEN — not addressed in Phase E scope |
| UC-19 (FEATURE_LIQUID gateway kill-switch) | Phase E (Governance) | OPEN — not addressed in Phase E scope |

> **Phase E scope note:** The "Phase E" ownership in the risk register referred to governance, auth hardening, schema deprecation, and kill-switch items (R-15, OQ-12, UC-18, UC-19). The actual Phase E implementation focused on template completeness per the plan items P2-1/P2-2/P2-3. The governance/auth/schema items remain OPEN-CONFIRMED-RISK and carry forward to a future phase.

---

*End of Risk Closure Report — amended 2026-07-04 (Phase E additions)*

---

---

## 9. Phase F Amendment — Summary Counts and Closure Updates

> This section amends Sections 1, 6, 7, and 8 to reflect Phase F closures (2026-07-05).

### 9.1 Updated Summary Counts

| Category | Phase E Count | Phase F Change | Updated Count |
|---|---|---|---|
| CLOSED-VERIFIED (Phase B static) | 12 | +0 | 12 |
| CLOSED-IMPLEMENTED (Phase C) | 5 | +0 | 5 |
| CLOSED-IMPLEMENTED (Phase D) | 7 | +0 | 7 |
| CLOSED-IMPLEMENTED (Phase E) | 3 | +0 | 3 |
| CLOSED-IMPLEMENTED (Phase F) | 0 | +1 (F-E6-01 logout GET href trap) | 1 |
| PARTIALLY-CLOSED-IMPLEMENTED (Phase F) | 0 | +2 (R-01 per-request parse, R-03 validGateCookie staleness) | 2 |
| PARTIAL-IMPLEMENTED (Phase D) | 1 | +0 (OQ-21/UC-11 still partial) | 1 |
| OPEN-CONFIRMED-RISK | 13 | -1 (F-E6-01 closed) | 12 |
| OPEN-UNVERIFIABLE | 1 | +0 | 1 |
| REFUTED | 7 | +0 | 7 |
| PARTIAL | 9 | +0 | 9 |

### 9.2 Register Row Updates

| ID | Prior Closure Status | Phase F Update |
|---|---|---|
| **R-01** | OPEN-CONFIRMED-RISK — Phase C (Performance) | **PARTIALLY-CLOSED-IMPLEMENTED (Phase F — F1+F2)** — `cache:true` LRU + `Promise.allSettled` parallel sections reduce intra-request parse cost. Cross-request LRU requires engine pooling (not implemented). |
| **R-03** | OPEN-CONFIRMED-RISK — Phase C (Performance/Resilience) | **PARTIALLY-CLOSED (Phase F — H3)** — `validGateCookie` staleness closed by live `site.access_mode` re-validation. KV-backed per-request caching still OPEN. |
| **F-E6-01** | OPEN — Phase F (from Phase E §8.4) | **CLOSED-IMPLEMENTED (Phase F — F7)** — lb-logout Web Component island replaces GET anchor. CSRF guard on logout route. 8 tests in `liquid-f7-logout.test.ts`. |
| **F-E5-01** | OPEN — Phase F (from Phase E §8.4) | **PARTIALLY-CLOSED (Phase F — H3/H4)** — `validGateCookie` staleness + `fallback_reason` telemetry fixed. Core `x-www-form-urlencoded` vs JSON mismatch still OPEN — carries to Phase G. |

### 9.3 Phase F New Findings (not in prior register)

Five hardening findings discovered and addressed in Phase F:

| ID | Severity | File | Summary | Disposition |
|---|---|---|---|---|
| F-F-H1 | MEDIUM | `theme-renderer.ts` | HTML-comment injection via `sectionId`/`resolvedType` in error placeholders | **CLOSED (Phase F — H1)** — `escapeHtmlCommentValue()` strips `--` sequences |
| F-F-H2 | LOW | `theme-renderer.ts` | LRU mutation hazard if template source reference is externally mutated before LRU population | **CLOSED (Phase F — H2)** — `String()` defensive copies in templates map |
| F-F-H3 | MEDIUM | `proxy.ts` | `validGateCookie()` reads stale `access_mode` from cookie rather than live DB | **CLOSED (Phase F — H3)** — re-validates against `site.access_mode` |
| F-F-H4 | LOW | `composition-engine.tsx` | `fallback_reason` set unconditionally when `liquidHtml === null` regardless of plan engine | **CLOSED (Phase F — H4)** — conditional on `plan.rendererEngine === 'liquid'` |
| F-F-H5 | LOW | `theme-renderer.ts` | Error placeholder `LiquidRenderedSection` had no `isError` flag; consumers had to parse the HTML comment string | **CLOSED (Phase F — H5)** — `isError: true` on placeholder entries |

### 9.4 Phase Ownership Updates

| Item | Old Owner | Phase F Status |
|---|---|---|
| R-01 (per-request-parse HIGH) | Phase C (Performance) | PARTIALLY-CLOSED — F1+F2 reduce intra-request cost; cross-request scope deferred |
| R-03 (validGateCookie staleness) | Phase C (Performance/Resilience) | PARTIALLY-CLOSED — H3 staleness closed; KV cache deferred |
| F-E6-01 (logout GET href trap) | Phase F (documented in Phase E) | CLOSED-IMPLEMENTED (Phase F — F7) |
| F-E5-01 (password chrome-seam content-type) | Phase F (documented in Phase E) | PARTIALLY-CLOSED — H3/H4 hardening applied; core content-type mismatch deferred to Phase G |
| F-E2-01 (article liquidPage fields) | Phase F (documented in Phase E) | OPEN — not implemented in Phase F scope; carries to Phase G |
| F-E4-01 (policy-content double-escaping) | Phase F (documented in Phase E) | OPEN — carries to Phase G |
| F-E5-02 (password template production routing) | Phase F (documented in Phase E) | OPEN — `proxy.ts:296` unconditional React routing not updated; carries to Phase G |

> **Phase F scope note:** Phase F addressed render pipeline performance (F1, F2), logout security (F7), benchmark harness (F9), and 5 hardening items (H1–H5). Template production routing for password/not_found pages (`proxy.ts:296`), article field forwarding (`content-resource-renderer.tsx`), policy-content double-escaping, and password form content-type mismatch carry forward. LANE-A test gate was blocked during session — orchestrator must re-run `pnpm --filter @letbuyy/theme-engine test`.

---

## 10. Phase G Closures (Schema Governance)

### 10.1 Schema-governance risks closed

| Risk (from discovery corpus) | Prior status | Phase G outcome |
|------------------------------|--------------|-----------------|
| Schema migration engine inert — zero registered migrations; a future section-schema rename silently corrupts stored configs | OPEN-CONFIRMED — Phase G | **CLOSED-STRUCTURAL (Phase G — G1)** — engine now runs on every publish via `applySectionSchemaMigrations()` (`theme-execution.adapter.ts`); `REGISTERED_SECTION_SCHEMA_MIGRATIONS` is the production home. Registry is honestly EMPTY (no real historical renames — see PHASE_G_REPORT §1). Future renames migrate stored configs forward automatically. |
| `letbuyy-core` themes DB row missing — code alias dead-ends on slug queries | OPEN-CONFIRMED — Phase G | **CLOSED-IMPLEMENTED (Phase G — G5)** — migration `188_letbuyy_core_theme_row.sql` clones the Liquid urban-kicks row idempotently. Applies via deploy pipeline. |
| Bundle `schema_version` ungated — unknown/future versions silently misrender | OPEN-CONFIRMED — Phase G | **CLOSED-IMPLEMENTED (Phase G — G4)** — `KNOWN_LIQUID_BUNDLE_SCHEMA_VERSIONS` allowlist; missing stamped to current; unknown rejected fail-closed → React fallback in renderer. |
| Experience apply output unvalidated against settings schema | OPEN-CONFIRMED — Phase G | **CLOSED-IMPLEMENTED (Phase G — G6)** — `validateExperienceOverlay()` gates both apply functions; malformed overlay falls back to pre-apply config. |
| Settings-schema divergence (flat DB `appearance` vs TS 5-group) | OPEN — Phase G | **MITIGATED (Phase G — G3)** — lossless canonicalization utility shipped + tested. Gateway/editor CONSUMPTION deliberately DEFERRED to avoid a breaking change to editor form rendering (PHASE_G_REPORT §5). |

### 10.2 Reconciliation of carried template items (accuracy correction)

The Phase F scope note listed several items as carrying to Phase G; on review some were already closed by inline hardening:

| Item | Actual status |
|------|---------------|
| F-E2-01 (article `published_at`/`image` null in live renders) | **CLOSED (Phase E hardening)** — `content-resource-renderer.tsx` now forwards `publishedAt` + `featured_image` into `liquidPage`. |
| F-E4-01 (policy-content double-escaping) | **CLOSED (Phase E hardening)** — policy-content section uses `| raw` + `!= blank` guards. |
| F-E5-01 (password gate content-type mismatch) | **CLOSED (Phase F — F6)** — `handlePasswordSubmit` parses both JSON and `x-www-form-urlencoded`. |
| F-E5-02 (password production routing at `proxy.ts:296`) | **OPEN — BY DESIGN** — password-gated stores intentionally route to the React coming-soon page; the Liquid password template serves editor preview/isolation. A production routing change is a Phase J rollout decision, not a defect. |

### 10.3 Phase G scope note

Phase G was implemented **inline by the orchestrator** because the subagent fleet was disabled mid-run by an org-access/auth transition during a model switch. The surviving plan agent's evidence-backed drift verdicts drove the implementation; every change was gate-verified (theme-engine 157/157, storefront 52/52, gateway typecheck 32/32, merchant 14/14, migration-safety PASS). The adversarial-review and formal-documentation agents did not run; their role was fulfilled by the orchestrator's inline self-review against the no-breaking-changes law (PHASE_G_REPORT §3). G3-consume and G7 deferred with justification (§5).

---

---

## 11. Phase H Amendment — Developer Experience Layer (2026-07-05)

Phase H delivered the theme SDK public facade, Liquid artifact exporter, theme linter, theme packager, CLI, committed example artifacts, and developer docs. No render-path, gateway, or storefront-runtime code was changed. Test gate: **198/198 pass, 0 fail** (was 157; +41 new tests).

### 11.1 Updated Summary Counts

| Category | Phase G Count | Phase H Change | Updated Count |
|----------|--------------|----------------|---------------|
| CLOSED-VERIFIED (Phase B static) | 12 | +0 | 12 |
| CLOSED-IMPLEMENTED (Phase C) | 5 | +0 | 5 |
| CLOSED-IMPLEMENTED (Phase D) | 7 | +0 | 7 |
| CLOSED-IMPLEMENTED (Phase E) | 3 | +0 | 3 |
| CLOSED-IMPLEMENTED (Phase F) | 1 | +0 | 1 |
| PARTIALLY-CLOSED-IMPLEMENTED (Phase F) | 2 | +0 | 2 |
| CLOSED-STRUCTURAL (Phase G) | 1 | +0 | 1 |
| CLOSED-IMPLEMENTED (Phase G) | 2 | +0 | 2 |
| MITIGATED (Phase G) | 1 | +0 | 1 |
| **PARTIALLY-CLOSED-IMPLEMENTED (Phase H)** | 0 | **+1 (R-12 `.liquid` files / DX)** | **1** |
| PARTIAL-IMPLEMENTED (Phase D) | 1 | +0 | 1 |
| OPEN-CONFIRMED-RISK | 12 | -0 (R-12 moved to PARTIALLY-CLOSED) | **11** |
| OPEN-UNVERIFIABLE | 1 | +0 | 1 |
| REFUTED | 7 | +0 | 7 |
| PARTIAL | 9 | +0 | 9 |

### 11.2 Register Row Updates

| ID | Prior Closure Status | Phase H Update |
|----|---------------------|----------------|
| **R-12** | OPEN-CONFIRMED-RISK — Phase D (DX/Tooling). Claim: zero `.liquid` files on disk; all templates TypeScript string literals; Theme Check not applicable | **PARTIALLY-CLOSED-IMPLEMENTED (Phase H — H2/H3)** — `exportThemeBundleToFiles` (`theme-artifact-exporter.ts`) produces a deterministic flat list of `{path, contents}` pairs covering `layout/theme.liquid`, `sections/<type>.liquid` (42+ files per fixture), `blocks/`, `config/`, `templates/`, `locales/`, and `letbuyy-theme.json`. Both the Urban Kicks and letbuyy-core bundles are committed under `packages/theme-engine/examples/`. Byte-identity is proven by `theme-artifact-exporter.test.ts` (7 tests) — section source is copied verbatim with no escaping. Drift-detection CI (`theme-examples.test.ts`, 7 tests) fails immediately when `theme-bundle.ts` changes without regenerating. **Remaining gap:** the TypeScript string literals in `theme-bundle.ts` remain the authoritative source. A proper authoring pipeline where `.liquid` files are the primary source and TypeScript is the compiled artifact (Plan P5-1) is still OPEN. |

### 11.3 Phase H New Findings

Three findings were identified during Phase H implementation review. None blocks production (all Phase H code is exporter/linter/CLI — no render path). They are registered here for Phase I tracking.

| ID | Severity | File | Summary | Disposition |
|----|----------|------|---------|-------------|
| **H-F1** | MEDIUM | `packages/theme-engine/src/theme-linter.ts:64` | `forbidAttrs` variable declared but never iterated; `forbidden-style-attr` rule uses hardcoded `/\bstyle\s*=/i` regex instead of looping over `FORBID_ATTR`; if `FORBID_ATTR` grows to include `onload` or similar the linter silently misses it despite its comment claiming `LIQUID_RENDERED_HTML_DOMPURIFY_CONFIG` as source of truth | OPEN — Phase I DX hardening |
| **H-F2** | MEDIUM | `packages/theme-engine/src/theme-artifact-exporter.ts:83–93` | Template and locale keys embedded in `templates/${templateKey}.json` and `locales/${localeKey}.json` paths without sanitization; a Zod-valid key of `../../evil` produces a path-traversal path; `generate-examples.mjs` resolves `..` segments via `path.join` which can write files outside the intended `examples/` output directory | OPEN — Phase I schema/exporter hardening |
| **H-F3** | LOW | `packages/theme-engine/src/theme-artifact-exporter.ts:76–79` | `settings_data` exported verbatim to `config/settings_data.json` without applying `BLOCKED_DROP_KEYS` discipline enforced by the renderer at render time; asymmetry is undocumented and untested | OPEN — Phase I documentation or defensive-code pass |

### 11.4 Phase H Scope Note

Phase H scope: `packages/theme-engine/src/` (5 new modules + index re-exports), `packages/theme-engine/examples/` (generated artifacts), `packages/theme-engine/test/` (41 new tests), `docs/storefront-liquid-discovery/developer/` (5 docs). No gateway, storefront-runtime, identity-platform, or database changes. ART-17 frozen section registry untouched. DOMPurify config untouched. `THEME_LIQUID_RENDERING_DEFAULT_ENABLED` default untouched.

---

*End of Risk Closure Report — amended 2026-07-05 (Phase H additions)*

---

---

## 12. Phase I Amendment — QA Certification (2026-07-10)

Phase I is test-only: 48 new tests authored across 4 files (2 per lane), adversarial self-review, and 3 hardening fixes. No product source files were modified.

### 12.1 Updated Summary Counts

| Category | Phase H Count | Phase I Change | Updated Count |
|---|---|---|---|
| CLOSED-VERIFIED (Phase B static) | 12 | +0 | 12 |
| CLOSED-IMPLEMENTED (Phase C) | 5 | +0 | 5 |
| CLOSED-IMPLEMENTED (Phase D) | 7 | +0 | 7 |
| CLOSED-IMPLEMENTED (Phase E) | 3 | +0 | 3 |
| CLOSED-IMPLEMENTED (Phase F) | 1 | +0 | 1 |
| PARTIALLY-CLOSED-IMPLEMENTED (Phase F) | 2 | +0 | 2 |
| CLOSED-STRUCTURAL (Phase G) | 1 | +0 | 1 |
| CLOSED-IMPLEMENTED (Phase G) | 2 | +0 | 2 |
| MITIGATED (Phase G) | 1 | +0 | 1 |
| PARTIALLY-CLOSED-IMPLEMENTED (Phase H) | 1 | +0 | 1 |
| PARTIAL-IMPLEMENTED (Phase D) | 1 | +0 | 1 |
| OPEN-CONFIRMED-RISK | 11 | +0 | 11 |
| OPEN-UNVERIFIABLE | 1 | +0 | 1 |
| REFUTED | 7 | +0 | 7 |
| PARTIAL | 9 | +0 | 9 |

> No register row status changes in Phase I. Phase I is a QA certification pass — it added tests that will detect future regressions; it did not close previously open risks. One new HIGH product bug (I-F1: DOMPurify clobbering strips `name="name"` from customer-register form) was discovered and is tracked for Phase J.

### 12.2 Test Gate Baseline (Post Phase I)

| Suite | Command | Result | Notes |
|---|---|---|---|
| theme-engine | `pnpm typecheck test --filter=@letbuyy/theme-engine` | **221/221 PASS** | Baseline was 199; +21 lane-a (8 A11Y + 13 SEC); +1 hardening (SEC-6b) |
| storefront-runtime | `pnpm typecheck test --filter=@letbuyy/storefront-runtime` | **78/78 PASS** | Baseline was 52; +26 lane-b (13 hydration parity + 13 SSR contracts) |
| api-gateway | `pnpm typecheck --filter=@letbuyy/api-gateway` | **32 turbo tasks, exit 0** | No type errors; unchanged |
| merchant-control-plane | `pnpm typecheck test --filter=@letbuyy/merchant-control-plane` | **15/15 PASS** | Unchanged |

### 12.3 UC-01 Row Update

| ID | Prior Closure Status | Phase I Update |
|---|---|---|
| **UC-01** | CLOSED-IMPLEMENTED (Phase C) — "89/89 theme-engine tests pass; 19/19 storefront-runtime tests pass" (Phase C updated count from stale 56 to 89+7=96; Phase D→E→F→H updated to 101/31→109/52→157/52→198/52) | **Updated test baseline: theme-engine 221/221; storefront-runtime 78/78; merchant 15/15; api-gateway typecheck clean.** Phase I added 48 new tests across 4 files targeting enterprise QA categories (Accessibility 8, Security 13, Hydration 13, SSR 13). All baselines hold. |

### 12.4 Phase I New Findings

| ID | Severity | File | Summary | Disposition |
|---|---|---|---|---|
| **I-F1** | HIGH | `packages/theme-engine/src/theme-bundle.ts` (customer-register template) + `packages/theme-engine/src/theme-renderer.ts` (DOMPurify config) | DOMPurify 3.x clobbering guard strips `name="name"` from the customer-register `<input type="text">`; no-JS POST omits customer name; account created without name | **OPEN** — Phase J. Fix: rename form field to `customer_name` or suppress clobbering guard for that input. Test A11Y-5 now asserts `autocomplete="name"` as honest observable; a TODO comment documents the broken state. |
| **I-F2** | HIGH | `packages/theme-engine/test/qi-security.test.ts` (original SEC-6) | `__proto__` sub-assertion tautological for JS literal path — always passed regardless of BLOCKED_DROP_KEYS | **FIXED (Phase I hardening)** — SEC-6b added to test the real JSON.parse injection path |
| **I-F3** | MEDIUM | `packages/theme-engine/test/qi-a11y.test.ts` (A11Y-5) | Test pins clobbered state as passing without explicit xfail or skip marker; green CI hides the broken form field | **PARTIALLY MITIGATED** — honest observable + TODO comment added; explicit xfail mechanism deferred to Phase J |
| **I-F4** | MEDIUM | `tests/launch/lb-storefront-ssr-contracts.test.mjs` (initial lb-logout regex) | lb-logout form-nesting assertion satisfied by JS comment text, not structural template containment | **FIXED (Phase I hardening)** — regex anchored to `<lb-logout\b[^>]*>` |
| **I-F5** | LOW | `tests/launch/lb-storefront-ssr-contracts.test.mjs` (initial SEC-3a) | SSTI probe assertion used global `/\b49\b/` with implicit fixture-isolation coupling | **FIXED (Phase I hardening)** — narrowed to `/<p>[^<]*49[^<]*<\/p>/` |

### 12.5 Phase H Findings — Phase I Disposition

| ID | Severity | Summary | Phase I Disposition |
|---|---|---|---|
| **H-F1** | MEDIUM | `theme-linter.ts:64` — `forbidAttrs` declared but never iterated; silent gap if FORBID_ATTR grows | OPEN — carries to Phase J |
| **H-F2** | MEDIUM | `theme-artifact-exporter.ts:83–93` — path-traversal via unsanitised template/locale keys | OPEN — carries to Phase J |
| **H-F3** | LOW | `theme-artifact-exporter.ts:76–79` — `settings_data` exported without BLOCKED_DROP_KEYS filter | OPEN — carries to Phase J |

### 12.6 Phase I Scope Note

Phase I changed only test files and doc files. Production source files, frozen components (theme-registry.ts, sanitizer FORBID config, `THEME_LIQUID_RENDERING_DEFAULT_ENABLED`, ART-17 section registry), and database migrations are untouched. The two pre-existing validator failures (`validate-governance.mjs` — tenant-table registry; `sequential-migration-validator.mjs` — uncommitted migrations 186/187) remain unchanged and were present before Phase I.

---

*End of Risk Closure Report — amended 2026-07-10 (Phase I QA Certification)*

---

---

## 13. Phase J Amendment — Production Rollout Readiness (2026-07-10)

Phase J is a documentation-only phase. No product source files, test files, migration files, or governance constants were changed. The phase produced five planning and evidence documents in `docs/storefront-liquid-discovery/phase-j/` and this amendment. The platform-wide Liquid flip remains ARB-AUTHORITY. `THEME_LIQUID_RENDERING_DEFAULT_ENABLED = false` at `packages/theme-engine/src/theme-governance.ts:14`. `THEME_LIQUID_PLATFORM_WIDE_FLIP_DECISION.status = 'deferred'` at the same file, lines 16–21.

### 13.1 Updated Summary Counts

| Category | Phase I Count | Phase J Change | Updated Count |
|---|---|---|---|
| CLOSED-VERIFIED (Phase B static) | 12 | +0 | 12 |
| CLOSED-IMPLEMENTED (Phase C) | 5 | +0 | 5 |
| CLOSED-IMPLEMENTED (Phase D) | 7 | +0 | 7 |
| CLOSED-IMPLEMENTED (Phase E) | 3 | +0 | 3 |
| CLOSED-IMPLEMENTED (Phase F) | 1 | +0 | 1 |
| PARTIALLY-CLOSED-IMPLEMENTED (Phase F) | 2 | +0 | 2 |
| CLOSED-STRUCTURAL (Phase G) | 1 | +0 | 1 |
| CLOSED-IMPLEMENTED (Phase G) | 2 | +0 | 2 |
| MITIGATED (Phase G) | 1 | +0 | 1 |
| PARTIALLY-CLOSED-IMPLEMENTED (Phase H) | 1 | +0 | 1 |
| PARTIAL-IMPLEMENTED (Phase D) | 1 | +0 | 1 |
| OPEN-CONFIRMED-RISK | 11 | +0 | 11 |
| OPEN-UNVERIFIABLE | 1 | +0 | 1 |
| REFUTED | 7 | +0 | 7 |
| PARTIAL | 9 | +0 | 9 |

> No register row status changes in Phase J. Phase J is a documentation and evidence consolidation pass. No previously open risk was closed; no new code paths were introduced that would expose new risks.

### 13.2 Phase H/I Finding Disposition (Confirmed in Phase J Review)

The Phase J review process confirmed the following dispositions for findings carried from Phases H and I. These supersede the OPEN status recorded in §11.3 and §12.4 of this report.

| ID | Severity | Summary | Phase J Confirmed Status |
|---|---|---|---|
| **H-F1** | MEDIUM | `theme-linter.ts:64` — `forbidAttrs` declared; `for (const attr of forbidAttrs)` at line 101 iterates FORBID_ATTR from `LIQUID_RENDERED_HTML_DOMPURIFY_CONFIG`. Rule named `forbidden-attr`. Previously described as using a hardcoded regex. | **CONFIRMED CLOSED** — Code on `stepup/main` confirms iteration at `theme-linter.ts:101`. The linter and renderer share a single source of truth. §11.3 characterization of this finding as OPEN was inaccurate; the code was already correct. |
| **H-F2** | MEDIUM | `packages/theme-engine/src/theme-artifact-exporter.ts:58–68` — `assertSafeArtifactPath()` throws `UnsafeThemeArtifactPathError` on absolute paths or `..` segments. Called at all path composition points (lines 75, 82, 90, 116, 124). Previously described as an OPEN path-traversal risk. | **CONFIRMED CLOSED** — Code on `stepup/main` confirms the guard is present and applied at all composition points. §11.3 characterization as OPEN was inaccurate; the fix was already in place. Note: the wrong file path (`apps/storefront-runtime/src/lib/theme-engine/theme-artifact-exporter.ts`) was referenced in some Phase J draft documents; the correct path is `packages/theme-engine/src/theme-artifact-exporter.ts`. |
| **H-F3** | LOW | `theme-artifact-exporter.ts:101–107` — `settings_data` exported verbatim; code comment documents this as intentional. `BLOCKED_DROP_KEYS` is a render-time defence; settings_data holds design tokens. | **OPEN (acknowledged design choice)** — Risk remains if untrusted merchant data reaches the export pipeline. No code change made. ARB to assess at Gate 2. |
| **I-F1** | HIGH | DOMPurify 3.x clobbering guard strips `name="name"` from customer-register `<input type="text">`; no-JS POST omits customer name; account created with null/empty name. | **OPEN — requires ARB judgment as GO-gate for no-JS registration on Liquid stores.** Fix: rename to `name="customer_name"` in `theme-bundle.ts` and update gateway input parser. No fix applied in Phase J. |

### 13.3 ARB-Gate Blocker Summary (Confirmed in Phase J)

| # | Blocker | Phase Closed | Status (Confirmed Phase J) |
|---|---|---|---|
| B-1 | postMessage key mismatch (editor section-selection) | Phase C | **CLOSED** |
| B-2 | `newsletter` / `newsletter-signup` type split | Phase C + D | **CLOSED** |
| B-3 | Fonts not wired, wrong typeface | Phase D | **CLOSED** |
| B-4 | `linklists` absent from Liquid scope | Phase D | **CLOSED** |
| B-5 | Schema migration engine — zero concrete migrations | Phase G | **MITIGATED** |
| B-6 | `letbuyy-core` DB row missing | Phase G | **CLOSED** (conditional on migration 188 running against production DB) |
| B-7 | Settings dual-shape (DB flat vs TS 5-group) | Phase G | **MITIGATED** |

**5 of 7 CLOSED, 2 MITIGATED, 0 still OPEN as blockers.**

### 13.4 Rollout Readiness Verdict (Honest — 2026-07-10)

The platform is **structurally ready for a cautious per-store canary rollout**. The safety net is complete: 5-layer crash-recovery architecture ensures every Liquid failure degrades to a full React page with no blank-page or hard-500 outcome. Five of seven ARB-gate blockers are CLOSED; two are MITIGATED (non-blocking for the render path). The test gate is green at 221/221 theme-engine, 78/78 storefront-runtime, 15/15 merchant-control-plane. Security assertions (SSTI, XSS, prototype-pollution, FORBID_TAGS/ATTR, drop limits) all PASS in unit scope.

**The platform-wide flip is NOT ready to proceed without the following acknowledgments:**

1. **I-F1 (HIGH, OPEN)** — DOMPurify clobbering strips `name="name"` from the customer-register form. No-JS registration silently omits the customer name. The ARB must decide whether this is a hard GO-gate or a supervised fast-follow before any store activation.
2. **Live observability is NOT-CONNECTED** — Cloudflare Logpush and Analytics Engine are not wired. Fallback rate, render latency under production traffic, production memory behavior, and the count of stores currently on the Liquid path are all unknown. The ARB should require at minimum `wrangler tail --format=json` monitoring before a canary cohort is activated.
3. **No percentage-of-stores rollout mechanism exists** — Per-store activation via `theme_releases.release_manifest.renderer_engine` is the only available staged path. A gradual percentage rollout would require net-new infrastructure.
4. **`FEATURE_LIQUID` gateway flag is dormant** — `featureGate('FEATURE_LIQUID', ...)` is never called. The ARB should decide whether to wire it as a gateway-level kill switch before the platform flip.

The platform-wide flip (changing `THEME_LIQUID_RENDERING_DEFAULT_ENABLED` to `true`) requires a recorded ARB decision, a human-authored commit, and a supervised storefront-runtime redeploy. The Phase J package provides the evidence for that decision; it does not make it.

### 13.5 Phase J Scope Note

Phase J scope: `docs/storefront-liquid-discovery/phase-j/` (5 new documents), `docs/storefront-liquid-discovery/certification/RISK_CLOSURE_REPORT.md` (this amendment). No source files, test files, migration files, or governance constants modified. No test gate count changes. ART-17 frozen section registry untouched. `THEME_LIQUID_RENDERING_DEFAULT_ENABLED` default unchanged. The two pre-existing validator failures (`validate-governance.mjs` — tenant-table registry; `sequential-migration-validator.mjs` — uncommitted WIP migrations 186/187) remain unchanged and were present before Phase B.

---

*End of Risk Closure Report — amended 2026-07-10 (Phase J Production Rollout Readiness)*

---

---

## 14. Phase K Amendment — Theme Platform Primitives (2026-07-10)

Phase K is a **pure library addition**. No render-path, gateway, storefront-runtime, database, or governance-constant code was changed. Five new modules were added to `packages/theme-engine/src/`, along with a 12-section contract document, 55 source-contract tests, and 90 unit tests. Test gate: **theme-engine 311/311 PASS** (was 221; +90); **storefront-runtime 133/133 PASS** (was 78; +55).

### 14.1 Updated Summary Counts

| Category | Phase J Count | Phase K Change | Updated Count |
|---|---|---|---|
| CLOSED-VERIFIED (Phase B static) | 12 | +0 | 12 |
| CLOSED-IMPLEMENTED (Phase C) | 5 | +0 | 5 |
| CLOSED-IMPLEMENTED (Phase D) | 7 | +0 | 7 |
| CLOSED-IMPLEMENTED (Phase E) | 3 | +0 | 3 |
| CLOSED-IMPLEMENTED (Phase F) | 1 | +0 | 1 |
| PARTIALLY-CLOSED-IMPLEMENTED (Phase F) | 2 | +0 | 2 |
| CLOSED-STRUCTURAL (Phase G) | 1 | +0 | 1 |
| CLOSED-IMPLEMENTED (Phase G) | 2 | +0 | 2 |
| MITIGATED (Phase G) | 1 | +0 | 1 |
| PARTIALLY-CLOSED-IMPLEMENTED (Phase H) | 1 | +0 | 1 |
| PARTIAL-IMPLEMENTED (Phase D) | 1 | +0 | 1 |
| OPEN-CONFIRMED-RISK | 11 | +0 | 11 |
| OPEN-UNVERIFIABLE | 1 | +0 | 1 |
| REFUTED | 7 | +0 | 7 |
| PARTIAL | 9 | +0 | 9 |

> No register row status changes in Phase K. Phase K is a pure library primitive pass — it closes no previously open risks and introduces no new production code paths. Three adversarial findings were recorded (K-F1 MEDIUM, K-F2 LOW, K-F3 LOW); all are non-blocking and carry to future phases.

### 14.2 Theme Platform Gap Closure (new gap register, Phase K)

The six gaps identified in the Phase K Ground document were all closed by Lane-A. These are net-new capabilities that did not exist as prior gap register rows in the Phase B corpus; they are recorded here as the authoritative closure evidence.

| Gap ID | Gap description | Phase K closure |
|--------|----------------|-----------------|
| **K-G1** | No epoch comparator for `compatibility_range` date-string fields; no `node-semver` dep exists anywhere in the workspace | **CLOSED (Phase K — K1)** — `theme-version.ts`: `parseSchemaRange`, `schemaVersionIndex`, `satisfiesSchemaRange`, `isThemeBundleSchemaCompatible` — fail-closed; 31 tests. |
| **K-G2** | No function checking a bundle's `compatibility_range` against `KNOWN_LIQUID_BUNDLE_SCHEMA_VERSIONS` | **CLOSED (Phase K — K1)** — `isThemeBundleSchemaCompatible` composes the G4 gate + the epoch comparator. Result: `boolean` (fail-closed). |
| **K-G3** | No upgrade/update planner composing section migrations + settings diff + risk classification | **CLOSED (Phase K — K2)** — `theme-upgrade.ts`: `planThemeUpgrade` — composes `migrateThemeTemplateSchemasWithRegistry` (correctly wired, no-op today) + `groupSettingsFields` + comparator. 12 tests. |
| **K-G4** | No install-validation pipeline (lint + schema gate + compat + checksum + section migration readiness) | **CLOSED (Phase K — K3)** — `theme-install.ts`: `validateThemeInstall` — 5-stage pure pipeline; stops at first blocking gate; slug coherence via `resolveCanonicalThemeSlug`. 13 tests. |
| **K-G5** | No publish manifest builder; `ThemePackageManifest` (H5) covers content-addressed checksums but not the gateway-level semantic record for `theme_package_versions.release_manifest` | **CLOSED (Phase K — K4)** — `theme-publish.ts`: `buildThemePublishManifest` — deterministic, no timestamps, no random values; SHA-256 `content_hash` via H5 delegation. 17 tests. |
| **K-G6** | No analytics event shapes or emission-point annotations; query-time DB aggregates (`install_count` etc.) have no event contract | **CLOSED (Phase K — K6)** — `theme-analytics.ts`: `ThemeAnalyticsEvent` (5 event union), `describeThemeMetrics` (4 metrics with `connected: false` + exact source), `describeThemeEventEmissionPoints` (5 events with `implemented: false`). 17 tests. |

### 14.3 Freeze Compliance (Confirmed in Phase K)

Phase K Lane-B's 55 contract tests (`tests/launch/lb-k-theme-platform.test.mjs`) formally assert the freeze boundaries on every test run:

| Assertion | Evidence |
|-----------|---------|
| `apps/storefront-runtime/src/app/api/themes/install/route.ts` returns 410 | Test group "Storefront install route freeze" (2 tests) confirms the route body and no bypass was added |
| `apps/theme-marketplace` is `frozen-next-app` with `frozen-not-deployed` authority | Test group "Frozen-app manifests" (5 tests per app) asserts `runtime.manifest.json` fields |
| `apps/app-marketplace` is `frozen-next-app` with `frozen-not-deployed` authority | Same group |
| `apps/developer-portal` is `frozen-next-app` with `frozen-not-deployed` authority | Same group |
| `config/runtime/production-topology.json` records all three as `status: "frozen"` | Test group "Production topology" (1 test) |

### 14.4 Phase K New Findings

| ID | Severity | File | Summary | Disposition |
|----|----------|------|---------|-------------|
| **K-F1** | MEDIUM | `packages/theme-engine/test/theme-version.test.ts` | Test `'^ with different family returns false'` exercises same-family path (returns `true`), not the cross-family rejection. The `versionFamily` mismatch branch in `satisfiesSchemaRange` is architecturally untestable with a single-entry `KNOWN_LIQUID_BUNDLE_SCHEMA_VERSIONS`. Test name is misleading. | OPEN — when a second epoch is added to the known-versions list, a cross-family negative test must be added and the test name corrected. |
| **K-F2** | LOW | `packages/theme-engine/test/theme-install.test.ts` | Stage 3 (compat-range) rejection in `validateThemeInstall` is never exercised independently — an unknown `schema_version` causes Stage 1 to fire first. A bundle with a known schema_version but an unresolvable `compatibility_range` is not covered. | OPEN — add a test with `schema_version` in the known list but `compatibility_range: '>=future-epoch-not-in-list'` to exercise Stage 3 independently. |
| **K-F3** | LOW | `apps/app-marketplace/next-env.d.ts`, `apps/developer-portal/next-env.d.ts` | Auto-generated Next.js files whose import path changed from `.next/types/routes.d.ts` to `.next/dev/types/routes.d.ts`; these were dirty before Phase K and are not Phase K deliverables. | Not a Phase K issue — commit or reset independently. |

### 14.5 Test Gate Baseline (Post Phase K)

| Suite | Command | Result | Notes |
|---|---|---|---|
| theme-engine | `pnpm typecheck test --filter=@letbuyy/theme-engine` | **311/311 PASS** | +90 from Phase K (K1:31, K2:12, K3:13, K4:17, K6:17) |
| storefront-runtime | `pnpm typecheck test --filter=@letbuyy/storefront-runtime` | **133/133 PASS** | +55 from Phase K (K5 contract tests) |
| api-gateway typecheck | `pnpm typecheck --filter=@letbuyy/api-gateway` | **32 turbo tasks, exit 0** | Unchanged |

### 14.6 UC-01 Row Update

| ID | Prior Closure Status | Phase K Update |
|---|---|---|
| **UC-01** | Updated baseline at Phase I: theme-engine 221/221; storefront-runtime 78/78; merchant 15/15; api-gateway typecheck clean. | **Updated test baseline: theme-engine 311/311; storefront-runtime 133/133; api-gateway typecheck clean. merchant-control-plane 15/15 unchanged.** Phase K added 90 theme-engine tests (K1–K4, K6 unit tests) and 55 storefront-runtime tests (K5 contract tests). All baselines hold. |

### 14.7 Phase K Scope Note

Phase K scope: `packages/theme-engine/src/` (5 new modules), `packages/theme-engine/test/` (5 new test files), `docs/storefront-liquid-discovery/phase-k/` (contract doc + this report), `tests/launch/lb-k-theme-platform.test.mjs` (55 contract tests), `apps/storefront-runtime/package.json` (one-line test-script extension). No gateway, database migration, storefront-runtime source, identity-platform, or governance-constant changes. ART-17 frozen section registry untouched. DOMPurify config untouched. `THEME_LIQUID_RENDERING_DEFAULT_ENABLED` default unchanged. The three frozen apps are untouched. The 410 install route is untouched. Render path is byte-identical.

---

*End of Risk Closure Report — amended 2026-07-10 (Phase K Theme Platform Primitives)*

---

---

## 15. Phase L Amendment — AI Theme Platform SDK (2026-07-10)

Phase L is a **pure library addition** delivering 7 deterministic generative primitives, a unified Merchant AI SDK facade, 6 adversarial hardening fixes, and a source-contract test asserting zero LLM/AI provider imports anywhere in `packages/theme-engine/src/`. No render-path, gateway, storefront-runtime, database, or governance-constant code was changed. Test gate: **theme-engine 643/643 PASS** (was 311; +332); **storefront-runtime 687/687 PASS** (was 133; +554).

### 15.1 Updated Summary Counts

| Category | Phase K Count | Phase L Change | Updated Count |
|---|---|---|---|
| CLOSED-VERIFIED (Phase B static) | 12 | +0 | 12 |
| CLOSED-IMPLEMENTED (Phase C) | 5 | +0 | 5 |
| CLOSED-IMPLEMENTED (Phase D) | 7 | +0 | 7 |
| CLOSED-IMPLEMENTED (Phase E) | 3 | +0 | 3 |
| CLOSED-IMPLEMENTED (Phase F) | 1 | +0 | 1 |
| PARTIALLY-CLOSED-IMPLEMENTED (Phase F) | 2 | +0 | 2 |
| CLOSED-STRUCTURAL (Phase G) | 1 | +0 | 1 |
| CLOSED-IMPLEMENTED (Phase G) | 2 | +0 | 2 |
| MITIGATED (Phase G) | 1 | +0 | 1 |
| PARTIALLY-CLOSED-IMPLEMENTED (Phase H) | 1 | +0 | 1 |
| PARTIAL-IMPLEMENTED (Phase D) | 1 | +0 | 1 |
| OPEN-CONFIRMED-RISK | 11 | +0 | 11 |
| OPEN-UNVERIFIABLE | 1 | +0 | 1 |
| REFUTED | 7 | +0 | 7 |
| PARTIAL | 9 | +0 | 9 |

> No Phase B register row status changes in Phase L. Phase L is a pure library primitive pass — it closes no previously open risks and introduces no new production code paths. Six adversarial findings (L-F1 through L-F6) were discovered in a cross-lane review and fixed within the phase; none of these were in the Phase B corpus. The one safety guardrail that did not exist before Phase L — WCAG 2.1 contrast math (`meetsWcagAA`) — is now CONNECTED.

### 15.2 New Gap Register (Phase L gaps — closed by Phase L)

Seven gaps identified in the Phase L Ground document. These are net-new capabilities that did not exist as prior Phase B corpus rows; they are recorded here as closure evidence.

| Gap | Description | Phase L closure |
|-----|-------------|-----------------|
| **L-G1** | No WCAG 2.1 contrast utility (`relativeLuminance`, `contrastRatio`, `meetsWcagAA`) existed anywhere in `packages/theme-engine` | **CLOSED (Phase L — ai-color-system.ts)** — sRGB linearisation per IEC 61966-2-1; L=0.2126R+0.7152G+0.0722B; ratio=(L1+0.05)/(L2+0.05); AA=4.5:1 normal / 3:1 large; 29 tests. `theme-ai-sdk.ts` imports from this single source (L-F6 hardening). |
| **L-G2** | No parametric palette generator; 10 experiences had hardcoded hex values | **CLOSED (Phase L — ai-color-system.ts, theme-ai-sdk.ts)** — `deterministicPalette(seed, variant)` with 5 variants (warm/cool/bold/muted/neutral); fail-closed WCAG AA assertion; `generateColorSystem` with Zod validation. |
| **L-G3** | No typography pairing generator from EXPERIENCE_FONT_REGISTRY | **CLOSED (Phase L — ai-typography.ts, theme-ai-sdk.ts)** — `generateTypographyPairing` + `TYPOGRAPHY_PAIRING_CATALOG`; 5 intents; all fonts from EXPERIENCE_FONT_REGISTRY; 20 tests. |
| **L-G4** | No section-order generator from merchant goals | **CLOSED (Phase L — ai-layout.ts, theme-ai-sdk.ts)** — `generateSectionOrder(industry, goals)` constrained to BUILT_IN_SECTION_TYPES with Liquid parity; heroBanner/newsletter anchors enforced; throws on unknown types; 16 tests. |
| **L-G5** | No A11y advisory mapper for lint issues | **CLOSED (Phase L — ai-accessibility.ts)** — `generateA11yReport` maps 5 lint rules to WCAG SC references; HSL-lightness sweep for text adjustment; 17 tests. |
| **L-G6** | No bundle optimizer (unused section removal, locale dedup) | **CLOSED (Phase L — ai-optimizer.ts)** — `analyzeThemeOptimizations` collects references via `Object.values(template.sections)` (not order-only; L-F1 hardening); validates via `parseLiquidThemePackageBundle` before returning; 18 tests. |
| **L-G7** | No merchant personalization overlay generator from segment signals | **CLOSED (Phase L — ai-personalization.ts, theme-ai-sdk.ts)** — `applyPersonalizationOverlay` + `selectExperienceForMerchant`; priority chain: override (0.95) → industry (0.75) → fallback (0.40); G6 gate via `validateExperienceOverlay`; 21 tests. |

### 15.3 Adversarial Findings (Phase L — all CLOSED)

| ID | Severity | File | Finding | Fix |
|----|----------|------|---------|-----|
| **L-F1** | HIGH | `ai-optimizer.ts` | `optimizeThemeBundle` iterated only `template.order`; sections in `template.sections` but absent from `order` (disabled/hidden — valid schema state) were classified as unreferenced, deleted, then caused `parseLiquidThemePackageBundle` to throw | Replaced order-scoped loop with `Object.values(template.sections)`; wrapped parse in try/catch; returns original bundle on failure |
| **L-F2** | HIGH | `ai-theme-generator.ts` | `generateThemeFromBrief` documented "zero error-level lint issues" but never called `lintThemeBundle`; a future `style=` attribute in fixture source would silently return a lint-failing bundle | Added `lintThemeBundle` call; throws on any error-level issue |
| **L-F3** | MEDIUM | `ai-color-system.ts` | Dark-mode safety loop exited at `textL >= 1.0` with no post-loop WCAG assertion; future lightness change would silently break the guarantee | Post-loop `meetsWcagAA` assertion added; fail-closed throw on failure |
| **L-F4** | MEDIUM | `theme-ai-sdk.ts` | `FONT_PAIRING_CATALOG` `friendly` entry: `headingFontFamily='Lato'` vs `ai-typography.ts` mapping `headingFontFamily='Inter'`; same intent via different code paths produced different heading fonts | Corrected to `headingFontFamily='Inter'`, `fontFamily='Lato'`; both catalogs now agree |
| **L-F5** | LOW | `ai-accessibility.ts` | `adjustTextForAA` multiplicative RGB loop exhausted all 100 steps for dark-on-dark pairs (e.g. `#0A0A0A`) and always fell back to `#FFFFFF`, skipping valid mid-range options | Replaced with HSL-lightness sweep (L=0.9 → 0.5 for dark backgrounds) |
| **L-F6** | LOW | `theme-ai-sdk.ts` | ~90-line WCAG math duplicate from `ai-color-system.ts`; future fix must be applied twice | `relativeLuminance`, `contrastRatio`, `meetsWcagAA` imported from `./ai-color-system`; re-exported for backward compatibility; duplicate removed |

All six findings are CLOSED. No finding remains open from Phase L.

### 15.4 UC-01 Row Update

| ID | Prior Closure Status | Phase L Update |
|----|---------------------|----------------|
| **UC-01** | Updated baseline at Phase K: theme-engine 311/311; storefront-runtime 133/133; merchant 15/15; api-gateway typecheck clean. | **Updated test baseline: theme-engine 643/643; storefront-runtime 687/687; api-gateway typecheck clean; merchant-control-plane 15/15 unchanged.** Phase L added 332 theme-engine tests (7 new unit test files + expanded theme-ai-sdk.test.ts) and 554 storefront-runtime tests (lb-l-ai-theme-platform.test.mjs source-contract tests + accumulated launch suite). All prior baselines hold. |

### 15.5 Model Boundary (NOT-CONNECTED)

Phase L introduces the first explicit `MODEL_BOUNDARY` constant in `packages/theme-engine/src/theme-ai-sdk.ts`:

```ts
MODEL_BOUNDARY.status       = 'NOT_CONNECTED'
MODEL_BOUNDARY.envVar       = 'THEME_AI_PROVIDER_API_KEY'
MODEL_BOUNDARY.gatewayRoute = 'POST /v1/theme-ai/parse-brief (does not exist)'
```

The contract test (`lb-l-ai-theme-platform.test.mjs`) asserts no AI provider imports in any `packages/theme-engine/src/` file. This assertion runs on every storefront-runtime test gate. The NL→ThemeBrief seam, NL→seed-hex seam, and NL→SectionGoal[] seam are all NOT-CONNECTED; only the deterministic downstream generators are implemented.

### 15.6 Phase L Scope Note

Phase L changed only: `packages/theme-engine/src/` (7 new files + `theme-ai-sdk.ts` expanded + `index.ts` additive re-exports); `packages/theme-engine/test/` (7 new test files + `theme-ai-sdk.test.ts` expanded); `tests/launch/lb-l-ai-theme-platform.test.mjs` (new); `docs/storefront-liquid-discovery/phase-l/` (2 new doc files). No gateway, database migration, storefront-runtime source, identity-platform, merchant-control-plane, or governance-constant changes. ART-17 frozen section registry untouched. DOMPurify config untouched. `THEME_LIQUID_RENDERING_DEFAULT_ENABLED = false` unchanged. Urban Kicks fixture untouched. Render path is byte-identical.

---

*End of Risk Closure Report — amended 2026-07-10 (Phase L AI Theme Platform SDK)*
